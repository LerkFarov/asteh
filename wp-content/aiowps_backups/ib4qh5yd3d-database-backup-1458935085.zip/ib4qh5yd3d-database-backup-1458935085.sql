DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_cn_social_icon`;

CREATE TABLE `wp_cn_social_icon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `sortorder` int(11) NOT NULL DEFAULT '0',
  `date_upload` varchar(100) DEFAULT NULL,
  `target` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `wp_cn_social_icon` VALUES("1","vk","","http://ast/wp-content/uploads/2016/03/vk.png","0","1458484613","1");
INSERT INTO `wp_cn_social_icon` VALUES("2","t","","http://ast/wp-content/uploads/2016/03/t.png","1","1458484645","1");
INSERT INTO `wp_cn_social_icon` VALUES("3","m","","http://ast/wp-content/uploads/2016/03/m.png","2","1458484659","1");
INSERT INTO `wp_cn_social_icon` VALUES("4","f","","http://ast/wp-content/uploads/2016/03/f.png","3","1458484672","1");
INSERT INTO `wp_cn_social_icon` VALUES("5","ok","","http://ast/wp-content/uploads/2016/03/ok.png","4","1458484682","1");


DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","Мистер WordPress","","https://wordpress.org/","","2016-03-11 14:15:47","2016-03-11 14:15:47","Привет! Это комментарий.
Чтобы удалить его, авторизуйтесь и просмотрите комментарии к записи. Там будут ссылки для их изменения или удаления.","0","1","","","0","0");


DROP TABLE IF EXISTS `wp_gc_attributes`;

CREATE TABLE `wp_gc_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `att_group_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `unit` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_attributes` VALUES("41","5","Сила удара","Дж");
INSERT INTO `wp_gc_attributes` VALUES("42","5","Мощность","Вт");
INSERT INTO `wp_gc_attributes` VALUES("43","5","Вес","кг");
INSERT INTO `wp_gc_attributes` VALUES("44","5","Частота ударов","уд/мин");
INSERT INTO `wp_gc_attributes` VALUES("45","5","Тип патрона","");
INSERT INTO `wp_gc_attributes` VALUES("46","5","Длина","мм");
INSERT INTO `wp_gc_attributes` VALUES("47","5","Размер шестигранника","мм");
INSERT INTO `wp_gc_attributes` VALUES("48","5","Напряжение","В");
INSERT INTO `wp_gc_attributes` VALUES("49","5","Уровень шума","Дб");
INSERT INTO `wp_gc_attributes` VALUES("50","4","Сила удара","Дж");
INSERT INTO `wp_gc_attributes` VALUES("51","4","Мощность","Вт");
INSERT INTO `wp_gc_attributes` VALUES("52","4","Вес","кг");
INSERT INTO `wp_gc_attributes` VALUES("53","4","Количество режимов","режим");
INSERT INTO `wp_gc_attributes` VALUES("54","4","Тип патрона","");
INSERT INTO `wp_gc_attributes` VALUES("55","4","Частота ударов","уд/мин");
INSERT INTO `wp_gc_attributes` VALUES("56","4","Длина","мм");
INSERT INTO `wp_gc_attributes` VALUES("57","4","Напряжение","В");
INSERT INTO `wp_gc_attributes` VALUES("58","4","Длина кабеля","м");
INSERT INTO `wp_gc_attributes` VALUES("59","6","Тип хвостовика","");
INSERT INTO `wp_gc_attributes` VALUES("60","6","Форма наконечника","");
INSERT INTO `wp_gc_attributes` VALUES("61","6","Длина","мм");
INSERT INTO `wp_gc_attributes` VALUES("62","6","Вес","кг");
INSERT INTO `wp_gc_attributes` VALUES("63","7","Тип хвостовика","");
INSERT INTO `wp_gc_attributes` VALUES("64","7","Форма наконечника","");
INSERT INTO `wp_gc_attributes` VALUES("65","7","Длина","мм");
INSERT INTO `wp_gc_attributes` VALUES("66","7","Вес","кг");
INSERT INTO `wp_gc_attributes` VALUES("67","7","Ширина","мм");
INSERT INTO `wp_gc_attributes` VALUES("68","8","Тип хвостовика","");
INSERT INTO `wp_gc_attributes` VALUES("69","8","Диаметр","мм");
INSERT INTO `wp_gc_attributes` VALUES("70","8","Общая длина","мм");
INSERT INTO `wp_gc_attributes` VALUES("71","8","Рабочая длина","мм");
INSERT INTO `wp_gc_attributes` VALUES("72","8","Вес","кг");


DROP TABLE IF EXISTS `wp_gc_attributes_group`;

CREATE TABLE `wp_gc_attributes_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_attributes_group` VALUES("1","Без группы");
INSERT INTO `wp_gc_attributes_group` VALUES("4","Перфораторы");
INSERT INTO `wp_gc_attributes_group` VALUES("5","Отбойные молотки");
INSERT INTO `wp_gc_attributes_group` VALUES("6","Пика");
INSERT INTO `wp_gc_attributes_group` VALUES("7","Долото");
INSERT INTO `wp_gc_attributes_group` VALUES("8","Бур");


DROP TABLE IF EXISTS `wp_gc_categories`;

CREATE TABLE `wp_gc_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` text,
  `thumbnail` text,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_categories` VALUES("1","Без категории","","","");
INSERT INTO `wp_gc_categories` VALUES("4","Перфораторы","/wp-content/uploads/2016/03/212.gif","/wp-content/uploads/2016/03/31.gif","<p>Перфоратор — это профессиональный строительный инструмент. Область применения — сверление и долбление отверстий в кирпиче, бетоне и камне. Современные перфораторы могут выполнять функции дрели, шуруповерта и отбойного молотка.</p>");
INSERT INTO `wp_gc_categories` VALUES("5","Отбойные молотки","/wp-content/uploads/2016/03/1.jpg","/wp-content/uploads/2016/03/2.gif","<p>Главная задача электрического отбойного молотка - удар максимальной мощности. Основное назначение - пробивка отверстий в перекрытиях и стенах, фундаментах, они помогают в разборке железобетонных конструкций, разрушают асфальт, разрыхляют мерзлый грунт, разрубают металл.<br></p>");
INSERT INTO `wp_gc_categories` VALUES("6","Расходные материалы","/wp-content/uploads/2016/03/2.jpg","/wp-content/uploads/2016/03/1.gif","<p>&nbsp;Результат работы любого инструмента зависит не только от его качества и мастерства работника. Одним из важнейших факторов успешной работы является правильно подобранная оснастка, расходные материалы и дополнительные приспособления.<br></p>");


DROP TABLE IF EXISTS `wp_gc_p_images`;

CREATE TABLE `wp_gc_p_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) DEFAULT NULL,
  `url` text,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_p_images` VALUES("164","35","/wp-content/uploads/2016/03/Foto-2.jpeg","0");
INSERT INTO `wp_gc_p_images` VALUES("165","35","/wp-content/uploads/2016/03/Foto-15.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("166","35","/wp-content/uploads/2016/03/Foto-16.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("167","35","/wp-content/uploads/2016/03/Foto-17.jpg","3");
INSERT INTO `wp_gc_p_images` VALUES("168","35","/wp-content/uploads/2016/03/Foto-18.jpg","4");
INSERT INTO `wp_gc_p_images` VALUES("169","38","/wp-content/uploads/2016/03/Foto-4.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("170","38","/wp-content/uploads/2016/03/Foto-21.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("171","38","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("172","39","/wp-content/uploads/2016/03/Foto-5.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("173","39","/wp-content/uploads/2016/03/Foto-23.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("174","39","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("175","37","/wp-content/uploads/2016/03/Foto-3.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("176","37","/wp-content/uploads/2016/03/Foto-19.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("177","37","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("178","40","/wp-content/uploads/2016/03/Foto-678910.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("179","40","/wp-content/uploads/2016/03/Foto-2527293133.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("180","40","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("181","41","/wp-content/uploads/2016/03/Foto-678910.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("182","41","/wp-content/uploads/2016/03/Foto-2527293133.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("183","41","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("184","42","/wp-content/uploads/2016/03/Foto-678910.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("185","42","/wp-content/uploads/2016/03/Foto-2527293133.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("186","42","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("187","43","/wp-content/uploads/2016/03/Foto-678910.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("188","43","/wp-content/uploads/2016/03/Foto-2527293133.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("189","43","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("190","45","/wp-content/uploads/2016/03/Foto-678910.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("191","45","/wp-content/uploads/2016/03/Foto-2527293133.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("192","45","/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("208","51","/wp-content/uploads/2016/03/Foto-1.jpg","0");
INSERT INTO `wp_gc_p_images` VALUES("209","51","/wp-content/uploads/2016/03/Foto-11.jpg","1");
INSERT INTO `wp_gc_p_images` VALUES("210","51","/wp-content/uploads/2016/03/Foto-12.jpg","2");
INSERT INTO `wp_gc_p_images` VALUES("211","51","/wp-content/uploads/2016/03/Foto-13.jpg","3");
INSERT INTO `wp_gc_p_images` VALUES("212","51","/wp-content/uploads/2016/03/Foto-14.jpg","4");


DROP TABLE IF EXISTS `wp_gc_parameters`;

CREATE TABLE `wp_gc_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `att_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=427 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_parameters` VALUES("321","50","35","17,5","1");
INSERT INTO `wp_gc_parameters` VALUES("322","51","35","1500","2");
INSERT INTO `wp_gc_parameters` VALUES("323","52","35","10","3");
INSERT INTO `wp_gc_parameters` VALUES("324","53","35","2","4");
INSERT INTO `wp_gc_parameters` VALUES("325","54","35","SDS-Max","5");
INSERT INTO `wp_gc_parameters` VALUES("326","55","35","1100-2150","6");
INSERT INTO `wp_gc_parameters` VALUES("327","56","35","610","7");
INSERT INTO `wp_gc_parameters` VALUES("328","57","35","220","8");
INSERT INTO `wp_gc_parameters` VALUES("329","58","35","5","9");
INSERT INTO `wp_gc_parameters` VALUES("334","63","38","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("335","64","38","Плоское","2");
INSERT INTO `wp_gc_parameters` VALUES("336","65","38","280","3");
INSERT INTO `wp_gc_parameters` VALUES("337","66","38","0,5","4");
INSERT INTO `wp_gc_parameters` VALUES("338","67","38","25","5");
INSERT INTO `wp_gc_parameters` VALUES("339","63","39","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("340","64","39","Плоское","2");
INSERT INTO `wp_gc_parameters` VALUES("341","65","39","300","3");
INSERT INTO `wp_gc_parameters` VALUES("342","66","39","0,6","4");
INSERT INTO `wp_gc_parameters` VALUES("343","67","39","50","5");
INSERT INTO `wp_gc_parameters` VALUES("344","59","37","SDS-Мах","1");
INSERT INTO `wp_gc_parameters` VALUES("345","60","37","Пика","2");
INSERT INTO `wp_gc_parameters` VALUES("346","61","37","280","3");
INSERT INTO `wp_gc_parameters` VALUES("347","62","37","0,49","4");
INSERT INTO `wp_gc_parameters` VALUES("348","68","40","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("349","69","40","22","2");
INSERT INTO `wp_gc_parameters` VALUES("350","70","40","520","3");
INSERT INTO `wp_gc_parameters` VALUES("351","71","40","400","4");
INSERT INTO `wp_gc_parameters` VALUES("352","72","40","0.87","5");
INSERT INTO `wp_gc_parameters` VALUES("353","68","41","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("354","69","41","25","2");
INSERT INTO `wp_gc_parameters` VALUES("355","70","41","520","3");
INSERT INTO `wp_gc_parameters` VALUES("356","71","41","400","4");
INSERT INTO `wp_gc_parameters` VALUES("357","72","41","0,92","5");
INSERT INTO `wp_gc_parameters` VALUES("358","68","42","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("359","69","42","28","2");
INSERT INTO `wp_gc_parameters` VALUES("360","70","42","570","3");
INSERT INTO `wp_gc_parameters` VALUES("361","71","42","450","4");
INSERT INTO `wp_gc_parameters` VALUES("362","72","42","1,35","5");
INSERT INTO `wp_gc_parameters` VALUES("363","68","43","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("364","69","43","32","2");
INSERT INTO `wp_gc_parameters` VALUES("365","70","43","690","3");
INSERT INTO `wp_gc_parameters` VALUES("366","71","43","550","4");
INSERT INTO `wp_gc_parameters` VALUES("367","72","43","1,85","5");
INSERT INTO `wp_gc_parameters` VALUES("368","68","45","SDS-Max","1");
INSERT INTO `wp_gc_parameters` VALUES("369","69","45","40","2");
INSERT INTO `wp_gc_parameters` VALUES("370","70","45","920","3");
INSERT INTO `wp_gc_parameters` VALUES("371","71","45","800","4");
INSERT INTO `wp_gc_parameters` VALUES("372","72","45","2,00","5");
INSERT INTO `wp_gc_parameters` VALUES("418","41","51","42","1");
INSERT INTO `wp_gc_parameters` VALUES("419","42","51","1340","2");
INSERT INTO `wp_gc_parameters` VALUES("420","43","51","16.5","3");
INSERT INTO `wp_gc_parameters` VALUES("421","44","51","1400","4");
INSERT INTO `wp_gc_parameters` VALUES("422","45","51","шестигранный","5");
INSERT INTO `wp_gc_parameters` VALUES("423","46","51","726","6");
INSERT INTO `wp_gc_parameters` VALUES("424","47","51","30","7");
INSERT INTO `wp_gc_parameters` VALUES("425","48","51","220","8");
INSERT INTO `wp_gc_parameters` VALUES("426","49","51","99","9");


DROP TABLE IF EXISTS `wp_gc_prices`;

CREATE TABLE `wp_gc_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prices_group_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_prices` VALUES("17","8","1-5 суток");
INSERT INTO `wp_gc_prices` VALUES("18","8","6-11 суток");
INSERT INTO `wp_gc_prices` VALUES("19","8","от 12 суток");
INSERT INTO `wp_gc_prices` VALUES("20","8","Залог");


DROP TABLE IF EXISTS `wp_gc_prices_all`;

CREATE TABLE `wp_gc_prices_all` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price_id` int(11) DEFAULT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_prices_all` VALUES("126","17","35","800","1");
INSERT INTO `wp_gc_prices_all` VALUES("127","18","35","700","2");
INSERT INTO `wp_gc_prices_all` VALUES("128","19","35","600","3");
INSERT INTO `wp_gc_prices_all` VALUES("129","20","35","5000","4");
INSERT INTO `wp_gc_prices_all` VALUES("134","17","38","100","1");
INSERT INTO `wp_gc_prices_all` VALUES("135","18","38","100","2");
INSERT INTO `wp_gc_prices_all` VALUES("136","19","38","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("137","20","38","200","4");
INSERT INTO `wp_gc_prices_all` VALUES("138","17","39","100","1");
INSERT INTO `wp_gc_prices_all` VALUES("139","18","39","100","2");
INSERT INTO `wp_gc_prices_all` VALUES("140","19","39","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("141","20","39","200","4");
INSERT INTO `wp_gc_prices_all` VALUES("142","17","37","100","1");
INSERT INTO `wp_gc_prices_all` VALUES("143","18","37","100","2");
INSERT INTO `wp_gc_prices_all` VALUES("144","19","37","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("145","20","37","200","4");
INSERT INTO `wp_gc_prices_all` VALUES("146","17","40","100","1");
INSERT INTO `wp_gc_prices_all` VALUES("147","18","40","100","2");
INSERT INTO `wp_gc_prices_all` VALUES("148","19","40","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("149","20","40","200","4");
INSERT INTO `wp_gc_prices_all` VALUES("150","17","41","100","1");
INSERT INTO `wp_gc_prices_all` VALUES("151","18","41","100","2");
INSERT INTO `wp_gc_prices_all` VALUES("152","19","41","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("153","20","41","200","4");
INSERT INTO `wp_gc_prices_all` VALUES("154","17","42","150","1");
INSERT INTO `wp_gc_prices_all` VALUES("155","18","42","100","2");
INSERT INTO `wp_gc_prices_all` VALUES("156","19","42","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("157","20","42","200","4");
INSERT INTO `wp_gc_prices_all` VALUES("158","17","43","200","1");
INSERT INTO `wp_gc_prices_all` VALUES("159","18","43","150","2");
INSERT INTO `wp_gc_prices_all` VALUES("160","19","43","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("161","20","43","300","4");
INSERT INTO `wp_gc_prices_all` VALUES("162","17","45","200","1");
INSERT INTO `wp_gc_prices_all` VALUES("163","18","45","150","2");
INSERT INTO `wp_gc_prices_all` VALUES("164","19","45","100","3");
INSERT INTO `wp_gc_prices_all` VALUES("165","20","45","300","4");
INSERT INTO `wp_gc_prices_all` VALUES("180","17","51","900","1");
INSERT INTO `wp_gc_prices_all` VALUES("181","18","51","800","2");
INSERT INTO `wp_gc_prices_all` VALUES("182","19","51","700","3");
INSERT INTO `wp_gc_prices_all` VALUES("183","20","51","5000","4");


DROP TABLE IF EXISTS `wp_gc_prices_group`;

CREATE TABLE `wp_gc_prices_group` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_prices_group` VALUES("1","Без Группы");
INSERT INTO `wp_gc_prices_group` VALUES("8","Основные цены");


DROP TABLE IF EXISTS `wp_gc_products`;

CREATE TABLE `wp_gc_products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `instruction_url` text,
  `instruction_button` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

INSERT INTO `wp_gc_products` VALUES("35","4","Перфоратор Makita HR 5001 C","<ul><li>Надежный инструмент для решения профессиональных задач<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Интенсивное сверление с ударом или долбление<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Высокая производительность<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Электронная регулировка числа оборотов<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Двойная защитная изоляция<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Система плавного пуска<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Рукоятки являются цельными (замкнутыми), что позволяет крепко и удобно держать инструмент<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Световой индикатор замены угольных щеток<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Защита от вибрации<span class=\"Apple-tab-span\" style=\"white-space: pre;\">						</span><br></li><li>Оснащен рукояткой перехода на реверс<br></li></ul>","/wp-content/uploads/2016/03/Perforator-Makita-HR-5001-C.doc","Инструкция");
INSERT INTO `wp_gc_products` VALUES("37","6","Пика SDS-Мах 280 мм","<ul><li>Имеет широкий спектр применения при строительных и ремонтных работах<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Пика предназначена для разрушения бетона, камня, кирпича, асфальта<br></li><li>Отлично подходит для пробивания отверстий под проводку<br></li><li>Пика изготавливается из инструментальной стали, имеет длительный срок службы<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("38","6","Долото SDS-Мах 25х280 мм","<ul><li>Имеет широкий спектр применения при строительных и ремонтных работах<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Удобно для съема слоистых покрытий с кирпичных и бетонных стен на мощных тяжелых перфораторах<br></li><li>Отлично подходит для пробивания отверстий под проводку<br></li><li>Долото изготавливается из инструментальной стали, имеет длительный срок службы<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("39","6","Долото SDS-Мах 50х300 мм","<ul><li>Имеет широкий спектр применения при строительных и ремонтных работах<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Удобно для съема слоистых покрытий с кирпичных и бетонных стен на мощных тяжелых перфораторах<br></li><li>Отлично подходит для пробивания отверстий под проводку<br></li><li>Долото изготавливается из инструментальной стали, имеет длительный срок службы<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("40","6","Бур по бетону SDS-Мах 22х520 мм","<ul><li>Является оснасткой к тяжелым профессиональным перфораторам<br></li><li>Служит для ударного сверления отверстий в твердых материалах (бетон, кирпич, камень и т.д.)<br></li><li>Шнековая спираль способствует быстрому и эффективному отводу сверлильной пыли из отверстия<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Бур изготовлен из высококачественной инструментальной стали<br></li><li>Наконечник с четырьмя режущими кромками выполнен из твердого вольфрамового сплава ВК8С<br></li><li>Высокая износостойкость и длительный срок эксплуатации<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("41","6","Бур по бетону SDS-Мах 25х520 мм","<ul><li>Является оснасткой к тяжелым профессиональным перфораторам<br></li><li>Служит для ударного сверления отверстий в твердых материалах (бетон, кирпич, камень и т.д.)<br></li><li>Шнековая спираль способствует быстрому и эффективному отводу сверлильной пыли из отверстия<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Бур изготовлен из высококачественной инструментальной стали<br></li><li>Наконечник с четырьмя режущими кромками выполнен из твердого вольфрамового сплава ВК8С<br></li><li>Высокая износостойкость и длительный срок эксплуатации<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("42","6","Бур по бетону SDS-Мах 28х570 мм","<ul><li>Является оснасткой к тяжелым профессиональным перфораторам<br></li><li>Служит для ударного сверления отверстий в твердых материалах (бетон, кирпич, камень и т.д.)<br></li><li>Шнековая спираль способствует быстрому и эффективному отводу сверлильной пыли из отверстия<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Бур изготовлен из высококачественной инструментальной стали<br></li><li>Наконечник с четырьмя режущими кромками выполнен из твердого вольфрамового сплава ВК8С<br></li><li>Высокая износостойкость и длительный срок эксплуатации<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("43","6","Бур по бетону SDS-Мах 32х690 мм","<ul><li>Является оснасткой к тяжелым профессиональным перфораторам<br></li><li>Служит для ударного сверления отверстий в твердых материалах (бетон, кирпич, камень и т.д.)<br></li><li>Шнековая спираль способствует быстрому и эффективному отводу сверлильной пыли из отверстия<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Бур изготовлен из высококачественной инструментальной стали<br></li><li>Наконечник с четырьмя режущими кромками выполнен из твердого вольфрамового сплава ВК8С<br></li><li>Высокая износостойкость и длительный срок эксплуатации<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("45","6","Бур по бетону SDS-Мах 40х920 мм","<ul><li>Является оснасткой к тяжелым профессиональным перфораторам<br></li><li>Служит для ударного сверления отверстий в твердых материалах (бетон, кирпич, камень и т.д.)<br></li><li>Шнековая спираль способствует быстрому и эффективному отводу сверлильной пыли из отверстия<br></li><li>Подходит под отбойники с патроном SDS-max<br></li><li>Бур изготовлен из высококачественной инструментальной стали<br></li><li>Наконечник с четырьмя режущими кромками выполнен из твердого вольфрамового сплава ВК8С<br></li><li>Высокая износостойкость и длительный срок эксплуатации<br></li></ul>","","Инструкция");
INSERT INTO `wp_gc_products` VALUES("51","5","Отбойный молоток Hitachi H65SB2","<ul><li>Разрушение кирпичных, бетонных стен и пробивание проемов <br></li><li>Антивибрационная рукоятка <br></li><li>Блокировка кнопки включения <br></li><li>Большая производительность <br></li><li>Высокая прочность и надежность <br></li><li>Относительно малый вес <br></li><li>Низкий уровень вибрации <br></li><li>Дополнительная боковая рукоятка с возможностью поворота <br></li><li>Корпус из алюминиевого сплава <br></li><li>Высокая энергия удара <br></li></ul>","/wp-content/uploads/2016/03/Otboynyy-molotok-Hitachi-H65SB2.pdf","Инструкция");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=621 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://asteh.su/","yes");
INSERT INTO `wp_options` VALUES("2","home","http://asteh.su/","yes");
INSERT INTO `wp_options` VALUES("3","blogname","ast","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Ещё один сайт на WordPress","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","7282588@bk.ru","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:5:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:31:\"goods_catalog/goods_catalog.php\";i:2;s:35:\"rus-to-lat-advanced/ru-translit.php\";i:3;s:37:\"tinymce-advanced/tinymce-advanced.php\";i:4;s:27:\"wp-super-cache/wp-cache.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("37","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("38","gmt_offset","4","yes");
INSERT INTO `wp_options` VALUES("39","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("40","recently_edited","a:5:{i:0;s:94:\"/home/m/mali13mx/asteh.su/public_html/wp-content/themes/ast_theme/scripts/prod_get_scripts.php\";i:1;s:82:\"/home/m/mali13mx/asteh.su/public_html/wp-content/themes/ast_theme/page-product.php\";i:2;s:85:\"/home/m/mali13mx/asteh.su/public_html/wp-content/themes/ast_theme/page-categories.php\";i:3;s:75:\"/home/m/mali13mx/asteh.su/public_html/wp-content/themes/ast_theme/style.css\";i:4;s:85:\"D:\\web_server\\OpenServer\\domains\\ast/wp-content/plugins/social-icons/social-icons.php\";}","no");
INSERT INTO `wp_options` VALUES("41","template","ast_theme","yes");
INSERT INTO `wp_options` VALUES("42","stylesheet","ast_theme","yes");
INSERT INTO `wp_options` VALUES("43","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("44","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("45","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("46","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("47","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("48","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("49","db_version","35700","yes");
INSERT INTO `wp_options` VALUES("50","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("51","upload_path","","yes");
INSERT INTO `wp_options` VALUES("52","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("53","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("54","show_on_front","page","yes");
INSERT INTO `wp_options` VALUES("55","tag_base","","yes");
INSERT INTO `wp_options` VALUES("56","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("57","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("58","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("61","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("63","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("64","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("65","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("66","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("67","image_default_link_type","file","yes");
INSERT INTO `wp_options` VALUES("68","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("69","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("71","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("73","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("74","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("75","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("76","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("77","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("78","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("79","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("82","uninstall_plugins","a:1:{s:27:\"wp-super-cache/wp-cache.php\";s:22:\"wpsupercache_uninstall\";}","no");
INSERT INTO `wp_options` VALUES("83","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("84","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("85","page_on_front","2","yes");
INSERT INTO `wp_options` VALUES("86","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("87","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("88","initial_db_version","29630","yes");
INSERT INTO `wp_options` VALUES("89","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("90","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("91","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("92","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("93","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("94","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("95","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("96","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:18:\"orphaned_widgets_1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("97","cron","a:7:{i:1458921142;a:1:{s:11:\"wp_cache_gc\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1458924249;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1458958555;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1458997704;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1459001768;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1459007049;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("99","_transient_random_seed","b4d5c3102483426928336aa05da4fcb5","yes");
INSERT INTO `wp_options` VALUES("127","db_upgraded","","yes");
INSERT INTO `wp_options` VALUES("132","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:21:\"leviafun777@gmail.com\";s:7:\"version\";s:6:\"4.0.10\";s:9:\"timestamp\";i:1457705820;}","yes");
INSERT INTO `wp_options` VALUES("134","recently_activated","a:5:{s:23:\"wordfence/wordfence.php\";i:1458920644;s:40:\"extensible-html-editor-buttons/start.php\";i:1458487476;s:34:\"wp-social-icons/wp-social-cons.php\";i:1458486422;s:39:\"easy-social-icons/easy-social-icons.php\";i:1458485883;s:29:\"social-icons/social-icons.php\";i:1458485720;}","yes");
INSERT INTO `wp_options` VALUES("141","wordpress_file_upload_table_log_version","4.0","yes");
INSERT INTO `wp_options` VALUES("142","wordpress_file_upload_table_userdata_version","1.0","yes");
INSERT INTO `wp_options` VALUES("143","wordpress_file_upload_table_dbxqueue_version","1.0","yes");
INSERT INTO `wp_options` VALUES("198","_transient_twentyfourteen_category_count","1","yes");
INSERT INTO `wp_options` VALUES("248","theme_mods_twentyfourteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1458221856;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("249","current_theme","AST Theme","yes");
INSERT INTO `wp_options` VALUES("250","theme_mods_ast_theme","a:2:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:4:\"main\";i:2;}}","yes");
INSERT INTO `wp_options` VALUES("251","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("262","_site_transient_timeout_browser_10540a47081223ee03b0b4447e7dfacf","1459020303","yes");
INSERT INTO `wp_options` VALUES("263","_site_transient_browser_10540a47081223ee03b0b4447e7dfacf","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"49.0.2623.87\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("278","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("279","widget_pages","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("280","widget_calendar","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("281","widget_tag_cloud","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("282","widget_nav_menu","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("283","theme_worktext","с 9.00 до 19.00 без выходных","yes");
INSERT INTO `wp_options` VALUES("284","theme_address","г. Москва, ул. Мартеновская, д. 38, корп. 2","yes");
INSERT INTO `wp_options` VALUES("285","theme_email","7282588@bk.ru","yes");
INSERT INTO `wp_options` VALUES("286","theme_telephone","+7 (495) 728-25-88","yes");
INSERT INTO `wp_options` VALUES("302","_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c","1458517073","no");
INSERT INTO `wp_options` VALUES("317","cnss-width","18","yes");
INSERT INTO `wp_options` VALUES("318","cnss-height","18","yes");
INSERT INTO `wp_options` VALUES("319","cnss-margin","10","yes");
INSERT INTO `wp_options` VALUES("320","cnss-row-count","","yes");
INSERT INTO `wp_options` VALUES("321","cnss-vertical-horizontal","horizontal","yes");
INSERT INTO `wp_options` VALUES("322","cnss-text-align","right","yes");
INSERT INTO `wp_options` VALUES("342","tadv_settings","a:6:{s:9:\"toolbar_1\";s:175:\"bold,italic,blockquote,bullist,numlist,alignleft,aligncenter,alignright,link,unlink,table,fullscreen,copy,paste,superscript,subscript,undo,redo,image,media,visualblocks,wp_adv\";s:9:\"toolbar_2\";s:169:\"formatselect,alignjustify,strikethrough,outdent,indent,pastetext,removeformat,charmap,wp_more,emoticons,forecolor,backcolor,fontselect,fontsizeselect,styleselect,wp_help\";s:9:\"toolbar_3\";s:0:\"\";s:9:\"toolbar_4\";s:0:\"\";s:7:\"options\";s:21:\"advlist,advlink,image\";s:7:\"plugins\";s:41:\"visualblocks,emoticons,table,advlist,link\";}","yes");
INSERT INTO `wp_options` VALUES("343","tadv_admin_settings","a:2:{s:7:\"options\";s:0:\"\";s:16:\"disabled_plugins\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("344","tadv_version","4000","yes");
INSERT INTO `wp_options` VALUES("345","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("346","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("347","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("348","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("360","theme_soc_vk","#","yes");
INSERT INTO `wp_options` VALUES("361","theme_soc_t","#","yes");
INSERT INTO `wp_options` VALUES("362","theme_soc_m","#","yes");
INSERT INTO `wp_options` VALUES("363","theme_soc_f","#","yes");
INSERT INTO `wp_options` VALUES("364","theme_soc_ok","#","yes");
INSERT INTO `wp_options` VALUES("490","rewrite_rules","a:76:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=2&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `wp_options` VALUES("492","can_compress_scripts","1","yes");
INSERT INTO `wp_options` VALUES("514","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.4.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-4.4.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.4.2\";s:7:\"version\";s:5:\"4.4.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.4\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1458920634;s:15:\"version_checked\";s:5:\"4.4.2\";s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("515","_site_transient_timeout_browser_909560e93cdca5be38f19205f346d485","1459364534","yes");
INSERT INTO `wp_options` VALUES("516","_site_transient_browser_909560e93cdca5be38f19205f346d485","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"44.0.2403.130\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("560","_site_transient_timeout_browser_060ede9b1ab2bb85636c9d8c60169363","1459498608","yes");
INSERT INTO `wp_options` VALUES("561","_site_transient_browser_060ede9b1ab2bb85636c9d8c60169363","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"47.0.2526.111\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("562","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1458937012","no");
INSERT INTO `wp_options` VALUES("563","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Mar 2016 03:50:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"https://wordpress.org/?v=4.5-RC1-37079\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 4.5 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2016/03/wordpress-4-5-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Mar 2016 03:50:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4165\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:344:\"The release candidate for WordPress 4.5 is now available. We&#8217;ve made 49 changes since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.5 on Tuesday, April 12, but we need your help [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Mike Schroder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2251:\"<p>The release candidate for WordPress 4.5 is now available.</p>
<p>We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=37077&amp;stop_rev=37026&amp;limit=120&amp;verbose=on\">49 changes</a> since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.5 on <strong>Tuesday, April 12</strong>, but we need your help to get there.</p>
<p>If you haven’t tested 4.5 yet, now is the time!</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href=\"https://core.trac.wordpress.org/report/5\">find them here</a>.</p>
<p>To test WordPress 4.5, you can use the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin or you can <a href=\"https://wordpress.org/wordpress-4.5-RC1.zip\">download the release candidate here</a> (zip).</p>
<p>For more information about what’s new in version 4.5, check out the <a href=\"https://wordpress.org/news/2016/02/wordpress-4-5-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-2/\">Beta 2</a>, <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-3/\">Beta 3</a>, and <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-4/\">Beta 4</a> blog posts.</p>
<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.5 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.5 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>
<p>Be sure to <a href=\"https://make.wordpress.org/core/\">follow along the core development blog</a>, where we&#8217;ll continue to post <a href=\"https://make.wordpress.org/core/tag/dev-notes+4-5/\">notes for developers</a> for 4.5.</p>
<p><em>Free as in Freedom</em><br />
<em>It is WordPress 4.5</em><br />
<em>Also free as in beer</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
				
		
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.5 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2016 04:30:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:4:\"beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4155\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.5 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Mike Schroder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3409:\"<p>WordPress 4.5 Beta 4 is now available!</p>
<p>This software is still in development<strong>,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.5-beta4.zip\" target=\"_blank\">download the beta here</a> (zip).</p>
<p>For more information on what&#8217;s new in 4.5, check out the <a href=\"https://wordpress.org/news/2016/02/wordpress-4-5-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-2/\">Beta 2</a>, and <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-3/\">Beta 3</a> blog posts, along with <a href=\"https://make.wordpress.org/core/tag/4-5+dev-notes/\">in-depth field guides on make/core</a>. This is the final <a href=\"https://make.wordpress.org/core/version-4-5-project-schedule/\">planned beta</a> of WordPress 4.5, with a release candidate scheduled for next week.</p>
<p>Some of the changes in Beta 4 include:</p>
<ul>
<li>Add support for oEmbed <strong>moments and timelines from Twitter</strong> (<a href=\"https://core.trac.wordpress.org/ticket/36197\">#36197</a>).</li>
<li>More changes to better support <strong>HHVM with Imagick</strong>.<strong> </strong>Please test with HHVM setups and resizing/rotating images (<a href=\"https://core.trac.wordpress.org/ticket/35973\">#35973</a>).</li>
<li>Tightened up the <strong>Inline Link</strong> feature (<a href=\"https://core.trac.wordpress.org/ticket/33301\">#33301</a>, <a href=\"https://core.trac.wordpress.org/ticket/30468\">#30468</a>).</li>
<li>Support <code>&lt;hr&gt;</code> <strong>editor shortcut</strong> with 3 or more dashes (<code>---</code>); no spaces. To give more time to study the best shortcuts for users, text patterns for bold and italic have been removed and won&#8217;t ship with for 4.5 (<a href=\"https://core.trac.wordpress.org/ticket/33300\">#33300</a>).</li>
<li>Fixes for <strong>SSL with Responsive Images</strong>. Please test with SSL, especially on sites with mixed http/https setups (<a href=\"https://core.trac.wordpress.org/ticket/34945\">#34945</a>).</li>
<li>Allow rewrite rules to work in nested <strong>WordPress installations on IIS</strong> (<a href=\"https://core.trac.wordpress.org/ticket/35558\">#35558</a>).</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log/?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=37025&amp;stop_rev=36932&amp;limit=200&amp;verbose=on\">almost 100 changes</a> during the last week.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\" target=\"_blank\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\" target=\"_blank\">a list of known bugs.</a></p>
<p>Happy testing!</p>
<p class=\"p1\"><em>Llegamos al fin</em><br />
<em>del tiempo pa&#8217; beta</em><br />
<em>¡Pruébalo Ahora!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
				
		
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.5 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 06:59:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:4:\"beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4128\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.5 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Mike Schroder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3631:\"<p>WordPress 4.5 Beta 3 is now available!</p>
<p>This software is still in development<strong>,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.5-beta3.zip\" target=\"_blank\">download the beta here</a> (zip).</p>
<p>For more information on what&#8217;s new in 4.5, check out the <a href=\"https://wordpress.org/news/2016/02/wordpress-4-5-beta-1/\">Beta 1</a> and <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-2/\">Beta 2</a> blog posts, along with <a href=\"https://make.wordpress.org/core/tag/4-5+dev-notes/\">in-depth field guides on make/core</a>. Some of the fixes in Beta 3 include:</p>
<ul>
<li>Many <strong>Theme Logo Support</strong> (<a href=\"https://core.trac.wordpress.org/ticket/33755\">#33755</a>) fixes, including support for bundled Twenty Fifteen (<a href=\"https://core.trac.wordpress.org/ticket/35944\">#35944</a>).</li>
<li>Add <strong>Responsive Preview</strong> to theme install previewer (<a href=\"https://core.trac.wordpress.org/ticket/36017\">#36017</a>).</li>
<li>Support <strong>Imagick in HHVM</strong> (<a href=\"https://core.trac.wordpress.org/ticket/35973\">#35973</a>).</li>
<li><strong>Whitelist IPTC, XMP, and EXIF profiles</strong> from <code>strip_meta()</code> to maintain authorship, copyright, license, and image orientation (<a href=\"https://core.trac.wordpress.org/ticket/28634\">#28634</a>).</li>
<li>Support <strong>Windows shares/DFS roots</strong> in <code>wp_normalize_path()</code> (<a href=\"https://core.trac.wordpress.org/ticket/35996\">#35996</a>).</li>
<li><span class=\"s1\">New installs default to <strong>generating secret keys and salts locally</strong> instead of relying on the <span class=\"s2\">WordPress.org</span> API. Please test installing WP in situations where it can’t connect to the internet <span class=\"s1\">(like on a 🛳, ✈️, or 🛰) </span></span><span class=\"s1\">(<a href=\"https://core.trac.wordpress.org/ticket/35290\">#35290</a>).</span></li>
<li>OPTIONS requests to REST API should <strong>return Allow header</strong> (<a href=\"https://core.trac.wordpress.org/ticket/35975\">#35975</a>).</li>
<li>Upgrade twemoji.js to version 2 (<a href=\"https://core.trac.wordpress.org/ticket/36059\">#36059</a>) and add extra IE11 compatibility (<a href=\"https://core.trac.wordpress.org/ticket/35977\">#35977</a>) for <strong>Emoji</strong>.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log/?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=36931&amp;stop_rev=36814&amp;limit=200&amp;verbose=on\">more than 100 changes</a> during the last week.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\" target=\"_blank\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\" target=\"_blank\">a list of known bugs.</a></p>
<p>Happy testing!</p>
<p class=\"p1\"><em><span class=\"s1\">Beta one, two, three<br />
</span><span class=\"s1\">so many bugs have been fixed<br />
</span><span class=\"s2\">Closer now; four, five.</span></em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.5 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Mar 2016 04:55:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4116\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.5 Beta 2 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Mike Schroder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2370:\"<p>WordPress 4.5 Beta 2 is now available!</p>
<p>This software is still in development<strong>,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.5-beta2.zip\" target=\"_blank\">download the beta here</a> (zip).</p>
<p>For more information on what&#8217;s new in 4.5, check out the <a href=\"https://wordpress.org/news/2016/02/wordpress-4-5-beta-1/\">Beta 1 blog post</a>. Some of the fixes in Beta 2 include:</p>
<ul>
<li>Added <a href=\"https://core.trac.wordpress.org/ticket/33300\">Horizontal Rule (HR) editing shortcut</a> and <a href=\"https://core.trac.wordpress.org/ticket/28612\">dismissible &#8220;Paste as Text&#8221; notice</a> in <strong>TinyMCE</strong>.</li>
<li><strong>Selective Refresh</strong> support is <a href=\"https://core.trac.wordpress.org/changeset/36797\">enabled for core themes titles and taglines</a>, which allows shift-click to focus on controls and PHP filters to apply in the preview.</li>
<li>Resolved a fatal error on <strong>image upload</strong> when ImageMagick could not complete stripping meta during resize (<a href=\"https://core.trac.wordpress.org/ticket/33642\">#33642</a>).</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log/?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=36813&amp;stop_rev=36701&amp;limit=200&amp;verbose=on\">just over 100 changes</a> in the last week.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\" target=\"_blank\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\" target=\"_blank\">a list of known bugs.</a></p>
<p>Happy testing!</p>
<p><em>It&#8217;s peer pressure time</em><br />
<em>Testing: all cool kids do it</em><br />
<em>Help find ALL the bugs!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"Contributor Weekend: One-Hour Video\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2016/02/contributor-weekend-one-hour-video/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 26 Feb 2016 19:36:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4112\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:349:\"It&#8217;s time for our second global contributor weekend, and this time we&#8217;re focusing on the video team. For this month&#8217;s challenge, in honor of it being our second month, you have two options for how you can participate! The challenge for this month overall is to work with at least one hour worth of WordCamp video, which [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Jen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2590:\"<p>It&#8217;s time for our second global contributor weekend, and this time we&#8217;re focusing on the <a href=\"https://make.wordpress.org/tv\">video team</a>. For this month&#8217;s challenge, in honor of it being our second month, you have two options for how you can participate! The challenge for this month overall is to work with at least one hour worth of WordCamp video, which you can do by either creating subtitles or editing the video file in preparation for upload to <a href=\"http://WordPress.tv\">WordPress.tv</a>.</p>
<p>One of the great things about contributing to the video team is that you get to learn so much, since all the work basically involves watching WordCamp presentation videos. Subtitling is a doubly important need, as it is needed to make all those WordCamp videos accessible to people who are deaf or hard of hearing and can&#8217;t listen to the audio track, as well as making it possible for the videos to be consumed (in some cases after subtitle translation) by people who speak different languages.</p>
<p>The challenge will last from Saturday, February 27, 2016 through Sunday, February 28, 2016, and the results will be reviewed afterward by members of the video team. If you enjoy the challenge, the video team would be very excited to welcome you into their ranks! Interested? <a href=\"https://wp.me/P6onIa-28D\">Here&#8217;s how to participate</a>.</p>
<h3>What About Last Month?</h3>
<p>In January, the inaugural contributor weekend was focused on the support forums. That challenge had 73 participants, including 10 people who provided 20 or more correct answers to open support threads, thereby winning the challenge. Congratulations to Harris Anastasiadis, Ahmad Awais, Takis Bouyouris, Phil Erb, Eric Gunawan, Jackie McBride, Diana Nichols, Kostas Nicolacopoulos, Juhi Saxena, and Sarah Semark! To them and to everyone else who participated, thank you <strong>so much</strong> for your efforts. Every answer helps, and over the course of this contributor weekend, these amazing volunteers responded to <strong>800 support threads</strong>. The support forums queue of requests with no replies went from 28 pages to 7 pages &#8212; that was an incredible success, of which every participant was a part!</p>
<p>So head on over to see how to <a href=\"https://wp.me/P6onIa-28D\">get involved with the one-hour video challenge</a> this weekend, and help us make next month&#8217;s post just as impressive! <img src=\"https://s.w.org/images/core/emoji/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:41:\"
		
		
		
		
				
		
		

		
		
				
	

		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.5 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2016/02/wordpress-4-5-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 25 Feb 2016 03:27:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4080\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.5 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:62:\"https://wordpress.org/news/files/2016/02/wp-inline-linking.mp4\";s:6:\"length\";s:6:\"409018\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:62:\"https://wordpress.org/news/files/2016/02/wp-editor-updates.mp4\";s:6:\"length\";s:6:\"231953\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Mike Schroder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5453:\"<p>WordPress 4.5 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.5, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.5-beta1.zip\" target=\"_blank\">download the beta here</a> (zip).</p>
<p>WordPress 4.5 is slated for release on <a href=\"https://make.wordpress.org/core/version-4-5-project-schedule/\" target=\"_blank\">April 12</a>, but to get there, we need your help testing what we have been working on, including:</p>
<ul>
<li><strong>Responsive Preview of your site in the Customizer </strong>(<a href=\"https://core.trac.wordpress.org/ticket/31195\">#31195</a>) &#8211; See how your site looks in <a href=\"https://make.wordpress.org/core/2016/01/28/previewing-site-responsiveness-in-the-customizer/\">mobile, tablet, and desktop</a> contexts before making changes to its appearance.</li>
<li><strong>Theme Logo Support </strong>(<a href=\"https://core.trac.wordpress.org/ticket/33755\">#33755</a>) &#8211; Native support for a <a href=\"https://make.wordpress.org/core/2016/02/24/theme-logo-support/\">theme logo within the Customizer</a>.</li>
<li><strong>Inline Link Editing</strong> (<a href=\"https://core.trac.wordpress.org/ticket/33301\">#33301</a>) &#8211; Within the visual editor, <a href=\"https://wordpress.org/news/files/2016/02/wp-inline-linking.mp4\">edit links inline</a> for a smoother workflow.</li>
<li><strong>Additional Editor Shortcuts</strong> (<a href=\"https://core.trac.wordpress.org/ticket/33300\">#33300</a>) &#8211; <a href=\"https://wordpress.org/news/files/2016/02/wp-editor-updates.mp4\">Includes a few new shortcuts</a>, like <code>`..`</code> for <code>code</code> and <code>**..**</code> for <strong>bold</strong>.</li>
<li><strong>Comment Moderation Improvements </strong>(<a href=\"https://core.trac.wordpress.org/ticket/34133\">#34133</a>) &#8211; An enhanced experience when moderating comments, including preview with rendered formatting.</li>
<li><strong>Optimization of Image Generation </strong>(<a href=\"https://core.trac.wordpress.org/ticket/33642\">#33642</a>) &#8211; Image sizes are generated more efficiently and remove unneeded meta, while still including color profiles in Imagick, for reduced sizes of up to 50% with near identical visual quality.</li>
</ul>
<p>&nbsp;</p>
<p>There have been changes for developers to explore as well:</p>
<ul>
<li><strong>Selective Refresh </strong>(<a href=\"https://core.trac.wordpress.org/ticket/27355\">#27355</a>)<strong> </strong>&#8211; A <a href=\"https://make.wordpress.org/core/2016/02/16/selective-refresh-in-the-customizer/\">comprehensive framework</a> for rendering parts of the customizer preview in real time. Theme and plugin authors should test their widgets specifically for compatibility with selective refresh, and note that it <a href=\"https://core.trac.wordpress.org/ticket/35855\">may ultimately be opt-in for 4.5</a>.</li>
<li><strong>Backbone and Underscore updated to latest versions</strong> (<a href=\"https://core.trac.wordpress.org/ticket/34350\">#34350</a>)<b> </b>&#8211; Backbone is upgraded from 1.1.2 to 1.2.3 and Underscore is upgraded from 1.6.0 to 1.8.3. See the <a href=\"https://make.wordpress.org/core/2016/02/17/backbone-and-underscore-updated-to-latest-versions/\">this post</a> for important changes.</li>
<li><strong>Embed templates</strong> (<a href=\"https://core.trac.wordpress.org/ticket/34561\">#34561</a>) &#8211; Embed templates were split into parts and can now be directly overridden by themes via the template hierarchy.</li>
<li><strong>New WP_Site class</strong> (<a href=\"https://core.trac.wordpress.org/ticket/32450\">#32450</a>) &#8211; More object-oriented approach for managing sites in Multisite</li>
<li><strong>Script loader</strong> (<a href=\"https://core.trac.wordpress.org/ticket/14853\">#14853</a>, <a href=\"https://core.trac.wordpress.org/ticket/35873\">#35873</a>) &#8211; Introduces <code>wp_add_inline_script()</code> for including inline JavaScript just like <code>wp_add_inline_style()</code> works for CSS, and better support for script header/footer dependencies.</li>
</ul>
<p>If you want a more in-depth view of what major changes have made it into 4.5, <a href=\"https://make.wordpress.org/core/tag/4-5/\" target=\"_blank\">check out all 4.5-tagged posts</a> on the main development blog, or check out a <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=4.5&amp;group=component&amp;order=priority\">list of everything</a> that&#8217;s changed.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\" target=\"_blank\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\" target=\"_blank\">a list of known bugs.</a></p>
<p>Happy testing!</p>
<p><em>A wonderful day</em><br />
<em>is one that brings new WordPress</em><br />
<em>Four Five Beta One</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Experiment: WordCamp Incubator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2016/02/experiment-wordcamp-incubator/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 18 Feb 2016 19:28:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4076\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:399:\"WordCamps are locally-organized WordPress conferences that happen all over the world (and are so fun). Sometimes people don&#8217;t realize that WordCamps are organized by local volunteers rather than a central organization, and they contact us asking, &#8220;Can you bring WordCamp to my city?&#8221; When this happens, we always suggest they start with a meetup group, and think about [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Jen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2989:\"<p><a href=\"http://wordcamp.org\">WordCamps</a> are locally-organized WordPress conferences that happen all over the world (and are so fun). Sometimes people don&#8217;t realize that WordCamps are organized by local volunteers rather than a central organization, and they contact us asking, &#8220;Can you bring WordCamp to my city?&#8221; When this happens, we always suggest they start with a meetup group, and think about organizing a WordCamp themselves after their group has been active for a few months. We emphasize that WordCamps are locally-organized events, not something that the central <a href=\"https://make.wordpress.org/community\">community team</a> plans from afar.</p>
<p>This has been successful in many areas &#8212; there are currently 241 meetup groups on our meetup.com chapter program! In some regions, though, enthusiastic volunteers have had more of a challenge getting things started. Because of this, we&#8217;re going to try an experiment this year called the WordCamp Incubator.</p>
<p>The intention of the incubator program is to help spread WordPress to underserved areas through providing more significant organizing support for a first event. In practical terms, this experiment means we&#8217;ll be choosing three cities in 2016 where there is not an active WordPress community &#8212; but where it seems like there is a lot of potential and where there are some people excited to become organizers &#8212; and will help to organize their first WordCamp. These WordCamps will be small, one-day, one-track events geared toward the goal of generating interest and getting people involved in creating an ongoing local community.*</p>
<p>So, where should we do these three events?  If you have always wanted a WordCamp in your city but haven&#8217;t been able to get a meetup group going, this is a great opportunity. We will be taking applications for the next week, then will get in touch with everyone who applied to discuss the possibilities. We will announce the  cities chosen by the end of March.</p>
<p>To apply, <a href=\"http://wordpressdotorg.polldaddy.com/s/wordcamp-incubator-application\">fill in the application</a> by February 26, 2016. You don&#8217;t need to have any specific information handy, it&#8217;s just a form to let us know you&#8217;re interested. You can apply to nominate your city even if you don&#8217;t want to be the main organizer, but for this experiment  we will need local liaisons and volunteers, so please only nominate cities where you live or work so that we have at least one local connection to begin.</p>
<p>Thanks, and good luck!</p>
<p><em><strong>* </strong>For the record, that describes the ideal first WordCamp even if you have an active meetup &#8212; there&#8217;s no need to wait until your group is big enough to support a large multi-day event, and small events are a lot of fun because everyone has a chance to be involved and get to know most of the other attendees.</em></p>
<p>&nbsp;</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.4.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2016/02/wordpress-4-4-2-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Feb 2016 17:57:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4065\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:375:\"WordPress 4.4.2 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.4.1 and earlier are affected by two security issues: a possible SSRF for certain local URIs, reported by Ronni Skansing; and an open redirection attack, reported by Shailesh Suthar. Thank you [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2072:\"<p>WordPress 4.4.2 is now available. This is a <strong>security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.4.1 and earlier are affected by two security issues: a possible SSRF for certain local URIs, reported by <a href=\"https://www.linkedin.com/in/ronni-skansing-36143b65\">Ronni Skansing</a>; and an open redirection attack, reported by <a href=\"https://twitter.com/shailesh4594\">Shailesh Suthar</a>.</p>
<p>Thank you to both reporters for practicing <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">responsible disclosure</a>.</p>
<p>In addition to the security issues above, WordPress 4.4.2 fixes 17 bugs from 4.4 and 4.4.1. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.4.2\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/query?milestone=4.4.2\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.4.2</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.4.2.</p>
<p>Thanks to everyone who contributed to 4.4.2:</p>
<p><a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/berengerzyla\">berengerzyla</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/chandrapatel\">Chandra Patel</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">Chris Christoff</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/firebird75\">firebird75</a>, <a href=\"https://profiles.wordpress.org/ivankristianto\">Ivan Kristianto</a>, <a href=\"https://profiles.wordpress.org/jmdodd\">Jennifer M. Dodd</a>, <a href=\"https://profiles.wordpress.org/salvoaranzulla\">salvoaranzulla</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
				
		
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"Contributor Weekend: Support Forums\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2016/01/contributor-weekend-support-forums/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Jan 2016 18:31:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:12:\"contributors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:14:\"Support Forums\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4055\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:351:\"Our first global contributor drive is coming up next weekend, January 30-31, 2016, and we want you to be involved! Many of our current contributors first got involved at a Contributor Day at a WordCamp or WordPress Meetup event near them, but not everyone has had that opportunity, so we&#8217;re trying to create an online experience that [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Jen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2112:\"<p>Our first global contributor drive is coming up next weekend, January 30-31, 2016, and we want you to be involved!</p>
<p>Many of our current contributors first got involved at a Contributor Day at a <a href=\"http://wordcamp.org\">WordCamp</a> or <a href=\"http://www.meetup.com/pro/wordpress/\">WordPress Meetup</a> event near them, but not everyone has had that opportunity, so we&#8217;re trying to create an online experience that will give new contributors the same kind of live support and group dynamic. We&#8217;ll be doing these as weekend challenges rather than one-day events so that WordPress users all over the world can participate without worrying about pesky time zones, but each challenge will be designed to be completed within a few hours, comparable to an in-person Contributor Day.</p>
<p>Our inaugural Contributor Weekend is focused on the <a href=\"https://make.wordpress.org/support\">Support Team</a> &#8212; the folks who volunteer their time to help people with WordPress questions in the <a href=\"https://wordpress.org/support\">support forums</a> and <a href=\"https://make.wordpress.org/support/irc-support-channel/\">IRC</a>. Over the two day span, forum moderators will be available online to help new contributors and answer questions as needed. The challenge this month is called <em>20 Questions;</em> your mission (should you choose to accept it) is to help WordPress users by answering 20 forum support requests over the course of the weekend.</p>
<p>You can participate on your own, or you can get together with other people from your local meetup group and work on it together. Working together in person is really fun, so we highly recommend trying to get some folks together if you&#8217;re able, but if that&#8217;s not possible you can still connect to other participants online. Either way, this is a great way to give back to the WordPress project and have some fun helping people at the same time.</p>
<p>Interested? <a href=\"https://make.wordpress.org/support/20-questions/\">Get the details on how to participate</a>.</p>
<p>Hope to see you next weekend!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.4.1 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2016/01/wordpress-4-4-1-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Jan 2016 20:07:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4041\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:376:\"WordPress 4.4.1 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.4 and earlier are affected by a cross-site scripting vulnerability that could allow a site to be compromised. This was reported by Crtc4L. There were also several non-security bug fixes: Emoji [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Aaron Jorbin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5153:\"<p>WordPress 4.4.1 is now available. This is a <strong>security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.4 and earlier are affected by a cross-site scripting vulnerability that could allow a site to be compromised. This was <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">reported</a> by <a href=\"https://hackerone.com/crtc4l\">Crtc4L</a>.</p>
<p>There were also several non-security bug fixes:</p>
<ul>
<li>Emoji support has been updated to include all of the latest emoji characters, including the new diverse emoji! <img src=\"https://s.w.org/images/core/emoji/72x72/1f44d.png\" alt=\"👍\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/72x72/1f3ff.png\" alt=\"🏿\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/72x72/1f44c.png\" alt=\"👌\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/72x72/1f3fd.png\" alt=\"🏽\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/72x72/1f44f.png\" alt=\"👏\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/72x72/1f3fc.png\" alt=\"🏼\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></li>
<li>Some sites with older versions of OpenSSL installed were unable to communicate with other services provided through some plugins.</li>
<li>If a post URL was ever re-used, the site could redirect to the wrong post.</li>
</ul>
<p>WordPress 4.4.1 fixes 52 bugs from 4.4. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.4.1\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/query?milestone=4.4.1\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.4.1</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.4.1.</p>
<p>Thanks to everyone who contributed to 4.4.1:</p>
<p><a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/Compute\">Compute</a>, <a href=\"https://profiles.wordpress.org/redsweater\">Daniel Jalkut (Red Sweater)</a>, <a href=\"https://profiles.wordpress.org/DvanKooten\">Danny van Kooten</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling (ocean90)</a>, <a href=\"https://profiles.wordpress.org/dossy\">Dossy Shiobara</a>, <a href=\"https://profiles.wordpress.org/eherman24\">Evan Herman</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/gblsm\">gblsm</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/igmoweb\">Ignacio Cruz Moreno</a>, <a href=\"https://profiles.wordpress.org/jadpm\">jadpm</a>, <a href=\"https://profiles.wordpress.org/jeffpyebrookcom/\">Jeff Pye Brook</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/JPr\">jpr</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/KrissieV\">KrissieV</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/wp-architect\">Matthew Ell</a>, <a href=\"https://profiles.wordpress.org/meitar\">Meitar</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/rogerhub\">Roger Chen</a>, <a href=\"https://profiles.wordpress.org/rmccue\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/salcode\">Sal Ferrarello</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scottbrownconsulting\">scottbrownconsulting</a>, <a href=\"https://profiles.wordpress.org/SergeyBiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/ShinichiN\">Shinichi Nishikawa</a>, <a href=\"https://profiles.wordpress.org/smerriman\">smerriman</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stephenharris\">Stephen Harris</a>, <a href=\"https://profiles.wordpress.org/tharsheblows\">tharsheblows</a>, <a href=\"https://profiles.wordpress.org/voldemortensen\">voldemortensen</a>, and <a href=\"https://profiles.wordpress.org/webaware\">webaware</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 25 Mar 2016 08:16:52 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Thu, 24 Mar 2016 03:50:27 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20160324152444\";}","no");
INSERT INTO `wp_options` VALUES("564","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1458937012","no");
INSERT INTO `wp_options` VALUES("565","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1458893812","no");
INSERT INTO `wp_options` VALUES("566","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1458937014","no");
INSERT INTO `wp_options` VALUES("567","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Versions of WP-CLI Prior to 0.23.0 Are Incompatible with WordPress 4.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52830\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wptavern.com/versions-of-wp-cli-prior-to-0-23-0-are-incompatible-with-wordpress-4-5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1858:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/12/restful-wp-cli.png\"><img class=\"aligncenter size-full wp-image-49286\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/12/restful-wp-cli.png?resize=1025%2C459\" alt=\"restful-wp-cli\" /></a>Daniel Bachhuber, maintainer of <a href=\"http://wp-cli.org/\">WP-CLI</a>, a popular command line interface utility for managing WordPress sites, <a href=\"http://wp-cli.org/blog/version-0.23.0.html\">has released</a> version 0.23.0. This release includes a number of bug fixes, improvements, and features, but the most important thing to note is that earlier versions of WP-CLI will not work with WordPress 4.5.</p>
<p>According to Bachhuber, WordPress 4.5 loads a file in wp-settings.php and since WP-CLI uses a custom wp-settings-cli.php file, 0.23.0 and above are the only versions compatible with WordPress 4.5. Bachhuber created a <a href=\"https://core.trac.wordpress.org/ticket/34936\">new ticket on Trac</a> to start a discussion on using wp-settings.php instead of the custom file.</p>
<p>&#8220;WP-CLI uses a custom wp-settings-cli.php to load WordPress, instead of wp-settings.php. While I appreciate the <a class=\"ext-link\" href=\"http://wp-cli.org/blog/how-wp-cli-loads-wordpress.html\">historical justifications</a> for the bootstrap process, it would be much better if WP-CLI could use wp-settings.php because, occasionally, there are <a class=\"ext-link\" href=\"http://wp-cli.org/blog/versions-0.21.1-and-0.20.4.html\">substantial problems</a> arising from needing to maintain a fork,&#8221; Bachhuber said.</p>
<p>To see a full list of changes with detailed explanations on how to use new features such as installing community commands from the package index, check out the <a href=\"http://wp-cli.org/blog/version-0.23.0.html\">release post</a>.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Mar 2016 21:59:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: WPWeekly Episode 227 – The HeroPress Story with Topher DeRosia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=52825&preview_id=52825\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://wptavern.com/wpweekly-episode-227-the-heropress-story-with-topher-derosia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2102:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I are joined by <a href=\"https://topher1kenobe.com/\">Topher DeRosia</a> to learn about the origins of <a href=\"http://heropress.com/\">HeroPress</a>. DeRosia explains his motivation for creating the site and why despite not reaching his crowdfunding goal, decided to press on.</p>
<p>We also discuss the impact the essays are having on people across the world and whether or not HeroPress is accomplishing <a href=\"http://heropress.com/about/\">its mission</a>. Last but not least, DeRosia shares a personal story of someone who couldn&#8217;t write an essay for the site because they&#8217;re spending all of their time trying to stay alive.</p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/media-from-ftp/\">Media from FTP</a> allows you to import items into the WordPress media library that are uploaded via FTP.</p>
<p class=\"shortdesc\"><a href=\"https://wordpress.org/plugins/wp-open-last-modified/\">WP Open Last Modified </a>adds the last modified date and the current revision of your post/page using the [last_modified_date] shortcode.</p>
<p><a href=\"https://wordpress.org/plugins/advanced-wp-reset/\">Advanced WordPress Reset</a> is a convenient way to restore WordPress back to a fresh install without having to go through the traditional installation process.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 30th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #227:</strong><br />
</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Mar 2016 20:56:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"WP Mobile Apps: WordPress for iOS: Version 6.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://apps.wordpress.org/?p=3229\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://apps.wordpress.com/2016/03/24/wordpress-for-ios-version-6-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2905:\"<p>Hello, WordPress users! <a href=\"https://itunes.apple.com/us/app/wordpress/id335703880?mt=8&uo=6&at=&ct=\">Version 6.0 of the WordPress for iOS app</a> is now available in the App Store.</p>
<h1>What&#8217;s New:</h1>
<p><strong>Delete sites from the app!</strong>  We know, we know, creating WordPress.com sites can get addictive. But if you feel like decluttering your dashboard, you can now delete a site (or two) directly from the app.</p>

<a href=\"https://apps.wordpress.com/img_2103/\"><img width=\"169\" height=\"300\" src=\"https://apps.files.wordpress.com/2016/03/img_2103.png?w=169&h=300\" class=\"attachment-medium size-medium\" alt=\"It\'s now possible to delete sites from within the app.\" /></a>
<a href=\"https://apps.wordpress.com/img_2104/\"><img width=\"169\" height=\"300\" src=\"https://apps.files.wordpress.com/2016/03/img_2104.png?w=169&h=300\" class=\"attachment-medium size-medium\" alt=\"You can choose to keep all your content when deleting a site.\" /></a>

<p><strong>More improvements.</strong> Several magical <a href=\"https://github.com/wordpress-mobile/WordPress-iOS/issues?utf8=✓&q=is%3Aclosed+is%3Aissue+milestone%3A6.0+label%3A%22%5BType%5D+Enhancement%22+\">behind-the-scenes improvements</a> to make sure our codebase is stronger than ever.</p>
<p><strong>Bug fixes.</strong> As usual, we squashed some bugs, but there weren&#8217;t many this time around. Keep an eye on <a href=\"https://github.com/wordpress-mobile/WordPress-iOS/issues?utf8=✓&q=is%3Aclosed+is%3Aissue+milestone%3A6.0+label%3A%22%5BType%5D+Bug%22+\">the complete list of bugs here</a>.</p>
<h1>Thank You!</h1>
<p>Thanks to all of the contributors who worked on this release:<br />
<a href=\"https://github.com/aerych\">@aerych</a>, <a href=\"https://github.com/alexcurylo\">@alexcurylo</a>, <a href=\"https://github.com/astralbodies\">@astralbodies</a>, <a href=\"https://github.com/diegoreymendez\">@diegoreymendez</a>, <a href=\"https://github.com/frosty\">@frosty</a>, <a href=\"https://github.com/hugobaeta\">@hugobaeta</a>, <a href=\"https://github.com/jleandroperez\">@jleandroperez</a>, <a href=\"https://github.com/koke\">@koke</a>, <a href=\"https://github.com/kurzee\">@kurzee</a>, <a href=\"https://github.com/kwonye\">@kwonye</a>, <a href=\"https://github.com/mattmiklic\">@mattmiklic</a>, <a href=\"https://github.com/maxme\">@maxme</a>, <a href=\"https://github.com/oguzkocer\">@oguzkocer</a>, <a href=\"https://github.com/sendhil\">@sendhil</a> and <a href=\"https://github.com/SergioEstevao\">@SergioEstevao</a>..</p>
<p>You can track the development progress for the next update by visiting <a href=\"https://github.com/wordpress-mobile/WordPress-iOS/issues?q=is%3Aopen+is%3Aissue+milestone%3A6.1\" target=\"_blank\">our 6.1 milestone on GitHub</a>. Until next time!</p><img alt=\"\" border=\"0\" src=\"https://pixel.wp.com/b.gif?host=apps.wordpress.com&blog=108068616&post=3229&subd=apps&ref=&feed=1\" width=\"1\" height=\"1\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Mar 2016 12:48:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"diegoreymendez\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: Cast of Silicon Valley Nails The Meaning of Automattic on The First Try\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52809\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://wptavern.com/cast-of-silicon-valley-nails-the-meaning-of-automattic-on-the-first-try\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1475:\"<p><a href=\"http://www.hbo.com/silicon-valley\">Silicon Valley</a> is a comedic television series on HBO about a group of six engineers who create a startup company in Silicon Valley. <a href=\"http://www.wired.com/\">Wired.com</a> sat down with the cast and gave them the names to real startup companies to see if they could guess what they do.</p>
<p>Among the names mentioned is <a href=\"https://automattic.com/\">Automattic</a>. Fast forward to <a href=\"https://youtu.be/5Y64UeNeiOM?t=1m14s\">1:14</a> to watch Kumail Nanjiani, who plays <a href=\"http://www.hbo.com/silicon-valley/cast-and-crew/kumail-nanjiani/index.html\">Dinesh</a> on the show, correctly guess the meaning of the name on his first try, &#8220;Automattic with two T&#8217;s is a company ran by a dude named Matt,&#8221; he says. His response to being told he&#8217;s correct is pretty funny.</p>
<p>Warning, the video contains strong language and is not safe for work.</p>
<div class=\"embed-wrap\"></div>
<p>Automattic, founded in 2005, is the driving force behind WordPress.com and a handful of other services like Akismet, Gravatar, VaultPress, IntenseDebate, Polldaddy, and more.</p>
<p>While many people are confused between WordPress the software project and WordPress.com, the reason for two T&#8217;s in Automattic was guessed correctly on the first try by someone who is not deeply involved in the community. There&#8217;s something mildly humorous about that.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Mar 2016 23:45:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WPTavern: Restrict BuddyPress Signups by Email Domain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52202\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wptavern.com/restrict-buddypress-signups-by-email-domain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2637:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/02/mailboxes.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/02/mailboxes.jpg?resize=1024%2C496\" alt=\"mailboxes\" class=\"aligncenter size-full wp-image-39214\" /></a></p>
<p>Spam is one of the most discouraging things about managing a BuddyPress-powered social network. Since WordPress itself is already a magnet for spam signups and comments, BuddyPress is subject to the same and then some. With an ordinary WordPress site you can block most of it fairly well, but with BuddyPress you often have to wade through signups to verify that real humans aren&#8217;t getting blocked.</p>
<p>One of the best ways to cut down on the avalanche of unwanted signups is to restrict them by email domain. <a href=\"https://wordpress.org/plugins/bp-rsed/\" target=\"_blank\">BP Restrict Signup by Email Domain</a> is a plugin that allows you to whitelist an email domain or set of domains that will be required for registration on the site. You can also set an error message and create a custom message to appear on the registration page.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/email-address-restrictions.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/email-address-restrictions.png?resize=566%2C862\" alt=\"email-address-restrictions\" class=\"aligncenter size-full wp-image-52791\" /></a></p>
<p>The plugin was created by BuddyPress contributing developer Ray Hoh for the <a href=\"http://commons.gc.cuny.edu/\" target=\"_blank\">CUNY Academic Commons</a>. It&#8217;s part of a suite of plugins recommended by the <a href=\"http://commonsinabox.org/\" target=\"_blank\">Commons In A Box (CBOX)</a> free software project. The university uses the plugin to ensure that anyone signing up to the Academic Commons will have a CUNY email address. You can see it in action on the <a href=\"http://commons.gc.cuny.edu/register/\" target=\"_blank\">registration page</a>.</p>
<p>BP Restrict Signup by Email Domain works on both single site and multisite installations of WordPress. It has been tested with the latest version of BuddyPress (2.5) but should also be compatible back to version 1.6.</p>
<p>Not every social site can afford to limit email domains, but this plugin works well for academic sites, nonprofit or other types of organizations, or any community that excludes all but a few set email domains. <a href=\"https://wordpress.org/plugins/bp-rsed/\" target=\"_blank\">BP Restrict Signup by Email Domain</a> is open source on WordPress.org and is actively maintained for use on CUNY.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Mar 2016 23:09:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: Frederick Townes Confirms W3 Total Cache is Not Abandoned\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52766\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/frederick-townes-confirms-w3-total-cache-is-not-abandoned\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7219:\"<p><a href=\"https://wordpress.org/plugins/w3-total-cache/\">W3 Total Cache</a> is a free, caching WordPress plugin created by <a href=\"https://profiles.wordpress.org/fredericktownes/\">Frederick Townes</a> that&#8217;s active on more than one million sites. While the plugin&#8217;s core functionality is free to use, there&#8217;s a handful of services users can buy from within the plugin such as enhanced support to server and site configurations.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/W3TCUpsells.png\"><img class=\"size-full wp-image-52768\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/W3TCUpsells.png?resize=1025%2C700\" alt=\"W3 Total Cache Upsells\" /></a>W3 Total Cache Upsells
<p>A recent post by Scott Tuchman on the <a href=\"https://www.facebook.com/groups/advancedwp/permalink/1116520665076813/\">Advanced WordPress Facebook group</a> cites that the plugin hasn&#8217;t been updated in more than seven months and is not compatible with WordPress 4.4.2. Out of 44 reports, 34 people say W3 Total Cache 0.9.4.1 doesn&#8217;t work with WordPress 4.4.2.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/W3TCBroken.png\"><img class=\"size-full wp-image-52769\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/W3TCBroken.png?resize=884%2C626\" alt=\"W3 Total Cache Not Compatible With WordPress 4.4.2\" /></a>W3 Total Cache Not Compatible With WordPress 4.4.2
<p>The plugin was recently updated with the <a href=\"https://plugins.trac.wordpress.org/changeset/1375883/w3-total-cache\">only change</a> being the readme.txt file which states it has been tested up to WordPress 4.5. A cursory glance at the support forums indicates <a href=\"https://wordpress.org/support/topic/how-come-the-version-0941-now-says-updated-on-mar-21\">some users</a> are <a href=\"https://wordpress.org/support/topic/compatible-up-to-45-but-no-update-since-9-months-ago\">not pleased</a> with the simple update.</p>
<h2>A Rocky Year</h2>
<p>In 2015, a disgruntled customer who purchased services from <a href=\"http://www.w3-edge.com/\">W3 Edge</a>, <a href=\"https://www.reddit.com/r/Wordpress/comments/2r7un1/my_experience_with_what_its_like_with_w3_total/\">described their negative experience</a> in a post on the WordPress subreddit. The complaints include, a lack of communication, not receiving purchased services, and project delays. Mike McAlister, of <a href=\"https://arraythemes.com/\">Array Themes</a>, told the Tavern about his experience with W3 Edge.</p>
<blockquote><p>In 2014, I signed up for the premium version of W3 Total Cache to unlock some of the advanced caching features. The email confirmation said that the license would auto-renew unless cancelled, so I contacted them right away with my request to cancel the auto-renewal. I didn&#8217;t hear anything back and wrongly assumed this was taken care of.</p>
<p>Fast forward one year and I get an email out of nowhere that my W3 license had been renewed. I immediately contacted W3 with details of my order and politely requested a solution, but never heard a response.</p>
<p>I wrote a total of four emails and several tweets directed at W3 Edge and its founder, Frederick Townes, with not a single response throughout the ordeal. Like many others, I had to resort to calling the bank and filing a dispute to get my money back, which dragged the issue out for several months.</p></blockquote>
<p>At the end of the Reddit thread, W3 Edge <a href=\"https://www.reddit.com/r/Wordpress/comments/2r7un1/my_experience_with_what_its_like_with_w3_total/cqag9sw\">responded to the criticism</a> and admitted that the company let users down with its lack of engagement. It also admitted to having a small team and the challenges involved with its support model.</p>
<p>&#8220;One of the largest lessons learned is that there&#8217;s a lot to get right especially with a small team,&#8221; W3 Edge said. &#8220;We&#8217;ve made some changes to the team recently and we&#8217;re working to rectify experiences like the ones noted here. Since it’s the customer experience that matters and not intentions, I apologize for the negative experiences. Our mission remains to enable independent publishers with great software and solutions.&#8221;</p>
<h2>W3 Total Cache Status Update</h2>
<p>The company&#8217;s <a href=\"https://twitter.com/w3edge/with_replies?lang=en\">official Twitter account</a> has been inactive since April of 2015 and the <a href=\"https://www.w3-edge.com/weblog/\">last post published</a> on its blog was 10 months ago. Combined with the lack of plugin updates, it&#8217;s understandable why customers and users are concerned with the plugin&#8217;s status.</p>
<p>Frederick Townes, founder of W3 Edge, issued the following statement to the Tavern.</p>
<blockquote><p>Since the last update, development and other operations have been ongoing. There have been several hundred bug fixes based on user feedback, more than 100 improvements and numerous major improvements. We’ve added tens of thousands of unit tests for the various bugs and improvements in an attempt to allow us to release more updates faster in the future.</p>
<p>We’re also working on a new services and support model, which is more exclusive in an attempt to reduce the volume of service requests and misaligned customer / subscriber expectations.</p>
<p>Our goal is unchanged, to create easy ways for publishers and developers to increase WordPress performance and tune user-experience in self-hosted environments. As we work towards leaving beta and moving towards a 1.0 release (and making our GitHub repository public rather than private) our goal is to offer hosted services that use automation to simplify the performance optimization process in the future.</p></blockquote>
<p>I spoke to Townes for an hour on Skype and he comes across as a sincere, concerned business owner who is struggling to find a system that works for the amount of support volume he and his team are dealing with. I asked what keeps him motivated to continue working on W3 Total Cache, &#8220;I love solving complex problems which is what W3 Total Cache does,&#8221; Townes replied.</p>
<p>I can only imagine how heavy the burdens are maintaining a free plugin that&#8217;s active on more than a million sites. Joost de Valk, founder of <a href=\"https://yoast.com/\">Yoast.com</a>, and lead developer of <a href=\"https://wordpress.org/plugins/wordpress-seo/\">WordPress SEO</a>, a plugin active on more than one million sites shared some of the <a href=\"https://yoast.com/yoast-seo-3-0-release-a-recap/\">lessons he learned</a> after users experienced issues upgrading to 3.0.</p>
<h2>Have The Changes Worked?</h2>
<p>While researching for this article, I requested feedback from thousands of people to learn what recent customers are experiencing with the company but no one responded. This can mean any number of things but it&#8217;s difficult to determine whether the changes mentioned in the Reddit thread have improved the situation without getting feedback from recent customers.</p>
<p>If you&#8217;ve recently purchased services from W3 Edge, please share your experience with us in the comments.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Mar 2016 20:42:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: GitHub Issue and Pull Request Templates: Choose Your Own Adventure\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52746\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"http://wptavern.com/github-issue-and-pull-request-templates-choose-your-own-adventure\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2633:\"<p>Last month GitHub <a href=\"http://wptavern.com/github-introduces-issue-and-pull-request-templates\" target=\"_blank\">introduced issue and pull request templates</a> in response to the <a href=\"http://wptavern.com/open-source-project-maintainers-confront-github-with-open-letter-on-issue-management\" target=\"_blank\">&#8220;Dear GitHub&#8221; letter of complaints</a> from open source project maintainers. The new templates let maintainers streamline contributions to be more structured and meaningful for the project.</p>
<p>Creating issue and pull request templates could be a boring addition to your project&#8217;s task list, or you can have a little fun with <a href=\"https://twitter.com/TalAter\" target=\"_blank\">Tal Ater</a>&#8216;s new <a href=\"https://www.talater.com/open-source-templates/\" target=\"_blank\">open source template generator</a>. It leads you on a whimsical journey inspired by Lewis Carroll and H.P. Lovecraft while creating templates for your project.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/issue-pull-request-generator.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/issue-pull-request-generator.png?resize=1025%2C485\" alt=\"issue-pull-request-generator\" class=\"aligncenter size-full wp-image-52757\" /></a></p>
<p>The generator lets you build your templates in the style of a Choose Your Own Adventure book. At every step you make selections that will help structure the final templates. For example, you can choose whether or not to focus on bug reports, or prioritize new features/improvements, or make room for both in your issues template.</p>
<p>In a post titled &#8220;<a href=\"http://www.theopensourcer.com/2016/learning-to-ship-through-ridiculousness/\" target=\"_blank\">Learn to Ship Faster by Embracing Ridiculousness</a>,&#8221; Ater explains how he built the project over three days as an exercise to help him learn to let go and ship imperfect products:</p>
<blockquote><p>The project’s own imperfections are by definition its greatest strengths. Is it user friendly? About as friendly as a mad hatter. Does the writing make sense? Absolutely not. Did I get it from idea to shipping in 3 days? Abso-freaking-lutely.</p></blockquote>
<p>The result is a fun little time machine that transports you back to childhood while outputting some useful templates for your open source projects. They may require a bit of additional tweaking for your particular use, but Ater&#8217;s <a href=\"https://www.talater.com/open-source-templates/#/\" target=\"_blank\">generator</a> gives you an easy way to get started.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Mar 2016 16:32:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WordPress Theme Review Team Moves Towards Automating Review Process\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52730\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/wordpress-theme-review-team-moves-towards-automating-review-process\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2402:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/01/red-pen.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/01/red-pen.jpg?resize=1024%2C500\" alt=\"photo credit: pollas - cc\" class=\"size-full wp-image-37241\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/pollas/526544001/\">pollas</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.0/\">cc</a>
<p>Getting a theme approved for the WordPress directory can sometimes take months, depending on the number of corrections required and reviewers available to handle the queue. As part of a larger plan to make things more efficient, the WordPress Theme Review Team is making progress towards automating many of the time-consuming checks involved in reviewing submissions and updates.</p>
<p><a href=\"https://twitter.com/grapplerulrich\" target=\"_blank\">Ulrich Pogson</a>, who is leading the effort, published a <a href=\"https://make.wordpress.org/themes/2016/03/21/work-on-requirements-automation-update-1/\" target=\"_blank\">list of requirements</a> that might be good candidates for automated checks. Each item is now an issue on GitHub where contributors can discuss implementation and help build the checks. A few examples include &#8220;<a href=\"https://github.com/Otto42/theme-check/issues/133\" target=\"_blank\">Use the Customizer for implementing theme options</a>,&#8221; &#8220;<a href=\"https://github.com/Otto42/theme-check/issues/134\" target=\"_blank\">Don’t include any plugins</a>,&#8221; and &#8220;<a href=\"https://github.com/Otto42/theme-check/issues/126\" target=\"_blank\">Don’t include admin/feature pointers</a>.&#8221;</p>
<p>During the most recent meeting, the team approved a <a href=\"https://make.wordpress.org/themes/2016/03/22/22-march-team-meeting/\" target=\"_blank\">list of 13 requirements</a> they are aiming to automate. They will need to write checks for each one and are inviting collaboration on GitHub.</p>
<p>&#8220;It could be making a pull request, helping write the regex, or contributing ideas how to implement the check,&#8221; Pogson said. &#8220;Once the checks have been written we need help testing them for false positives.&#8221;</p>
<p>Check out the <a href=\"https://github.com/Otto42/theme-check/issues\" target=\"_blank\">issues queue</a> for the Theme Check plugin if you want to help the team automate more checks.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Mar 2016 22:30:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: Submit Pull Requests to WordPress Core with the GitHub-to-Patch Utility\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52711\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://wptavern.com/submit-pull-requests-to-wordpress-core-with-the-github-to-patch-utility\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3623:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/github-to-patch.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/github-to-patch.png?resize=1025%2C499\" alt=\"github-to-patch\" class=\"aligncenter size-full wp-image-52720\" /></a></p>
<p>When Matt Mullenweg asked the audience who has used Git and/or GitHub during his <a href=\"http://wptavern.com/matt-mullenwegs-state-of-the-word-highlights-internationalization-mobile-and-new-tools-for-wordpress-contributors\" target=\"_blank\">2014 State of the Word</a> address, the response was almost unanimous. “Whoah, that’s all the hands!” he exclaimed before announcing that core contributors will soon be able to submit pull requests on GitHub.</p>
<p>Two years later, an official patch workflow has not yet been established. In addition to ironing out the logistics, contributors must also take into account what might be lost or gained in the GitHub approach to problem solving. The GitHub pull request collaboration style is markedly different than the lengthy discussions that happen on WordPress Trac.</p>
<p>Nevertheless, WordPress contributors who use GitHub as part of daily life are eager to see progress on an official pipeline for pull requests. In the meantime, Ryan McCue has just launched a utility that allows contributors to submit pull requests to core. <a href=\"https://rmccue.io/patch/\" target=\"_blank\">GitHub-to-Patch</a> is a proof-of-concept that provides an easy way to submit a pull request as a patch.</p>
<p>The process that McCue outlines in his <a href=\"http://journal.rmccue.io/367/patch-wordpress-via-github/\" target=\"_blank\">post</a> involves submitting a pull request to the <a href=\"https://github.com/WordPress/WordPress\" target=\"_blank\">WordPress/WordPress repo</a>, selecting the request via the utility, and associating the request with the corresponding ticket number. He also advises heading back to the ticket to leave a comment about the patch you added.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/github-to-patch-step-1.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/github-to-patch-step-1.png?resize=1025%2C703\" alt=\"github-to-patch-step-1\" class=\"aligncenter size-full wp-image-52726\" /></a></p>
<p>&#8220;Internally, the utility uses GitHub’s API to get a patch format of the pull request, then uses Trac’s XML-RPC API to upload,&#8221; McCue said. &#8220;This requires your WordPress.org credentials, and because of cross-origin policy, also requires an intermediary server. I hope to fix this in the future, either by integrating the tool into Trac itself, or by using OAuth with WordPress.org.&#8221;</p>
<p>McCue clarified on Twitter that his utility is not meant to be a final solution to WordPress/GitHub interactions but rather a stop-gap measure until a better solution is available. He <a href=\"https://twitter.com/rmccue/status/712143679780200448\" target=\"_blank\">referenced</a> Weston Ruter&#8217;s approach that <a href=\"https://make.xwp.co/2015/12/05/streamlining-contributions-to-wordpress-core-via-github/\" target=\"_blank\">uses Travis CI to handle uploading patches from trusted pull requests to Trac</a> as one of the more elegant examples in the works.</p>
<p>For those with no SVN experience, GitHub-to-Patch significantly lowers the barrier to entry for contributing to core. If you don&#8217;t want to use the <a href=\"https://rmccue.io/patch/\" target=\"_blank\">utility</a> on McCue&#8217;s server, the code is available on GitHub and can be installed on your own server.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Mar 2016 18:34:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WordPress Adopts Accessibility Coding Standards for All New and Updated Code\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52690\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"http://wptavern.com/wordpress-adopts-accessibility-coding-standards-for-all-new-and-updated-code\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3221:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/paper-1.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/paper-1.jpg?resize=960%2C501\" alt=\"photo credit: Startup Stock Photos\" class=\"size-full wp-image-52706\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/L2KBJB91D6\">Startup Stock Photos</a>
<p>The Accessibility Team announced today that the <a href=\"https://make.wordpress.org/core/handbook/best-practices/coding-standards/accessibility-coding-standards/\" target=\"_blank\">WordPress Accessibility Coding Standards</a> have been approved for the core handbook. The team <a href=\"http://wptavern.com/your-chance-to-give-feedback-on-wordpress-accessibility-coding-standards\" target=\"_blank\">sought feedback on the draft of the guidelines</a> earlier this year and, after a few revisions, the coding standards are out of draft status.</p>
<p>Contributors will now be required to meet these guidelines in order to have their code merged into core:</p>
<blockquote><p>All new or updated code released in WordPress must conform with the <a href=\"https://www.w3.org/WAI/intro/wcag\" target=\"_blank\">WCAG 2.0 guidelines</a> at level AA.</p></blockquote>
<p>Level AA, according to accessibility team member Rian Rietveld, includes guidelines used as a reference for a legal standard in many countries. WordPress&#8217; new accessibility coding standards cover five key areas:</p>
<ul>
<li>HTML Semantics</li>
<li>Color Contrast</li>
<li>Keyboard Accessibility</li>
<li>Images and Icons</li>
<li>Labeling</li>
</ul>
<p>The default Twenty Sixteen theme is already compliant with WCAG 2 AA and more <a href=\"https://wordpress.org/themes/tags/accessibility-ready/\" target=\"_blank\">accessibility-ready themes</a> are tagged in the official directory. At this time, themes and plugins hosted on WordPress.org are not required to meet these guidelines.</p>
<p>&#8220;Having a dedicated principle that WordPress needs to meet a certain level of accessibility standards is incredibly powerful,&#8221; contributor Joe Dolson said in a reaction on his <a href=\"https://www.joedolson.com/2016/03/wordpress-goes-wcag-mean/\" target=\"_blank\">blog</a>.</p>
<p>&#8220;Since it doesn’t change the fact that the WordPress Accessibility team consists of a relatively small group of part-time volunteers, we have to realistically acknowledge that we won’t catch everything.</p>
<p>&#8220;But that still leaves us with an overall arc that leads to a future with a more accessible WordPress, and that’s an unmistakable win for accessibility,&#8221; he said.</p>
<p>Vocal accessibility advocates have been <a href=\"http://wptavern.com/your-chance-to-give-feedback-on-wordpress-accessibility-coding-standards\" target=\"_blank\">calling for WordPress to adopt a set of standards</a> and these new guidelines demonstrate the project&#8217;s commitment to serving those with a disability. With WCAG 2 AA established as the standard, the accessibility team is now in a better position to provide a list of requirements for an <a href=\"https://make.wordpress.org/accessibility/2014/05/02/automated-accessibility-testing/\" target=\"_blank\">automated testing tool</a>.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Mar 2016 05:17:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: WP Engine Adds 2FA to User Portal, Opt-In PHP 7 Support In the Works\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52657\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"http://wptavern.com/wp-engine-adds-2fa-to-user-portals-opt-in-php-7-support-in-the-works\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6799:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/11/wp-engine.jpg\"><img class=\"aligncenter size-full wp-image-34106\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/11/wp-engine.jpg?resize=1025%2C427\" alt=\"wp-engine\" /></a></p>
<p>WP Engine <a href=\"https://wpengine.com/blog/two-factor-authentication/\" target=\"_blank\">announced</a> today that two-factor authentication (2FA) is now available to its 42,000 customers. The security measure will help combat increasing attempts on the host&#8217;s user portal.</p>
<p>&#8220;As we grow, almost everything about the company changes, and security is one of them,&#8221; said WP Engine founder Jason Cohen. &#8220;For example, we see things like fraudulent accounts and account impersonation/phishing, and other things which didn’t appear often when we were smaller and less of a target.&#8221;</p>
<p>Adding 2FA is part of a larger plan for improved security that the company began last year when it hired Eric Murphy as its new security director.</p>
<p>&#8220;We’ve had a cross-departmental internal security group of about a dozen people for a few years now, but in 2015 we decided we needed even more leadership in that area,&#8221; Cohen said.</p>
<p>&#8220;We hired Eric last year, in fact before the December security incident, so in hindsight that was excellent timing.&#8221;</p>
<p>Murphy is now overseeing the technical aspects of security, like firewalls and VPNs, as well as the social engineering and training aimed at protecting customer account access.</p>
<p>After the December breach where <a href=\"http://wptavern.com/wp-engine-security-breach-customer-credentials-exposed\" target=\"_blank\">customer credentials were exposed</a>, WP Engine began moving its customers off of Linode&#8217;s cloud infrastructure. Cohen confirmed that thousands of customers have been moved and that no new customers have been added to Linode.</p>
<h3>The Challenges of Implementing 2FA</h3>
<p>Although providing 2FA for accounts is a security best practice, Cohen said that it would not have prevented the December breach, as the entry point was with Linode. Regardless, WP Engine customers have been requesting 2FA support for the user portal for years. When asked why it took the company so long to implement it, Cohen identified a few of the technical challenges.</p>
<p>&#8220;One of the challenges was in identity recovery,&#8221; he said. &#8220;We can’t use email as a way to recover from a lost phone, because then the email address becomes a &#8216;single factor,&#8217; i.e. you can use it to recover your password as well as your phone aspect.</p>
<p>&#8220;However, nowadays with the advent of Google Authenticator and other apps, plus people’s general awareness of how to use things like scratch codes, we felt it was now not going to be hard for people to use,&#8221; Cohen said.</p>
<p>When it comes to protecting WordPress, WP Engine customers have always been able to use a plugin to add 2FA. Cohen said that the company is investigating a solution to make it more convenient for customers who manage multiple accounts.</p>
<p>&#8220;Suppose you manage 50 WP sites and you want 2FA,&#8221; he said. &#8220;So do you configure 2FA on every site and have 50 entries in your Google Authenticator App? That stinks!</p>
<p>&#8220;So, something better would be a SSO system somewhere, have 2FA on <em>that</em>, and then use that to get into WordPress,&#8221; Cohen said.</p>
<p>&#8220;Another way would be to use OAuth, e.g. use Google OAuth on WP, and indeed for customers who already use Google Apps, we do recommend that method. Another method might be that our own User Portal be an OAuth provider.&#8221;</p>
<p>With a host of solutions already available, Cohen said they are also considering simply pointing customers to a list of recommendations.</p>
<p>&#8220;Even if we do our own, we’d always support the other methods,&#8221; he said. &#8220;The idea isn’t to box anyone into a single method.&#8221;</p>
<h3>WP Engine Plans to Add Opt-In PHP 7 Support in 2016</h3>
<p>WP Engine is currently <a href=\"https://wpengine.com/blog/php-7-the-way-of-the-future/\" target=\"_blank\">working on a PHP 7 implementation</a> for all customers. In December, the company tested 25 concurrent users over 5 minutes across 10 randomly selected URLs — run against a basic WordPress (4.3.1) install on its Mercury Vagrant configuration. The results showed that PHP 7 handles the raw hits 2.6x faster than PHP 5.5.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/wp-engine-testing.png\"><img class=\"aligncenter size-full wp-image-52674\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/wp-engine-testing.png?resize=1025%2C709\" alt=\"wp-engine-testing\" /></a></p>
<p>Unfortunately, customers who are eager to see WP Engine upgrade to PHP 7 across the board will be waiting for the rest of the WordPress ecosystem to catch up. As an alternative, the company is looking at the possibility of making PHP 7 an opt-in.</p>
<p>&#8220;We have PHP7 running on some machines,&#8221; Cohen said. &#8220;But it’s actually amazing how few WP sites in the field are compatible. We’re finding that it&#8217;s less than 20%. There will need to be an opt-in for that reason.&#8221;</p>
<p>Although WordPress core is compatible with PHP 7, the vast majority of WordPress plugins and themes are not.</p>
<p>&#8220;Even WooCommerce doesn’t completely work with it,&#8221; Cohen said. &#8220;Many big, popular plugins are not yet compatible. With PHP v5.5 there was some of that, but this is much more. Of course PHP7 is the future so it’s inevitable, but it’s going to take more time than some other PHP releases did.&#8221;</p>
<p>Cohen said the best case scenario would be for customers to choose PHP 7 on an install-by-install basis and change at any time. He does not yet have an ETA, as the company is working on an undisclosed big project that Cohen says is part and parcel of it.</p>
<p>&#8220;We have to make some decisions about how much to put into it before release, versus releasing it earlier and then layering in more things afterwards,&#8221; he said.</p>
<p>There are several large hurdles to allowing PHP version selection on an install-by-install basis, which need to be worked out before rolling it out to thousands of customers.</p>
<p>&#8220;One challenge is running multiple versions at the same time on the same machine,&#8221; Cohen said. &#8220;Another is tech support — if something doesn’t work in it, we need our 150+ support techs to understand how to figure that out and help.&#8221;</p>
<p>Cohen said he could see opt-in PHP 7 support happening for customers as early as this year but could not specify when.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Mar 2016 20:17:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Matt: Chamath on Growing Facebook\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46387\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://ma.tt/2016/03/chamath-on-growing-facebook/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1405:\"<p><span class=\"embed-youtube\"></span></p>
<p>This is a cool talk from <a href=\"https://twitter.com/chamath\">Chamath Palihapitiya</a> from a few years ago in 2013 which makes it extra interesting. It seems like a smaller audience so it&#8217;s fun and unguarded. (Though a great thing about Chamath is he&#8217;s incredibly candid in every context.) You can&#8217;t see the slides in the video, and there&#8217;s not much to them, but here they are:</p>
<p> 
<div> <strong> <a href=\"https://www.slideshare.net/growthhackersconference/how-we-put-facebook-on-the-path-to-1-billion-users\" title=\"Facebook&#x27;s Growth Hacker on how they put Facebook on the Path to 1 Billion Users\" target=\"_blank\">Facebook&#x27;s Growth Hacker on how they put Facebook on the Path to 1 Billion Users</a> </strong> from <strong><a target=\"_blank\" href=\"http://www.slideshare.net/growthhackersconference\">growthhackersconference</a></strong> </div>
<p>Here are the values he talks about at the end:</p>
<ol>
<li>Very high IQ.</li>
<li>Strong sense of purpose.</li>
<li>Relentless focus on success.</li>
<li>Aggressive and competitive.</li>
<li>High quality bar bordering on perfectionism.</li>
<li>Likes changing and disrupting things.</li>
<li>New ideas on how to do things better.</li>
<li>High integrity.</li>
<li>Surrounds themselves with good people.</li>
<li>Cares about building real value over perception.</li>
</ol>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Mar 2016 02:00:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"WPTavern: In Case You Missed It – Issue 5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=52645&preview_id=52645\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"http://wptavern.com/in-case-you-missed-it-issue-5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7253:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png\" rel=\"attachment wp-att-50955\"><img class=\"size-full wp-image-50955\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png?resize=676%2C292\" alt=\"In Case You Missed It Featured Image\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/112901923@N07/16153818039\">Night Moves</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc/2.0/\">(license)</a>
<p>There&#8217;s a lot of great WordPress content published in the community but not all of it is featured on the Tavern. This post is an assortment of items related to WordPress that caught my eye but didn&#8217;t make it into a full post.</p>
<h2>Human Made Hires Siobhan McKeown</h2>
<p>Development firm, Human Made Ltd., <a href=\"https://hmn.md/2016/03/17/siobhan-mckeown-joins-human-made/\">announced</a> that it has hired Siobhan McKeown as their events director. Human Made worked closely with McKeown who helped organize and run <a href=\"https://feelingrestful.com\">A Day of REST</a>, a conference devoted to the WordPress REST API. According to the post, McKeown&#8217;s role is to expand the company&#8217;s events, including the Day of Rest conference.</p>
<h2>WordPress is the Light in a Sea of Darkness</h2>
<p>Raghavendra Satish Peri from India, who discovered at the age of 14 that he was 80% blind, <a href=\"http://heropress.com/essays/finding-hope-darkness/\">describes how WordPress</a> became a shining light in a sea of darkness.</p>
<blockquote><p>WordPress has changed the way I see my life, today I am a full time <a href=\"http://www.digitala11y.com\">Digital Accessibility Consultant</a> &amp; I build most of my code examples on WP. This is helping me grow professionally &amp; personally each day. I am financially independent, travel around the world, attend &amp; speak at conferences/meet-ups, fought depression with my writing, wrote a bucket list &amp; am actively pursuing it. All this would have not been possible with the power of publishing &amp; WP has simplified it for me.</p></blockquote>
<p>In the post, Satish Peri says he has two wishes. The first is to attend WordCamp US and meet Matt Mullenweg. The second is to see every part of WordPress core be accessible. While the <a href=\"https://make.wordpress.org/accessibility/\">WordPress accessibility team</a> is working on his second wish, how can we as a community grant the first?</p>
<h2>WordPress&#8217; Greatest Threat Isn&#8217;t a CMS</h2>
<p>Chris Wallace explains why the <a href=\"http://chriswallace.org/the-biggest-threat-to-wordpress-isnt-another-cms/\">greatest threat to WordPress</a> isn&#8217;t a competing CMS, but the people who criticize it in a rude and disrespectful way.</p>
<blockquote><p>But the biggest threat to WordPress right now is not a CMS. Heck, it’s not even a technology challenge or an issue with legacy code. The biggest threat to WordPress is people in the community who voice opinions in a rude and disrespectful way, echoing a deep lack of appreciation for the contributors and project leaders simply trying to make WordPress better within the framework of being used on 25% of the web <em>with a desire to continue increasing that number</em>.</p></blockquote>
<p>I tried to explain <a href=\"http://wptavern.com/how-not-to-communicate-grievances-with-wordpress\">how to be helpful</a> when criticizing WordPress last year, but I&#8217;m not sure I made an impact. I know from experience that encountering a constant barrage of criticism is unhealthy and can lead to burnout. The same holds true for those who are committed to improving WordPress on a daily basis.</p>
<p>It&#8217;s not that things need to be sugarcoated, it&#8217;s that criticism should be given in an actionable way to make things better for all involved. It&#8217;s also about civil discourse and treating others with respect.</p>
<p>The final part of Wallace&#8217;s post is great advice:</p>
<blockquote><p>Let’s all take a few minutes to be grateful for the opportunity to make a living off the hard work of thousands of other people who donated their time and code to build something that has made a huge impact on the Internet and in people’s actual lives.</p></blockquote>
<h2>Matt Mullenweg on The Changelog Podcast</h2>
<p>Matt Mullenweg appeared on <a href=\"https://changelog.com/197/\">The Changelog podcast</a> to discuss the future of WordPress and how Calypso fits in. It&#8217;s a great show as the duo dive deep into the role JavaScript plays in the future of WordPress.</p>
<h2>Developing a WordPress Plugin That Uses Service APIs</h2>
<p>Smashing Magazine <a href=\"https://www.smashingmagazine.com/2016/03/making-a-wordpress-plugin-that-uses-service-apis/\">published a great guide</a> that explains how to create a plugin that taps into third-party service APIs.</p>
<h2>Adopting Plugins is Life Changing for Some</h2>
<p><a href=\"http://www.zdnet.com/meet-the-team/us/david-gewirtz/\">David Gewirtz</a>, who writes for ZDNet, describes how <a href=\"http://www.zdnet.com/article/a-year-later-what-happens-when-you-adopt-an-open-source-project/\">adopting 10 WordPress plugins changed his life</a>. It&#8217;s one of the coolest stories I&#8217;ve read on the use of the <a href=\"http://wptavern.com/adopt-me-plugin-tag-is-now-in-use-on-wordpress-org\">&#8220;Adopt-Me&#8221; tag</a> in the WordPress plugin directory. One of the best parts of the story is when Gewirtz explains what happened when he adopted a plugin with more than 10K active installs.</p>
<blockquote><p>Seamless Donations had more than 10,000 active users on the day I adopted it. I expected my workload would be roughly the same as for the widget. I&#8217;d make a few security fixes as they came along and tweaks for compatibility.</p>
<p>I was wrong.</p>
<p>I also expected the users to be seasoned webmasters. After all, if you&#8217;re installing an open source project on your server, you&#8217;re obviously going to be experienced with Linux and PHP and all the rest, right? Right?</p>
<p>Oh, how wrong I was.</p></blockquote>
<p>Definitely give this a read if you&#8217;re thinking about adopting a popular plugin.</p>
<h2>Warm Weather Wapuu</h2>
<p>As a traditional part of this series, I end each issue by featuring a Wapuu design. For those who don&#8217;t know, Wapuu is the <a href=\"http://wapuu.jp/2015/12/12/wapuu-origins/\">unofficial mascot</a> of the WordPress project. Since the first day of Spring in the US is Sunday, March 20th, I decided to feature the Wapuu family from WordCamp Miami. Each member of the family except for the basketball one, is a reminder that warmer weather is on the way!</p>
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">The official <a href=\"https://twitter.com/hashtag/wcmia?src=hash\">#wcmia</a> Wapuu family. <a href=\"http://t.co/U2Ao9Yh0qN\">pic.twitter.com/U2Ao9Yh0qN</a></p>
<p>&mdash; WordCamp Miami (@wordcampmiami) <a href=\"https://twitter.com/wordcampmiami/status/606179756472692736\">June 3, 2015</a></p></blockquote>
<p></p>
<p>That&#8217;s it for issue five. If you recently discovered a cool resource or post related to WordPress, please share it with us in the comments.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Mar 2016 01:40:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: WordPress 4.5 to Add oEmbed Support for Twitter Moments and Timelines\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52535\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"http://wptavern.com/wordpress-4-5-to-add-oembed-support-for-twitter-moments-and-timelines\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1549:\"<p>WordPress introduced oEmbed support for tweets in its <a href=\"https://codex.wordpress.org/Version_3.4\" target=\"_blank\">3.4 release</a>, but recent changes to Twitter&#8217;s API requires updates to core. On May 1, Twitter will be <a href=\"https://twittercommunity.com/t/deprecation-of-xml-response-type-for-single-tweet-oembed/62013\" target=\"_blank\">removing the XML response format</a> from the single Tweet oEmbed endpoint. Twitter engineer Niall Kennedy opened a <a href=\"https://core.trac.wordpress.org/ticket/36197\" target=\"_blank\">ticket</a> to change the oEmbed URL for single tweets from api.twitter.com to publish.twitter.com.</p>
<p>In addition to the patch Kennedy submitted with the ticket, core committer Dominik Schilling added a patch to extend the provider list to support <a href=\"https://about.twitter.com/moments\" target=\"_blank\">moments</a> and <a href=\"https://support.twitter.com/articles/164083\" target=\"_blank\">timelines</a> from Twitter.</p>
<p>The update was included in this week&#8217;s <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-4/\" target=\"_blank\">WordPress 4.5 Beta 4 release</a>. To see it in action you can take the latest beta for a test drive or check out the embedded moment and timeline links below.</p>
<p><a class=\"twitter-moment\" href=\"https://twitter.com/i/moments/650667182356082688\">The Obamas\' wedding anniversary</a></p>
<p><a class=\"twitter-grid\" href=\"https://twitter.com/TwitterDev/timelines/539487832448843776\">National Park Tweets</a></p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Mar 2016 21:29:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"Post Status: WordPress Hosting — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=22401\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://poststatus.com/wordpress-hosting-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2543:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Joe Hoyle &#8212; the CTO of Human Made &#8212; and Brian Krogsgard.</p>
<p>WordPress hosting is always a hot topic of conversation, due to the difficult task of differentiating one host from another. There is also a lot of money and marketing involved in the industry &#8212; an industry that includes some of the largest companies in the WordPress ecosystem.</p>
<p>In this episode, Joe and I attempt to break down what different types of hosting are available, how they are applicable to WordPress, and even dig in to some of the drama and politics that surround the hosting world.</p>
<p>The techical part of the conversation is the first 50 minutes or so, and around that mark, we get into the politics and non-technical issues around WordPress hosting, as well as tell some stories of how companies have successfully marketed themselves by getting embedded in the WordPress community.</p>
<p><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href=\"https://audio.simplecast.com/32589.mp3\">https://audio.simplecast.com/32589.mp3</a><br />
<a href=\"https://audio.simplecast.com/32589.mp3\">Direct Download</a></p>
<h3>Links</h3>
<ul>
<li><a href=\"http://reviewsignal.com\">Review Signal</a> is a great resource for comparing hosting.</li>
<li>The 2015 <a href=\"http://reviewsignal.com/blog/2015/07/28/wordpress-hosting-performance-benchmarks-2015/\">Review Signal WordPress hosting review</a> is a nice guide.</li>
<li>WordPress <a href=\"https://wordpress.org/hosting/\">recommended hosting page</a> is a source of a number of questions.</li>
<li>We talk about a lot of different hosting companies during this episode. Just Google them.</li>
</ul>
<p>This episode is sponsored by one of our great partners, Prospress. Check out <a href=\"https://poststatus.com/organizations/prospress-inc/\">Prospress&#8217;s Post Status profile</a>, as well as <a href=\"https://prospress.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">their website</a>. They are the makers of the excellent WooCommerce Subscriptions plugin, amongst other helpful products.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Mar 2016 20:02:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: Is W3C Replicating the WordPress Pingback System?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52624\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wptavern.com/is-w3c-replicating-the-wordpress-pingback-system\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6137:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/JamesRichmanProfile.png\" rel=\"attachment wp-att-52632\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/JamesRichmanProfile.png?resize=150%2C150\" alt=\"JamesRichmanProfile\" class=\"alignright size-thumbnail wp-image-52632\" /></a>This post was contributed by guest author <a href=\"http://1stwebdesigner.com/\" target=\"_blank\">James Richman</a>. James writes about marketing, digital design, entrepreneurship, and technology. He has gained most of his experience from running a variety of his own businesses for more than a decade.<br />
&nbsp;</p>
<hr />
<p>On January 12, 2016, the W3C (the World Wide Web Consortium) released its first public working draft of <a href=\"https://www.w3.org/TR/2016/WD-webmention-20160112/\" target=\"_blank\">Webmentions</a>, but the announcement didn’t feel new. In fact, Webmentions have been around since IndieWebCamp created them in 2013, and <a href=\"https://www.toptal.com/wordpress\" target=\"_blank\">top WordPress developers</a> are already using a Webmentions plugin to utilize the tool.</p>
<p>Yet, for those who use WordPress, Webmentions seemed like a retread of WordPress’ Pingback system from the early 2000s, which featured a similar concept.</p>
<p>The Pingback system was invented in 2002 by Stuart Langridge, and in essence, it allowed pieces that were published on different WordPress sites to talk to each other. This is perhaps best explained by walking through an example scenario:</p>
<ol>
<li>Website A posts a new entry on its blog.</li>
<li>Website B responds to that blog post with its own post and links to the post on Website A.</li>
<li>The Pingback system then notifies Website A that Website B wrote about and linked to its blog post.</li>
<li>Website A then verifies the content and link on Website B. If it is not spam, Website A will post a comment on the original blog post linking to Website B’s post.</li>
</ol>
<p>It’s important to note a few things about the Pingback system. First, it is exclusively for WordPress sites, and both sites have to enable Pingback for it to work. Second, the whole Pingback system is automated, streamlining the process of trackbacks, which is the manual equivalent of the automated Pingback.</p>
<p>Yet despite its perks, <a href=\"http://wptavern.com/its-time-for-xml-rpc-in-wordpress-to-hit-the-road\" target=\"_blank\">Pingback system usage</a> declined after the automatic system was taken advantage of by spammers.</p>
<p>The issue of spamming and abuse of such a communication channel has long been the problem with this type of communication channel. Prior to Pingbacks, WordPress used a Trackback system that provided the same type of communication.</p>
<p>The only difference between the Trackback system and Pingbacks is that Trackbacks had to be inputted manually. Spamming problems were just as prevalent with trackbacks. In fact the WPTavern site <a href=\"http://wptavern.com/wptavern-was-trackbacked-to-death\" target=\"_blank\">shut down in 2010</a> because of trackback spam.</p>
<p>So what makes Webmentions different than the Pingbacks and Trackbacks that came before? Well, not all that much. Turns out, Webmentions do the exact same thing as the Pingback system; they just do it better.</p>
<p>The biggest difference between the two is the code they’re composed of. Pingback uses XMLRPC, an outdated approach that encodes data with XML and then transports that data with HTTP. The Pingback system is bulky and slow. Webmentions, on the other hand, uses HTTP and x-www-form-urlencoded content, a much more widely accepted format in today’s world. The result is that Webmentions is much faster and much easier to integrate.</p>
<p>As Pingback’s creator Langridge <a href=\"http://www.kryogenix.org/days/2014/11/29/enabling-webmentions/\" target=\"_blank\">points out on his blog</a>, “XMLRPC is considerably less popular than it was, and is really heavyweight for this sort of thing. We’ve learned since then that HTTP can actually do all this stuff for us way more simply.” If you haven’t guessed, the Pingback founder has converted to Webmentions too.</p>
<p>Webmention’s growing popularity is due to the tool’s ease of use and the fact that it blocks spam effectively with the <a href=\"http://indiewebcamp.com/Vouch\" target=\"_blank\">Vouch protocol</a>. But Webmentions also look better aesthetically in the comments section. Pingback comments look robotic and aren’t exactly readable; a Pingback comment contains the title of the post that sent the Pingback and an ellipsed summary that doesn’t make much sense.</p>
<p>Webmentions look and feel like human comments with the help of the <a href=\"https://github.com/pfefferle/wordpress-semantic-linkbacks\" target=\"_blank\">Semantic Linkbacks plugin</a>. This plugin parses the Webmention linkback and translates it into a full sentence (e.g. ‘Sarah mentioned this post in her article x on site y’) and can even include the author’s profile picture.</p>
<p>Webmentions are quickly replacing the Pingback system because of the tool’s convenience and better implementation to reach a similar goal, and this has been happening prior to W3C’s public endorsement. So what does W3C’s support of <a href=\"http://indiewebcamp.com/webmention\" target=\"_blank\">IndieWebCamp’s creation</a> mean?</p>
<p>Ultimately, W3C’s announcement will likely help cement Webmention’s place on the internet. And so W3C’s recent push can be and should be considered as an effort to standardize the wild web.</p>
<p>The internet was created to communicate and share information, yet individual pieces of content are unable to communicate with each other as easily as users can. The Pingback system was a worthy, but flawed, attempt to change that, and now Pingback’s legacy survives through the broader support and growing distribution of Webmention’s network. If Webmentions become more popular, maybe one day in the future, they will connect the strands of the web together, so that the web will have earned its namesake in truth.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Mar 2016 17:40:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"WPTavern: Cory Miller and Pippin Williamson Discuss the Importance of Mental Health on Office Hours Podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52599\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:117:\"http://wptavern.com/cory-miller-and-pippin-williamson-discuss-the-importance-of-mental-health-on-office-hours-podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2006:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/heart.jpg\" rel=\"attachment wp-att-52604\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/heart.jpg?resize=1024%2C587\" alt=\"photo credit: rubryan\" class=\"size-full wp-image-52604\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/rubyran2626/2263837091/in/faves-57854010@N05/\">rubryan</a>
<p>In the latest episode of <a href=\"http://officehours.fm/\" target=\"_blank\">Office Hours</a>, a WordPress business podcast, host Carrie Dils interviewed <a href=\"https://ithemes.com/\" target=\"_blank\">Cory Miller</a> and <a href=\"https://pippinsplugins.com/\" target=\"_blank\">Pippin Williamson</a> to discuss the importance of personal wellness. The episode is titled &#8220;<a href=\"http://officehours.fm/podcast/95-2/\" target=\"_blank\">Taking Care of Your Business Means Taking Care of Yourself</a>&#8221; and the video is now available on OfficeHours.fm.</p>
<p>Both Miller and Williamson are successful WordPress entrepreneurs who have recently shared their experiences on maintaining mental health. In this interview Dils chats with the guests about stress and depression and how they can impact your business. They each share tips for how to recharge or &#8220;Go find your soul food,&#8221; as Williamson put it. The episode covers a broad range of topics that aren&#8217;t often discussed in the world of business:</p>
<ul>
<li>Extracting yourself from toxic relationships</li>
<li>Fear of failure/ fear of not working</li>
<li>Setting healthy boundaries</li>
<li>Taking breaks</li>
<li>Establishing a support team</li>
<li>Transparency with peers</li>
<li>Combatting negative thoughts</li>
<li>Finding a mentor</li>
</ul>
<p>If you are experiencing the unique pressures of entrepreneurship or struggling with maintaining your mental health, check out the <a href=\"http://officehours.fm/podcast/95-2/\" target=\"_blank\">latest episode of Office Hours</a> for some practical tips.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Mar 2016 05:25:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: WPForms Aims to be the Most Beginner Friendly Forms Plugin for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52516\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/wpforms-aims-to-be-the-most-beginner-friendly-forms-plugin-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9192:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsFeaturedImage.png\" rel=\"attachment wp-att-52594\"><img class=\"aligncenter size-full wp-image-52594\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsFeaturedImage.png?resize=817%2C261\" alt=\"WPForms Featured Image\" /></a></p>
<p><a href=\"https://wordpress.org/plugins/wpforms-lite/\">WPForms Lite</a> is a new plugin developed by <a href=\"https://profiles.wordpress.org/smub/\">Syed Balkhi</a> and <a href=\"https://profiles.wordpress.org/jaredatch/\">Jared Atchison</a> that aims to be the most beginner friendly form creation plugin in the market, &#8220;We made simple tasks EASY rather than letting the complex tasks define how hard simple will be,&#8221; Balkhi told the Tavern. I took the plugin for a test drive to see how easy it is to use.</p>
<h2>A Great Introduction</h2>
<p>Upon activation, a WPForms introduction screen is displayed. This screen provides information on how to create your first form and includes an embedded video explaining how. I had to watch the video a few times to follow along but overall it serves its purpose.</p>
<p>If video is not your thing, consider walking through the <a href=\"https://wpforms.com/docs/creating-first-form/\">step by step guide</a> on the WPForms website. Those who want to jump right in can do so by clicking the <strong>WPForms &gt; Add New</strong> link.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsIntroductionScreen.png\" rel=\"attachment wp-att-52581\"><img class=\"size-full wp-image-52581\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsIntroductionScreen.png?resize=1025%2C675\" alt=\"WP Forms Introduction Screen\" /></a>WPForms Introduction Screen
<h2>WPForm User Interface Forces You to Focus</h2>
<p>One of the first things I noticed is the user interface and how it appears over WordPress. It was shocking at first to see WordPress disappear but the team chose to use this interface to avoid being constrained with WordPress&#8217; user interface. After working with WPForms for more than an hour, I found myself enjoying the fact that the interface forced me to focus on creating my form.</p>
<p>WPForms ships with six different templates to handle the most common use cases. All templates except the Blank Form and the Simple Contact form require you to upgrade to the commercial version. I chose the simple contact form template.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormTemplates.png\" rel=\"attachment wp-att-52582\"><img class=\"size-full wp-image-52582\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormTemplates.png?resize=1025%2C559\" alt=\"WPForm Templates\" /></a>WPForm Templates
<p>The simple contact form template automatically adds a name, email, paragraph, and submit fields to the form. An important time saver that sets WPForms apart from other plugins is that, the fields are automatically flagged as required.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormSimpleContactFormTemplate.png\" rel=\"attachment wp-att-52583\"><img class=\"size-full wp-image-52583\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormSimpleContactFormTemplate.png?resize=1025%2C605\" alt=\"WPForm Simple Contact Form Template\" /></a>WPForm Simple Contact Form Template
<p>You can rearrange the fields by clicking and dragging them up or down. Rearranging fields is a breeze, doesn&#8217;t require a page refresh, and doesn&#8217;t bog down the browser. When clicking on a field, its properties are displayed on the left where you can configure its label, format, description, and whether or not its required.</p>
<p>Advanced options enable you to determine a field&#8217;s size, placeholder text, default values, and whether to hide the label or sub-labels. Switching between screens and configuring fields is a fast, straightforward process.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormFieldOptions.png\" rel=\"attachment wp-att-52584\"><img class=\"size-full wp-image-52584\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormFieldOptions.png?resize=1025%2C671\" alt=\"WPForm Field Options\" /></a>WPForm Field Options
<p>Once the fields are configured, you&#8217;ll want to click the Settings screen. This is where you can configure what happens when a visitor clicks the submit button. You can enable or disable email notifications and use smart tags to configure the form&#8217;s output. This version of WPForms Lite doesn&#8217;t have email templates but Balkhi says it&#8217;s something the team is working on.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormSmartTags.png\" rel=\"attachment wp-att-52585\"><img class=\"size-full wp-image-52585\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormSmartTags.png?resize=1025%2C489\" alt=\"WPForm Smart Tags\" /></a>WPForm Smart Tags
<p>Here is what the form&#8217;s output looks like in Thunderbird. Personally, I like Jetpack&#8217;s formatting style more but this could change once WPForms supports email templates.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormOutput.png\" rel=\"attachment wp-att-52586\"><img class=\"size-full wp-image-52586\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormOutput.png?resize=836%2C367\" alt=\"WPForm Output\" /></a>WPForms Output
<p>As a comparison, this is what Jetpack&#8217;s Contact Form module output looks like in Thunderbird. The text looks better and I appreciate the bold field names.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/JetpacksFormOutput.png\" rel=\"attachment wp-att-52588\"><img class=\"size-full wp-image-52588\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/JetpacksFormOutput.png?resize=809%2C310\" alt=\"Jetpack Contact Form Output\" /></a>Jetpack Contact Form Module Output
<p>WPForms battles spam using two different methods, honeypot and <a href=\"https://wpforms.com/docs/setup-captcha-wpforms/\">reCAPTCHA.</a> reCAPTCHA is a free,  <a href=\"https://www.google.com/recaptcha/intro/index.html\">anti-spam service</a> provided by Google. In order to use it with WPForms, you&#8217;ll need to sign up for an account and add your site key and secret key to WPForm&#8217;s settings page.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsSettingsPage.png\" rel=\"attachment wp-att-52590\"><img class=\"size-full wp-image-52590\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsSettingsPage.png?resize=1025%2C420\" alt=\"WPForms Settings Page\" /></a>WPForms Settings Page
<p>Once a form is configured and saved, adding it to a page is easy. Simply create a new page in WordPress and in the editor, click the Add Form button. A modal will pop up giving you the option to choose which form to add to the page. You can also choose whether to show the form&#8217;s title and description from this box. When a form is added to the page, WPForms puts a shortcode like [ wpforms id=&#8221;50582&#8243; ] into the content area.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormInsertUI.png\" rel=\"attachment wp-att-52592\"><img class=\"size-full wp-image-52592\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormInsertUI.png?resize=498%2C219\" alt=\"UI For Inserting a WPForm into a Page\" /></a>UI For Inserting a WPForm into a Page
<p>I configured WPForms to not apply styling to my form. However, you can choose whether WPForms applies base and form theme styling or base styling only. You&#8217;ll want to experiment with these options to see if your form looks any better with styles applied.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsTavernContactForm.png\" rel=\"attachment wp-att-52593\"><img class=\"size-full wp-image-52593\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/WPFormsTavernContactForm.png?resize=696%2C881\" alt=\"WPForms Contact Form on The Tavern Frontend\" /></a>WPForms Contact Form on The Tavern Frontend
<h2>My Verdict?</h2>
<p>You should know that outside of creating simple contact forms and what&#8217;s available via the standard fields, almost everything else requires you to upgrade to the commercial version, including the ability to store and view form entries in WordPress. However, the plugin doesn&#8217;t nag or annoy you with popups that a commercial version is available. Upgrade prompts are only triggered when trying to access a commercial feature.</p>
<p>After putting WPForms Lite through its paces, it&#8217;s definitely one of the easiest and fastest ways to set up a contact form. It&#8217;s clear by using the supplied templates that Balkhi and his team have considered common pitfalls and have done a great job eliminating them.</p>
<p>I haven&#8217;t looked into the contact form space in WordPress for a few years but after testing WPForms, I&#8217;m motivated to compare some of the most popular plugins in the space to see how each one tackles the user experience. Expect a detailed roundup in the next few weeks.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Mar 2016 02:05:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:123:\"WPTavern: Stack Overflow Survey Results Show WordPress is Trending Up, Despite Being Ranked Among Most Dreaded Technologies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52540\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:132:\"http://wptavern.com/stack-overflow-survey-results-show-wordpress-is-trending-up-despite-being-ranked-among-most-dreaded-technologies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7217:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/stack-overflow-developer-survey-2016.png\" rel=\"attachment wp-att-52554\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/stack-overflow-developer-survey-2016.png?resize=1025%2C462\" alt=\"stack-overflow-developer-survey-2016\" class=\"aligncenter size-full wp-image-52554\" /></a></p>
<p>Stack Overflow published the results of its <a href=\"https://stackoverflow.com/research/developer-survey-2016\" target=\"_blank\">2016 Developer Survey</a>, summarizing responses from 56,033 developers in 173 countries. The 45-question survey collected answers from more than twice as many developers as the previous year.</p>
<p>The results were published along with a disclaimer recognizing that the survey is &#8220;biased against devs who don&#8217;t speak English, or who don&#8217;t like taking English-language surveys.&#8221; Nevertheless, since the survey captured responses from such a large number of developers on a site that receives 40 million visitors per month, the results are definitely worth a read.</p>
<p>The average age of developers surveyed was 29.6 years old and 92.8% of the respondents were male. Most of them are at least partially self-taught (69%) with 45% of them having acquired degrees in computer science or a related field.</p>
<p>A quick developer profile of those surveyed shows that the largest section (28%) is made up of those who identify as a full-stack web developer.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/developer-profile.png\" rel=\"attachment wp-att-52557\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/developer-profile.png?resize=1025%2C490\" alt=\"developer-profile\" class=\"aligncenter size-full wp-image-52557\" /></a></p>
<h3>Developers Value Diversity</h3>
<p>Despite the fact that the vast majority of the respondents were male, the results indicate that developers value diversity. In summarizing 42,156 responses, Stack Overflow found the following:</p>
<blockquote><p>Overall, about 73% of developers tell us they think diversity is at least somewhat important in the workplace. 41% of developers say diversity is very important. And developers who most often influence hiring decisions are more likely to believe in the value of diversity than other developer types.</p></blockquote>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/diversity.png\" rel=\"attachment wp-att-52544\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/diversity.png?resize=1025%2C481\" alt=\"diversity\" class=\"aligncenter size-full wp-image-52544\" /></a></p>
<h3>Visual Basic and WordPress Top the List for Most Dreaded Technologies</h3>
<p>WordPress moved up one spot from last year in the ranking of <a href=\"https://stackoverflow.com/research/developer-survey-2016#technology-most-loved-dreaded-and-wanted\" target=\"_blank\">most dreaded technologies</a> that respondents would prefer not to use. This is not surprising given that the most popular tags for posts on Stack Overflow are JavaScript, Java, Android, and Python.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/most-dreaded.png\" rel=\"attachment wp-att-52546\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/most-dreaded.png?resize=1025%2C634\" alt=\"most-dreaded\" class=\"aligncenter size-full wp-image-52546\" /></a></p>
<p>On the other hand, when surveying the <a href=\"https://stackoverflow.com/research/developer-survey-2016#most-popular-technologies-per-occupation\" target=\"_blank\">most popular technologies per developer type</a>, WordPress is currently used by 24.1% of front-end developers. As a side note, this also corresponds roughly to its current <a href=\"http://w3techs.com/technologies/history_overview/content_management/all\" target=\"_blank\">market share</a> (26%).</p>
<h3>WordPress and JavaScript Technologies Are Trending Up</h3>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/trending-technologies.png\" rel=\"attachment wp-att-52548\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/trending-technologies.png?resize=1025%2C842\" alt=\"trending-technologies\" class=\"aligncenter size-full wp-image-52548\" /></a></p>
<p>Newer technologies like React, Node.js, and AngularJS are trending, with the above percentages representing the change in share of Stack Overflow votes between January 2015 and January 2016. All three are also among the <a href=\"https://stackoverflow.com/research/developer-survey-2016#technology-top-paying-tech\" target=\"_blank\">top-paying technologies</a> per occupation for both full stack and front-end developers.</p>
<p>It&#8217;s worth noting that all of these trending technologies are also becoming more readily integrated with WordPress, and will be more widely used when the REST API is finally merged with core.</p>
<p>Despite the fact that WordPress ranks second in the most dreaded technology category, it is also trending up 18.5% from 2015. According to these results, WordPress&#8217; popularity is increasing at a rate similar to that of many JavaScript-based technologies.</p>
<h3>Job Title and Remote Work Are Important Priorities for Experienced Developers</h3>
<p>The 2016 results found that 91% of developers surveyed worldwide are “gainfully employed” (full-time, self-employed, or freelance). Developers are in high demand, with just 15% of respondents actively looking for a job. It&#8217;s also interesting to note that 78% of developers surveyed are interested in exploring new employment opportunities.</p>
<p>If you&#8217;re trying to hire a developer, one of the most important things to consider is that they highly prioritize being able to work remotely. Responses from 49,521 developers indicate that as they gain more years of experience, both job title and remote work options are increasing priorities.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/priorities.png\" rel=\"attachment wp-att-52549\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/priorities.png?resize=1025%2C675\" alt=\"priorities\" class=\"aligncenter size-full wp-image-52549\" /></a></p>
<p>Only 30% of developers currently work remotely part-time or full-time, but Stack Overflow found that remote developers are more likely to love their jobs than other developers. If you own a company that hires developers, chances are that you will attract a larger, more experienced pool of applicants if employees are allowed to work remotely.</p>
<p>Developers who want to get a better understanding of the broader industry&#8217;s work challenges, salary expectations, and most popular technologies will want to review the full <a href=\"https://stackoverflow.com/research/developer-survey-2016\" target=\"_blank\">results of the survey</a>.</p>
<p>The document includes some important feedback for the WordPress community to consider. Although WordPress is among the technologies that are trending up, the broader development community still does not seem to enjoy working with it. How can we make the software more developer-friendly without compromising user friendliness?</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2016 21:57:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: WPWeekly Episode 226 – Burnout\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=52552&preview_id=52552\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"http://wptavern.com/wpweekly-episode-226-burnout\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2888:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I discuss the symptoms of burnout and share tips on how to prevent it. We provide a status update on WordPress 4.5 and discuss my experience hooking up a site to Apple News Publisher. To round out the show, Marcus shares his experience using Shopify&#8217;s new WordPress plugin.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/when-contributing-to-wordpress-full-time-leads-to-burnout\">When Contributing to WordPress Full-Time Leads to Burnout</a><br />
<a href=\"http://wptavern.com/wordpress-global-translation-day-set-for-april-24-2016\">WordPress Global Translation Day Set for April 24, 2016</a><br />
<a href=\"http://wptavern.com/tickets-for-wordcamp-jacksonville-2016-now-on-sale\">Tickets for WordCamp Jacksonville 2016 Now on Sale</a><br />
<a href=\"http://wptavern.com/how-to-connect-your-wordpress-powered-site-to-apple-news-publisher\">How to Connect Your WordPress Powered Site to Apple News Publisher</a><br />
<a href=\"http://wptavern.com/shopify-launches-official-plugin-for-wordpress\">Shopify Launches Official Plugin for WordPress</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/shopify-ecommerce-shopping-cart/\">Shopify</a> is an eCommerce plugin for WordPress that makes selling products on your site simple. In just a few clicks, you can create a Buy Button that lets visitors securely checkout from any page on your site.</p>
<p><a href=\"https://wordpress.org/plugins/woomaxmin/\">WooMaxMin for WooCommerce </a>gives you the ability to set up minimum and maximum purchase limits for your customers.</p>
<p><a href=\"https://wordpress.org/plugins/lifterlms-wpmktgengine-extension/\">LifterLMS &#8211; WPMKTGENGINE Extension </a>allows you to automatically track all of the participation within a LifterLMS installation from your WPMktgEngine customer database. You can use this information to incorporate their participation with courses and memberships along with other activity information to target messages, create new products that will hit the mark, and build tighter and trusting relationships with customers.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 23rd 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #226:</strong><br />
</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2016 21:05:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: Saving the Open Web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46383\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ma.tt/2016/03/saving-the-open-web/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:230:\"<p><a href=\"http://buytaert.net/can-we-save-the-open-web\">Dries Buytaert asks &#8220;Can we save the open web?&#8221;</a> and makes an amazing case for why we should. I agree with and endorse basically everything in that post.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2016 14:39:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"WPTavern: Fight for the Future Launches “Save Security” Campaign in Support of Apple\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52486\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/fight-for-the-future-launches-save-security-campaign-in-support-of-apple\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3063:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/save-security.png\" rel=\"attachment wp-att-52525\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/save-security.png?resize=1025%2C456\" alt=\"save-security\" class=\"aligncenter size-full wp-image-52525\" /></a></p>
<p><a href=\"https://www.fightforthefuture.org/\" target=\"_blank\">Fight for the Future</a>, a non-profit organization that works to preserve freedom of expression on the web, launched its new &#8220;<a href=\"https://savesecurity.org/\" target=\"_blank\">Save Security</a>&#8221; campaign today in support of Apple. The FBI has requested that the company hack into an iPhone recovered from one of the terrorists involved in the <a href=\"https://en.wikipedia.org/wiki/2015_San_Bernardino_attack\" target=\"_blank\">San Bernardino mass shooting</a> to assist in the criminal investigation.</p>
<p>Apple has refused numerous court orders to create a new tool that would allow the government to circumvent the iPhone&#8217;s security measures that protect the encrypted communications of private individuals. The company will go to court on March 22nd for hearing in Riverside, CA. Fight for the Future plans to display thousands of statements in support of Apple from Internet users outside the courthouse.</p>
<p>The Save Security campaign website summarized what is at stake with the government forcing Apple to weaken its encryption:</p>
<blockquote><p>In its attacks on Apple, the FBI is seeking a legal precedent that would let them force any company to weaken the security of its products. Engineers use consumer products like the iPhone to maintain the most sensitive systems on the planet. Hospitals. Air traffic control. Nuclear power. What the FBI is asking for puts lives at risk, by undermining security everywhere.</p></blockquote>
<p>Two weeks ago, Automattic <a href=\"https://transparency.automattic.com/2016/03/03/automattic-and-wordpress-com-stand-with-apple-to-support-digital-security/\" target=\"_blank\">announced</a> that it stands with Apple to support digital security. The company <a href=\"https://cloudup.com/iZG9vzAV3U3\" target=\"_blank\">filed an amicus brief</a> in support of Apple alongside Cloudflare, Ebay, Kickstarter, Twitter, GitHub, Reddit, Square, and other leading technology companies.</p>
<p>&#8220;The fact is that if a security flaw exists, there is no way to ensure that only trusted governments, investigating a crime, can exploit that vulnerability,&#8221; Automattic&#8217;s attorney Paul Sieminski said in the announcement. &#8220;Improving security for everyone means aggressively finding and closing holes, not creating new ones.&#8221;</p>
<p>If you want to join in Fight for the Future&#8217;s campaign to support Apple, the <a href=\"https://savesecurity.org/\" target=\"_blank\">SaveSecurity.org</a> website offers a profile picture you can use as well as a website banner (see <a href=\"https://savesecurity.org/?ALWAYS_SHOW_SC_BANNER=true\" target=\"_blank\">live demo</a>) to raise awareness.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Mar 2016 22:56:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: How to Connect Your WordPress Powered Site to Apple News Publisher\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52502\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/how-to-connect-your-wordpress-powered-site-to-apple-news-publisher\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5623:\"<p>When Apple News Publisher <a href=\"http://www.apple.com/pr/library/2015/06/08Apple-Announces-News-App-for-iPhone-iPad.html\">launched in September, 2015</a>, it partnered with 20 publishers including, ESPN, The New York Times, and CNN. Today, publishers large and small are able to <a href=\"https://icloud.com/newspublisher\">sign up</a> to Apple&#8217;s <a href=\"https://developer.apple.com/news-publisher/\">News Publisher program</a> which delivers content from sites to devices running iOS 9 or above. Since its launch, the service has garnered more than <a href=\"http://9to5mac.com/2015/10/27/apple-news-40-million/\">40 million users</a>.</p>
<p>Aside from its user base, one of the main benefits to syndicating through News Publisher is that content is optimized across all of Apple&#8217;s iOS 9 devices, providing a better user experience as opposed to RSS readers that can render content unpredictably.</p>
<h2>Configuring Sites for News Publisher</h2>
<p>There are three options for publishers to push content to the service. You can use the content creation screen inside of News Publisher, connect an existing site using a plugin, or submit the URL to your site&#8217;s RSS feed.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/NewsPublisherContentAuthoring.png\" rel=\"attachment wp-att-52504\"><img class=\"size-full wp-image-52504\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/NewsPublisherContentAuthoring.png?resize=1025%2C544\" alt=\"News Publisher Content Creation Screen\" /></a>News Publisher Content Creation Screen
<p>I submitted the Tavern to News Publisher a few weeks ago and received a notification today that the site is approved. When submitting your site, you&#8217;ll need to give Apple your contact phone number and physical address. You&#8217;ll also need to upload a PNG logo that&#8217;s transparent, less than 2MB in size, and meets <a href=\"https://help.apple.com/newspublisher/icloud/#/apd7c9ae979c\">Apple&#8217;s logo guidelines</a>.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/PublisherSubmissionProcess2.png\" rel=\"attachment wp-att-52506\"><img class=\"size-full wp-image-52506\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/PublisherSubmissionProcess2.png?resize=837%2C652\" alt=\"News Publisher Submission Process\" /></a>News Publisher Submission Process
<p>If you use WordPress and your site is approved, consider using the <a href=\"https://wordpress.org/plugins/publish-to-apple-news/\">Publish to Apple News</a> plugin developed by <a href=\"http://www.alleyinteractive.com/\">Alley Interactive</a> and other contributing developers. Once installed, visit your channel&#8217;s administration page in News Publisher and click on the API Key link. This will give you the three things needed to connect your site.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/ChannelAPIInfo.png\" rel=\"attachment wp-att-52507\"><img class=\"size-full wp-image-52507\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/ChannelAPIInfo.png?resize=693%2C536\" alt=\"Channel API Information\" /></a>Channel API Information
<p>Login to your WordPress site and visit <strong>Settings &gt; Apple News</strong> and insert the following information into the corresponding fields. Since the field names and order don&#8217;t match, I created this short list.</p>
<ul>
<li>Channel ID &gt; API Channel</li>
<li>Key ID &gt; API Key</li>
<li>Secret &gt; API Secret</li>
</ul>
<p>From the settings screen, you can configure if the plugin should publish and update articles to Apple News automatically and whether to do it at the same time as WordPress in one action. You can also choose which Post Types are available. At the bottom of the screen, there are a host of design options that enable you to alter the display of how your articles look in Apple News.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/NewsPublisherOptionsPage.png\" rel=\"attachment wp-att-52508\"><img class=\"size-full wp-image-52508\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/NewsPublisherOptionsPage.png?resize=757%2C835\" alt=\"News Publisher Plugin Options Page\" /></a>News Publisher Plugin Options Page
<p>I don&#8217;t know what the Tavern&#8217;s content looks like on News Publisher as I wait for the initial series of posts to be approved. For the time being, the content is styled with the default settings.</p>
<h3>Monetizing Your Feed</h3>
<p>To monetize your News Publisher feed, enable iTunes connect with your developer ID. If you don&#8217;t have one, you&#8217;ll need to enroll in <a href=\"https://developer.apple.com/programs/enroll/\">Apple&#8217;s Developer Program </a>Once that&#8217;s complete, sign the Apple News Content Agreement and provide your tax and banking information on iTunes Connect. Note, that in order to <a href=\"https://help.apple.com/newspublisher/icloud/#/apdd44eeeeeb\">place ads</a> in your content, you need to publish articles from a CMS like WordPress.</p>
<h2>Is News Publisher Worth the Hassle?</h2>
<p>As a new publisher to Apple&#8217;s syndication system, it&#8217;s too early to tell if signing up was a waste of time or a benefit to readers. In the next week or two, I&#8217;ll report my findings, including feedback from Tavern readers on what they think of the format. Until then, you can subscribe to our channel by <a href=\"https://apple.news/TQYQeeBHDRce_JL3U0PCWGw\">opening this link</a> on a device that uses iOS 9 or later. If you subscribe to the Tavern, tell us about your experience in the comments.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Mar 2016 20:46:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Matt: Kat Hagan Works Differently\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46347\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://ma.tt/2016/03/kat-hagan-works-differently/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:246:\"<p><span class=\"embed-youtube\"></span></p>
<p>&nbsp;</p>
<p><a href=\"http://workdifferent.com/wdstories-kat-hagan-automatic/\">Kat Hagan is an engineer and a team lead at Automattic, and you can read all about her story that led her there</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Mar 2016 18:51:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: Dyad: A Beautiful Free WordPress Theme for Photographers and Foodies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52207\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/dyad-a-beautiful-free-wordpress-theme-for-photographers-and-foodies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2976:\"<p><a href=\"https://wordpress.org/themes/dyad/\" target=\"_blank\">Dyad</a> is the latest free theme release from the folks at Automattic. It was designed to suit creative websites, with written content and photographs receiving equal treatment.</p>
<p>The theme is actually a fork of <a href=\"https://wordpress.org/themes/receptar/\" target=\"_blank\">Receptar</a>, a theme by <a href=\"http://www.webmandesign.eu/\" target=\"_blank\">WebMan Design</a>. The original split-screen, book-like design for single posts was created to look like a modern cook book.</p>
<p>Automattic designers added a featured content slider to the homepage along with a sticky top navigation menu, among other changes. The featured tag can be set in the customizer. If you don&#8217;t want to use the slider, the theme will default to displaying the custom header image (which is set by adding a featured image to the page assigned as the static homepage).</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/dyad-screenshot.png\" rel=\"attachment wp-att-52479\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/dyad-screenshot.png?resize=660%2C683\" alt=\"dyad-screenshot\" class=\"aligncenter size-full wp-image-52479\" /></a></p>
<p>The homepage sports a grid layout for posts with featured images and excerpts side-by-side. Single posts display the featured image and title at 50% of of the screen with the content on the other half. The layout responds nicely for mobile devices.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/dyad-single-post-responsive.png\" rel=\"attachment wp-att-52495\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/dyad-single-post-responsive.png?resize=660%2C391\" alt=\"dyad-single-post-responsive\" class=\"aligncenter size-full wp-image-52495\" /></a></p>
<p>Dyad includes one expandable widget area in the footer. Any widgets dropped into this area will expand to fit one, two, three, or four columns. The footer also includes space for a social links menu with icons available for 26 different social accounts.</p>
<p>Check out a <a href=\"https://dyaddemo.wordpress.com/\" target=\"_blank\">live demo</a> of Dyad on WordPress.com to see the theme in action.</p>
<p>One consideration for using the theme is that you will always need to have large-sized feature images readily available to maintain the design. The optimal size is 1800px x 1280px. This shouldn&#8217;t be a problem for photography, cooking, portfolio, or other image-heavy sites. However, if your content is more text-oriented with a few scattered images, you may want to select a different theme.</p>
<p><a href=\"https://wordpress.org/themes/dyad/\" target=\"_blank\">Dyad</a> is Automattic&#8217;s 87th free theme release on WordPress.org. Full documentation for setting it up is available on the theme&#8217;s WordPress.com <a href=\"https://wordpress.com/themes/dyad/\" target=\"_blank\">homepage</a>.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Mar 2016 17:47:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: White House Seeks Feedback on GitHub for Government-Wide Open Source Software Policy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52437\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"http://wptavern.com/white-house-seeks-feedback-on-github-for-government-wide-open-source-software-policy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3710:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/white-house.jpg\" rel=\"attachment wp-att-52474\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/white-house.jpg?resize=1024%2C520\" alt=\"photo credit: The White House Washington DC - (license)\" class=\"size-full wp-image-52474\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/71380981@N06/19902559769\">The White House Washington DC</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc-nd/2.0/\">(license)</a>
<p>The White House is <a href=\"https://sourcecode.cio.gov/\" target=\"_blank\">calling for developers to comment</a> on its proposed draft for a Government-wide Open Source Software policy. In the request for public comment, the <a href=\"https://www.whitehouse.gov/omb/\" target=\"_blank\">White House Office of Management and Budget (OMB)</a> outlined two major goals for the new policy:</p>
<blockquote><p>This policy requires that, among other things: (1) new custom code whose development is paid for by the Federal Government be made available for reuse across Federal agencies; and (2) a portion of that new custom code be released to the public as Open Source Software (OSS).</p></blockquote>
<p>The pilot program proposed in the draft policy would require &#8220;covered agencies to release at least 20 percent of their newly-developed custom code, in addition to the release of all custom code developed by Federal employees at covered agencies as part of their official duties.&#8221;</p>
<p>Specifically, the government is asking for feedback on a list of considerations regarding releasing custom code as open source. A few examples include the following:</p>
<ul>
<li>To what extent is the proposed pilot an effective means to fuel innovation, lower costs, benefit the public, and meet the operational and mission needs of covered agencies?</li>
<li>Would a different minimum percentage be more or less effective in achieving the goals above?</li>
<li>To what extent could this policy have an effect on the software development market? For example, could such a policy increase or decrease competition among vendors, dollar amounts bid on Federal contracts, or total life-cycle cost to the Federal Government?</li>
<li>What opportunities and challenges exist in Government-wide adoption of an open source policy?</li>
</ul>
<p>Encouraging developers to produce reusable code to be shared across federal agencies could significantly lower development costs and improve government efficiency. It could also promote transparency of the code quality produced by vendors and employees.</p>
<p>After the embarrassing <a href=\"http://nymag.com/daily/intelligencer/2013/10/silicon-valley-reacts-to-healthcaregov.html\" target=\"_blank\">debacle of Healthcare.gov</a>, which cost taxpayers hundreds of millions of dollars, it&#8217;s good to see government embracing open source in an expanded capacity.</p>
<h3>How to Contribute</h3>
<p>You can join the conversation by participating in discussions on the <a href=\"https://github.com/whitehouse/source-code-policy/issues\" target=\"_blank\">source code policy GitHub issues</a> or by logging a new issue. The White House even welcomes changes and line edits to the policy content via <a href=\"https://github.com/whitehouse/source-code-policy/edit/gh-pages/pages/index.md\" target=\"_blank\">pull requests</a>.</p>
<p>Anyone can <a href=\"https://github.com/WhiteHouse/source-code-policy\" target=\"_blank\">contribute on GitHub</a> to help shape the federal source code policy until April 11, 2016. At that time public contributions will be closed and the White House will analyze feedback while creating the final policy.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Mar 2016 22:54:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WPTavern: Shopify Launches Official Plugin for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52450\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"http://wptavern.com/shopify-launches-official-plugin-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2620:\"<p>Shopify <a href=\"https://www.shopify.com/blog/113145925-introducing-shopify-for-wordpress\" target=\"_blank\">announced</a> today that the company is jumping into the WordPress market with a new official plugin and three WordPress themes. The Canadian company captures just <a href=\"https://wappalyzer.com/categories/ecommerce\" target=\"_blank\">8% of the e-commerce technology market share</a>, trailing WooCommerce (31%), Magento (19%), OpenCart (11%), Prestashop (10%), and others (13%).</p>
<p>The new <a href=\"https://github.com/Shopify/buy-button-wordpress\" target=\"_blank\">Shopify Buy Button</a> plugin is intended for users who already have a business set up on WordPress and are only looking to sell a few products with a buy button, as opposed to a full-fledged store. It allows users to sell products that have already been added to their Shopify stores and requires a $9/month Shopify Lite subscription.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/shopify-wp.gif\" rel=\"attachment wp-att-52463\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/shopify-wp.gif?resize=975%2C549\" alt=\"shopify-wp\" class=\"aligncenter size-full wp-image-52463\" /></a></p>
<p>Shopify partnered with Themezilla, Themify, and Ultralinx to build Shopify-powered WordPress themes. The themes are only free to download for a limited time, which leaves users without updates unless they purchase the theme from the commercial provider.</p>
<p>The corresponding plugin is currently hosted on GitHub but is in the process of being reviewed for WordPress.org, according to product representative Daniel Patricio.</p>
<p>&#8220;Many users have already been using it through the themes for a couple weeks now so we just wanted to get it out there to the rest of our users,&#8221; Patricio said. &#8220;We are in the review cycle to get it listed and should be up shortly where people will be able to get updates as we add features.&#8221;</p>
<p>It is not advisable to use or install the plugin until it is hosted on WordPress.org, as Shopify currently has no way to deliver security updates to users. It is unclear why the company chose to officially launch its new WordPress integration without updates in mind, but this is a major concern. If a vulnerability were discovered, the company has no straightforward way to alert people who have downloaded the plugin from GitHub.</p>
<p>When asked for an ETA for the plugin&#8217;s arrival on WordPress.org, Patricio said, &#8220;We don&#8217;t have a timeline yet but will be getting it up there soon.&#8221;</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Mar 2016 19:23:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"Matt: What’s in My Bag, 2016 edition\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46172\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://ma.tt/2016/03/whats-in-my-bag-2016-edition/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12982:\"<p>Many people have been requesting an update to <a href=\"https://ma.tt/2015/01/whats-in-my-bag-2014/\">my what&#8217;s in my bag post from last year</a>. Almost every single item in the bag has changed, this year has had particularly high turnover. We&#8217;re <a href=\"https://ma.tt/2015/05/macbook-usb-c-review/\">still in a weird teenage period of USB-C adoption</a>, and I hope by next year to have many fewer non-USB-C or Lightning cables. Things with a asterisk * are the same from last year. Without further ado:</p>
<p><a href=\"http://i0.wp.com/ma.tt/files/2016/02/DSC_1387.jpg?ssl=1\"><img class=\"aligncenter size-full wp-image-46178\" src=\"http://i0.wp.com/ma.tt/files/2016/02/DSC_1387.jpg?w=604&ssl=1\" alt=\"\" /></a></p>
<ol>
<li><a href=\"http://shop.lululemon.com/products/clothes-accessories/men-bags/Mens-Cruiser-Backpack\">This is my favorite item of the new year, a Lululemon Cruiser backpack</a> that has a million pockets both inside and outside, and allows me to carry more stuff, more comfortably, and access it faster. Lululemon updates their products and designs every few months, but if you ever spot something like this online or in the store check it out. Hat tip on this one to <a href=\"http://roseinmidair.com/\">Rose</a>.</li>
<li><a href=\"http://www.amazon.com/gp/product/B00TX5YUCM\">A short Lightning + micro USB cable</a>, which is great for pairing with a battery pack. I sometimes carry a few of these around and give them away all the time, as &#8220;do you have a light?&#8221; has evolved to &#8220;do you have a charge?&#8221; in the new millenium.</li>
<li><a href=\"http://www.amazon.com/gp/product/B012V56D2A\">Short regular USB to USB-C cable</a>.</li>
<li><a href=\"http://www.amazon.com/gp/product/B000BX47X2\">Belkin Retractable Ethernet</a>. *</li>
<li>Anker <a href=\"http://www.amazon.com/gp/product/B0119OI9XU\">USB-C to USB-C cable</a>. Make sure to read the reviews when you buy these to get the ones that do the proper voltage. I can charge a Macbook with this, and the new Nexus 5x, directly from the battery pack or the #43 wall charger.</li>
<li><a href=\"http://www.amazon.com/gp/product/B000CDFYNS\">Mini-USB cable</a>, which I use for the odd older device (like a Nikon camera) that still does mini-USB (that older big one). Would love to get rid of this one.</li>
<li>A charge cable for #45, the Fitbit Charge HR. <a href=\"http://www.amazon.com/gp/product/B0142A96G2\">You can buy these cheap on Amazon</a>, and if you lose it you&#8217;re out of luck, so I usually keep a few at home and one in my bag.</li>
<li><a href=\"http://www.apple.com/shop/product/ME291AM/A/lightning-to-usb-cable\">This is my goldilocks regular lightning cable, not too long and not too short</a>, 0.5m.</li>
<li>A retractable micro-USB.</li>
<li><a href=\"http://www.apple.com/shop/product/MLA02LL/A/magic-mouse-2\">Apple Magic Mouse 2</a>, the new one that charges via Lightning, natch.</li>
<li>Way over to the right, <a href=\"http://www.muji.us/store/stationery/notebooks.html\">a small Muji notebook</a>.</li>
<li>This is a weird but cool cable, <a href=\"http://www.amazon.com/gp/product/B00T7BK9PY\">basically bridges USB to Norelco shavers</a>. I use a Norelco beard trimmer and for some reason all of these companies think we want to carry around proprietary chargers, this is a slightly unwieldy cable but better than carrying around the big Norelco power brick.</li>
<li>Lockpick set. *</li>
<li><a href=\"https://www.honest.com/bath-and-body/honest-organic-lip-balm-trio\">Lavender mint organic lip balm from Honest Co</a>, which I think I got for free somewhere.</li>
<li><a href=\"http://www.aesop.com/usa/skin-care/lip/rosehip-seed-lip-cream.html\">Aesop rosehip seed lip cream</a>, which I bought mostly for the smell, when it&#8217;s done I&#8217;ll probably switch to <a href=\"http://www.aesop.com/usa/skin-care/lip/avail-lip-balm.html\">their lip balm</a>. (I should do a cosmetics version of this for my dopp kit, it&#8217;s had lots of trial and error as well.) I love Aesop, especially t<a href=\"http://www.aesop.com/usa/body-care/cleanse/resurrection-aromatique-hand-wash-4.html\">heir Resurrection line</a>.</li>
<li><a href=\"http://www.amazon.com/Aveda-Blue-Oil-0-24-oz/dp/B0031KN9UE\">Aveda Blue Oil</a> that I find relaxing. *</li>
<li><a href=\"http://www.amazon.com/Apple-Thunderbolt-Cable-0-5-Meter-MD862LL/dp/B00WVDGZM6/\">Short thunderbolt to thunderbolt cable</a>, which is great for transferring between computers. *</li>
<li>Muji international power adapter, much simpler, lighter, and cooler than what I used before.</li>
<li>Way on the top right, this is probably the least-travel-friendly thing I travel with, but the utility is so great I put up with it. It&#8217;s the <a href=\"http://www.amazon.com/gp/product/B00D4LBOV6\">Sennheiser Culture Series Wideband Headset</a>, which I use for podcasts, Skype, Facetime, Zoom, and Google Hangout calls with external folks and teams inside of Automattic. Light, comfortable, great sound quality, and great at blocking out background noise so you don&#8217;t annoy other people on the call. Worth the hassle.</li>
<li>A customized Macbook Pro 15&#8243;, in space grey, with the WordPress logo that shines through.</li>
<li><a href=\"http://www.amazon.com/Belkin-Car-Vent-Mount-Smartphones/dp/B00O5JARCI/\">Belkin car mount</a>, which is great for rentals. *</li>
<li>A <a href=\"http://www.amazon.com/gp/product/B00X8Z47XA\">USB 3.0 SD / CompactFlash / etc reader</a>.</li>
<li>microSD to SD adapter, with a 64gb micro SD in it. Good for cameras, phones, and occasionally transferring files. Can be paired with the card reader if the computer has a USB port but not a SD reader. <a href=\"http://www.amazon.com/dp/B010Q588D4/\">When you get a microSD card it usually comes with this</a>.</li>
<li>One of my new favorite things: <a href=\"http://www.dxo.com/us/dxo-one\">DxO One camera</a>. It&#8217;s a SLR-quality camera that plugs in directly to the lightning port on your iPhone, and can store the photos directly on your phone. Photo quality is surprisingly good, the only problem I&#8217;ve had with it is the lightning port pop-up will no longer close. The other similar device I tried but wasn&#8217;t as good was the <a href=\"http://www.getolympus.com/us/en/air-a01.html\">Olympus Air A01</a>, so I just carry around the DxO now.</li>
<li><a href=\"https://www.amazon.com/gp/product/B007PTCFFW/\">TP-LINK TL-WR702N Wireless N150 Travel Router</a>, which works so-so. Not sure why I still carry this, haven&#8217;t used it in a while. *</li>
<li><a href=\"http://www.amazon.com/gp/product/B018TGGH4E\">Aukey car 49.5W 3-port USB adapter</a>, which has two high-powered USB ports and a Quick Charge 3.0 USB-C port.</li>
<li>My favorite external battery right now, the <a href=\"http://www.amazon.com/gp/product/B019IFIJW8\">RAVPower 20100mAh Portable Charger</a>, also with Quick Charge 3.0 and a USB-C port. This thing is a beast, can charge a USB-C Macbook too.</li>
<li><a href=\"http://www.amazon.com/High-Resolution-Display-Adaptive-PagePress-Sensors/dp/B00IOY8XWQ\">Kindle Voyage</a> with the <a href=\"http://www.amazon.com/Limited-Edition-Premium-Leather-Origami/dp/B00NO84J0W\">brown leather cover</a>. *</li>
<li>Macbook power adapter.</li>
<li>Very cool <a href=\"http://en-us.sennheiser.com/momentum-wireless-headphones-with-mic\">Sennheiser Momentum Wireless</a> headphones in ivory,customized with the WordPress logo. I&#8217;m testing this out as a possible gift for <a href=\"https://automattic.com/\">Automatticians</a> when they reach a certain number of years at the company. For a fuller review, <a href=\"https://ma.tt/2015/04/best-headphones-spring-2015-edition/\">see this post</a>.</li>
<li><a href=\"https://www.cotopaxi.com/products/waterbottle-white?variant=8128462529\">Cotopaxi water bottle</a> that I got for free at the <a href=\"https://sas.summit.co/\">Summit at Sea conference</a>. The backpack has a handy area to carry a water bottle, and I&#8217;ve become a guy who refills water bottles at the airport instead of always buying disposable ones.</li>
<li>Special cord for the #30 Momentum headphones.</li>
<li><a href=\"http://www.amazon.com/dp/B004C51HRY/\">Retractable 1/8th inch audio cable</a>. *</li>
<li><a href=\"http://www.amazon.com/dp/B00IYA2ZJW/\">Powerbeats 2 Wireless headphones</a> that I use for running, working out, or just going around the city.</li>
<li><a href=\"http://www.amazon.com/gp/product/B00E9W11QM\">Belkin headphone splitter</a>, for sharing audio when watching a movie on a plane. *</li>
<li><a href=\"https://www.google.com/chromecast/speakers/\">Chromecast audio</a>, which I&#8217;ve never used but it&#8217;s so small and light I carry it around just in case.</li>
<li><a href=\"https://www.google.com/chromecast/tv/\">Chromecast TV</a>, which I&#8217;ve also never used but also small and light and I&#8217;m sure it&#8217;ll come in handy one of these days.</li>
<li>Verizon iPhone 6s+, which is normal, but the new thing here is I&#8217;ve stopped carrying a wallet, and a separate phone case, and now carry this big &#8216;ol <a href=\"http://www.amazon.com/gp/product/B00VGDQRAW\">Sena Heritage Wallet Book</a>. At first I felt utterly ridiculous doing this as it feels GINORMOUS at first, but after it wore in a little bit, and I got used to it, it&#8217;s so freeing to only have one thing to keep track of, and it&#8217;s also forced me to carry a lot less than I used to in my wallet.</li>
<li>Maison Bonnet sunglasses. Hat tip to <a href=\"https://about.me/tonyconrad\">Tony</a>.</li>
<li>Stickers! <a href=\"http://wapuu.jp/\">Wapuu</a> and <a href=\"https://slack.com/\">Slack</a>.</li>
<li><a href=\"http://www.amazon.com/Blinks-Ultralight-Comfortable-Contoured-Blindfold/dp/B000WNX21Y/\">Bucky eye shades</a>, like an eye mask but has a curve so it doesn’t touch your eyes. I don’t use this often but when I do it’s a life-saver. *</li>
<li>My favorite USB wall plug, after trying dozens, is this <a href=\"https://www.amazon.com/gp/product/B00UWMCXD8/\">Aukey 30W / 6A travel wall charger</a>. I love the foldable plug, and it&#8217;s really fast.</li>
<li>I generally only have one wall charger, but temporarily carrying around this <a href=\"http://www.amazon.com/gp/product/B019C23ZGW\">Tronsmart 33W USB-C + USB charger with Quick Charge 3.0</a>, which can very quickly charge the battery or the Nexus, and a Macbook in a pinch. Hopefully will combine this and #42 sometime this year. One thing I really dislike about this item is the bright light on it, which I need to cover with tape.</li>
<li>The only pill / vitamin / anything I take every day: <a href=\"http://www.elysiumhealth.com/\">Elysium Health Basis</a>. I&#8217;m not an expert or a doctor, but read up on them and the research around it, pretty interesting stuff.</li>
<li><a href=\"https://www.fitbit.com/chargehr\">Fitbit Charge HR</a>. I gave up on my Apple Watch. I&#8217;ll probably try the Fitbit watch when it comes out. My favorite feature is the sleep tracking. Least favorite is the retro screen, and that it doesn&#8217;t always show the time.</li>
<li><a href=\"http://www.amazon.com/Sharpie-Permanent-Markers-Marker-32101PP/dp/B000XANH9S\">Double-sided sharpie (thick and thin point)</a> and a <a href=\"http://www.muji.us/store/pen-pencils.html\">Muji pen</a>.</li>
<li><a href=\"http://www.westoneaudio.com/index.php/products/hearing-protection/es49-custom-hearing-protection.html\">Westone ES49 custom earplugs</a>, for if I go to concerts or anyplace overly loud. *</li>
<li>Some index cards, good for brainstorming.</li>
<li>Passport. * As Mia Farrow said about Frank Sinatra, &#8220;I learned to bring my passport to dinner.&#8221;</li>
<li>Jetpack notebook, I like to have a paper notebook to take notes, especially in group or product meetings, because there isn&#8217;t the distraction of a screen.</li>
<li><a href=\"https://www.google.com/nexus/5x/\">Nexus 5x</a>, which is definitely one of the better Android devices I&#8217;ve had, paired with <a href=\"https://fi.google.com/\">Google Project Fi</a> phone / data service, which has saved me thousands of dollars with its $10/gb overseas data pricing. Since my iPhone is so huge, I tried to go for a smaller Android device. I always travel with both in case something happens to one phone, for network diversity, and as I said this has better international data pricing than Verizon.</li>
<li>Business card holder. *</li>
<li>Post-it notes.</li>
</ol>
<p>All in all 13 items stayed the same, the other 40 are new to this edition.</p>
<p><a href=\"http://i0.wp.com/ma.tt/files/2016/02/DSC_1387.jpg?ssl=1\"><img class=\"aligncenter size-full wp-image-46178\" src=\"http://i0.wp.com/ma.tt/files/2016/02/DSC_1387.jpg?w=604&ssl=1\" alt=\"\" /></a></p>
<p>That&#8217;s a wrap, folks! If you have any questions or suggestions please drop them in the comments. Once my <a href=\"https://ma.tt/2016/02/lent-this-year-buying-things/\">no-buying-things moratorium for Lent</a> is over I can start trying new things out again.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Mar 2016 17:24:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: Tickets for WordCamp Jacksonville 2016 Now on Sale\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52421\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"http://wptavern.com/tickets-for-wordcamp-jacksonville-2016-now-on-sale\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2514:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/wordcamp-jacksonville.png\" rel=\"attachment wp-att-52424\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/wordcamp-jacksonville.png?resize=1025%2C502\" alt=\"wordcamp-jacksonville\" class=\"aligncenter size-full wp-image-52424\" /></a></p>
<p>Florida hosts some of the most successful and longest-running WordCamps in the US with events in Miami, Orlando, and Tampa Bay. Jacksonville, the largest city in Florida with a population of more than 800,000, will be hosting its very first WordCamp. The event will be held April 16-17 downtown at the <a href=\"https://2016.jacksonville.wordcamp.org/location/\" target=\"_blank\">Florida State College</a> campus.</p>
<p>According to <a href=\"http://frankcorso.me/\" target=\"_blank\">Frank Corso</a>, lead organizer for the WordCamp and an organizer of the Gainesville WordPress Meetup, the team is planning for 250 attendees. The WordPress community in northern Florida is working together to make the event happen.</p>
<p>&#8220;One of the co-organizers is the organizer of the local WPjax meet-up group and another organizer is the organizer of another city&#8217;s WP meetup group,&#8221; Corso said. &#8220;A few of us started talking at WordCamp Miami 2015 and realized that we really wanted to have a local WordCamp in our area. So, we reached out some others in the Jacksonville area to see if there was enough demand for it. We received a large amount of support for it and decided to proceed.&#8221;</p>
<p>Last week the event&#8217;s organizers introduced the <a href=\"https://2016.jacksonville.wordcamp.org/2016/03/11/introducing-the-first-round-of-speakers/\" target=\"_blank\">first round of speakers</a>, which includes local tech entrepreneurs and WordPress community leaders from around Florida. The deadline for speaker applications has passed, but organizers are still looking for <a href=\"https://2016.jacksonville.wordcamp.org/2016/03/03/call-for-volunteers/\" target=\"_blank\">volunteers</a> and <a href=\"https://2016.jacksonville.wordcamp.org/2016/01/04/call-for-sponsors/\" target=\"_blank\">sponsors</a>.</p>
<p>WordCamp Jacksonville <a href=\"https://2016.jacksonville.wordcamp.org/tickets/\" target=\"_blank\">tickets</a> went on sale today, but there are only 250 available due to venue capacity. Follow <a href=\"https://twitter.com/WordCampJax\" target=\"_blank\">@WordCampJax</a> and the #wcjax hashtag on Twitter for all the latest news.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Mar 2016 22:34:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: When Contributing to WordPress Full-Time Leads to Burnout\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52409\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/when-contributing-to-wordpress-full-time-leads-to-burnout\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4014:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/BurnoutFeaturedImage.png\" rel=\"attachment wp-att-52418\"><img class=\"size-full wp-image-52418\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/BurnoutFeaturedImage.png?resize=657%2C333\" alt=\"Burnout Featured Image\" /></a><a href=\"http://www.flickr.com/photos/12480780@N05/24053903526\">Fireplace 4</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc-nd/2.0/\">(license)</a>
<p>As a distributed worker, one of the toughest obstacles I face is burnout. It&#8217;s one of the reasons I took a month off from all things WordPress. According to <a href=\"http://www.merriam-webster.com/dictionary/burnout\">Merriam-Webster</a>, burnout is, &#8220;the condition of someone who has become very physically and emotionally tired after doing a difficult job for a long time.&#8221; Once burnout sets in, it&#8217;s tough to recover without avoiding the job completely.</p>
<p>Drew Jaynes, WordPress core developer, describes how contributing to the WordPress project full-time <a href=\"http://werdswords.com/contributing-full-time-isnt-everyone/\">led to burnout</a>.</p>
<p>&#8220;Here’s the thing: burnout is a real struggle. And when you’re working on something full-bore, 100 percent of the time, and you burnout, there aren’t a lot of good options to help combat that except to keep pressing on and try to get your groove back,&#8221; Jaynes said.</p>
<p>Recognizing the signs that burnout is imminent is an important step towards avoiding it, &#8220;I typically realize I’m burned out when I basically lose interest in whatever thing I’d been previously passionate about. Burnout is the result of going at something too hard for too long. And then when you stop, getting started again is a struggle,&#8221; he said.</p>
<p>Jaynes realized it was time to move on from full-time contributing to something new after experiencing burnout three times in seven months. Although he will continue to contribute back to WordPress, it will be in a more limited role as he focuses on products.</p>
<h2>How Matt Mullenweg Avoids Burnout</h2>
<p>People combat burnout differently based on their individual circumstances. When asked <a href=\"https://www.producthunt.com/live/matt-mullenweg#comment-151645\">how he combats burnout</a> in an <a href=\"http://wptavern.com/highlights-from-matt-mullenwegs-qa-session-on-product-hunt\">Ask Me Anything segment</a> in September 2015, Matt Mullenweg, CEO of Automattic, responded:</p>
<blockquote><p>Everything is connected, so if one of ( health | diet | relationships | family | work | soul | creative outlet ) is running on empty for too long, it will impact the others and you might end up treating the symptom rather than the cause. Recovery always comes from the people around you who give you unconditional love and support, which I&#8217;ve been lucky to have since I was an infant.</p>
<p>To avoid it now I try to take small mini-breaks frequently, be that a ten minute meditation every day, jogging a few times a week, or taking a few days to recharge once a month. I find that&#8217;s better (and less stressful) than trying to do a big blow-out reset or vacation once a year. Conversely, a lot of times when people think I&#8217;m on vacation I&#8217;m actually working as much or more than when I&#8217;m at home, just from a more interesting location (often with fewer distractions). Funnily enough I&#8217;m more likely to actually take time off and unplug at home, and more likely to be working when in an exotic location.</p></blockquote>
<p>I work for a company that has an unlimited vacation policy. I took advantage of it by taking a month off to clear my mind to help me refocus and it worked wonders for my mental well-being. If you feel it&#8217;s necessary and your employer has a similar policy, don&#8217;t be afraid to ask for some time off to regroup. What do you do to combat burnout? Please share your advice in the comments.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Mar 2016 22:05:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Addicted to Distraction\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46355\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://ma.tt/2016/03/addicted-to-distraction/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:665:\"<blockquote><p>Addiction is the relentless pull to a substance or an activity that becomes so compulsive it ultimately interferes with everyday life. By that definition, nearly everyone I know is addicted in some measure to the Internet. It has arguably replaced work itself as our most socially sanctioned addiction. [&#8230;]</p>
<p>Denial is any addict’s first defense. No obstacle to recovery is greater than the infinite capacity to rationalize our compulsive behaviors.</p></blockquote>
<p>Oldie but goodie <a href=\"http://www.nytimes.com/2015/11/29/opinion/sunday/addicted-to-distraction.html?_r=2\">from the New York Times, Addicted to Distraction</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Mar 2016 18:57:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: WordPress Global Translation Day Set for April 24, 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=51996\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/wordpress-global-translation-day-set-for-april-24-2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4941:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/globe.jpg\" rel=\"attachment wp-att-29134\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/globe.jpg?resize=1024%2C499\" alt=\"photo credit: . Entrer dans le rêve - cc\" class=\"size-full wp-image-29134\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/tranbina/4765484383/\">. Entrer dans le rêve</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.0/\">cc</a>
<p>The WordPress Polyglots team is planning its first ever <a href=\"https://make.wordpress.org/polyglots/2016/03/02/wordpress-global-translation-day-april-24th-2016/\" target=\"_blank\">Global Translation Day</a> to be held April 24, 2016, in every timezone around the globe. The 24-hour translation sprint will start at dawn in the East and end in the West. In addition to translating strings, organizers are also looking to grow the translation teams and educate new translators. They have identified the following three goals for the event:</p>
<ul>
<li>Show people who are interested in translating WordPress in their language how to get involved</li>
<li>Translate and validate the waiting strings for current projects under the supervision of the current General translation editors</li>
<li>Add more general translation editors to different translation teams</li>
</ul>
<p>The Global Translation Day is an ambitious undertaking that involves coordinating a 24-hour live stream of tutorials about translating WordPress in different languages, as well as local, on-site contributor teams.</p>
<p>&#8220;Not very many people know how big the translation efforts around WordPress are, how dedicated our volunteer Translation Editors are to making sure we have quality, consistent software translations,&#8221; Polyglots contributor Petya Raykovska said. &#8220;We wanted the Global Translation Day to shed a bit of light on that and especially on the local teams.</p>
<h3>Growing the WordPress Platform by Making it More Internationally Accessible</h3>
<p>The Polyglots team is slowly chipping away at the world&#8217;s most widely spoken languages to provide core, theme, and plugin translations for users in their own languages.</p>
<p>&#8220;We have many languages that need a lot of help,&#8221; Raykovska said. &#8220;Our Japanese, German, French, Dutch, Spanish, Portuguese teams are amazing, these are active 100% translated locales,&#8221; she said. &#8220;But when it comes to plugin and theme translations, that’s where the demand is greatest.</p>
<p>&#8220;On the other hand, we have languages that need help for WordPress core. All the Indian languages can use a huge push, our African and Asian languages need help.&#8221;</p>
<p>The progress of each locale is tracked on the <a href=\"https://make.wordpress.org/polyglots/teams/\" target=\"_blank\">Translation Teams</a> page, displaying the percentage of strings translated for each.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/translations.png\" rel=\"attachment wp-att-52391\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/translations.png?resize=1025%2C395\" alt=\"translations\" class=\"aligncenter size-full wp-image-52391\" /></a></p>
<p>&#8220;Some of the biggest languages in the world are represented in this chart and if we got them to 100% that could have a huge impact on WordPress itself,&#8221; Raykovska said.</p>
<p>&#8220;If you remember the big jump WordPress did in 2011 and then in 2014, when international downloads surpassed English downloads, half of those international downloads were for Japanese,&#8221; she said.</p>
<p>&#8220;Now imagine what impact languages like Chinese, Hindi (and other Indian languages) and other languages in countries where English is not a default language, can have. The Global WordPress Translation day is about making WordPress accessible to more people and also about helping the platform’s growth,&#8221; Raykovska said.</p>
<p>The Polyglots are calling all multilingual contributors to join in the event. Raykovska reports that so far they have more than 60 teams committing to take part, with 10 mini-contributor days held locally and more incoming. The Polyglots are also planning to host remote events where local teams use their own Slack channels to onboard contributors and work on translations.</p>
<p>Contributors can choose from a number of ways to get involved. You can record a video in your language for the promotion clip, volunteer to do a live stream talk about translating WordPress into your language, organize a local contributor day, or get involved with the main organization.</p>
<p>If you have the language skills to participate in the translation sprint, it&#8217;s one of the easiest ways to start contributing to WordPress and help prepare the platform for its next major international leap. Join #polyglots on Slack to connect with the team.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Mar 2016 18:11:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Changelog Podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46350\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://ma.tt/2016/03/changelog-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:575:\"<p>I know a lot of people are on their way to SxSW right now, <a href=\"https://changelog.com/197/\">here&#8217;s a podcast I joined called The Changelog you can download and check out on the way there</a> (or back). It&#8217;s a bit more technical than the interviews I normally do, we talk about Javascript, Calypso, the philosophy of open source and WordPress, some of the thinking behind Automattic&#8217;s acquisitions, and my favorite programming books. I hope <a href=\"https://changelog.com/197/\">you can check it out</a>, Adam and Jerod did a great job on this one.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 12 Mar 2016 02:17:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"WPTavern: In Case You Missed It – Issue 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=52368&preview_id=52368\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"http://wptavern.com/in-case-you-missed-it-issue-4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6892:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png\" rel=\"attachment wp-att-50955\"><img class=\"size-full wp-image-50955\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/01/ICYMIFeaturedImage.png?resize=676%2C292\" alt=\"In Case You Missed It Featured Image\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/112901923@N07/16153818039\">Night Moves</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc/2.0/\">(license)</a>
<p>There&#8217;s a lot of great WordPress content published in the community but not all of it is featured on the Tavern. This post is an assortment of items related to WordPress that caught my eye but didn&#8217;t make it into a full post.</p>
<h2>Justin Tadlock Announces Simpler Pricing</h2>
<p>Justin Tadlock <a href=\"http://themehybrid.com/weblog/simpler-pricing-for-theme-designer-and-plugin-developer\">revamped his pricing</a> model for his <a href=\"http://themehybrid.com/plugins/plugin-developer\">Plugin Developer</a> and <a href=\"http://themehybrid.com/plugins/theme-designer\">Theme Designer</a> plugins. Based on two months of feedback, Tadlock removed the pricing tiers in favor of a single price. Both plugins are $90 and come with source files, one year of support, and access to the Theme Hybrid Slack channel.</p>
<p>Existing customers have already been upgraded and can take advantage of the new perks. What&#8217;s nice is that Tadlock is giving those who purchased the plugins for $125 a partial refund of $35 to make up the difference.</p>
<h2>Using WordPress to Break The Silence</h2>
<p>Mahangu Weerasinghe, who works at Automattic as a Happiness Engineer, <a href=\"http://heropress.com/essays/breaking-the-silence/\">published a fantastic essay</a> on HeroPress this week that describes how WordPress helped him break his silence. Weerasinghe suffers from stuttering and as a result, remained silent even if he had something to say. It&#8217;s an inspirational story and the best content I&#8217;ve read all week. There are many quotable spots in the post, but this is my favorite.</p>
<blockquote><p>There are a lot of things we cannot control in this world, many forces at work that we cannot even see. But, as members of this community, I think we can content ourselves with this thought:</p>
<p>Because of the GPL, and the way it works, WordPress will be available as a publishing platform for decades to come, and long after the next social network comes and goes, for as long as the Internet remains free and accessible, anyone with WordPress will be able to have their say.</p>
<p>What WordPress did for me, it can do for others. And that’s why we need to keep going.</p>
<p>Because every silence can be overcome.</p></blockquote>
<p>Congrats Weerasinghe on defeating the silence and helping others to do the same.</p>
<h2>Automattic Acquires Pressable</h2>
<p>Automattic has purchased the rest of Vid Luther&#8217;s common stock shares in Pressable and has effectively <a href=\"https://poststatus.com/automattic-pressable/\">acquired the company</a>. Chris Lauzon, a Happiness Engineer at Automattic, is the company&#8217;s interim CEO. Be sure to read Matt Mulleweng&#8217;s statement which clearly indicates to me that the company is not part of Automattic&#8217;s long-term interests.</p>
<h2>Matt Mullenweg in The Irish Times</h2>
<p>Ciara O&#8217;Brien <a href=\"http://www.irishtimes.com/business/technology/matt-mullenweg-how-wordpress-got-the-whole-world-blogging-1.2558828\">interviewed Matt Mullenweg</a> when he visited Dublin, Ireland to speak at an Irish Software Association event. It&#8217;s one of the better interviews I&#8217;ve read in recent memory and if you know Matt well enough, you can tell which parts of the interview he showed his sense of humor.</p>
<p>For example, when asked how he relaxes and switches off work mode, he responds &#8220;Well, this is lovely. We have tea and little cookies.” I can almost guarantee you that he chuckled while making that remark.</p>
<h2>Introvert Reviews Pressnomics</h2>
<p>Jeff Matson, who leads the documentation efforts for Rocketgenius, <a href=\"http://jeffmatson.net/realization-of-progress-and-success/\">documented</a> (pun intended) his experience at Pressnomics 4. Thanks to his involvement in the community the past few years, people recognized him and started conversations with him instead of the other way around.</p>
<blockquote><p>I’m the nerd with the thick glasses, overgrown beard, and a hoodie; the guy who lives in a rather small apartment, drives a Kia, and shops at outlet malls. To put it simply, I’m your typical every-day middle-class 20-something guy. Certainly not the typically targeted clientele for such a high level business-centric conference.</p></blockquote>
<p>Yet, he had a great time and strengthened relationships and created new ones with members of the community. As a friend, it&#8217;s great to see Jeff make large strides both in his professional and personal life.</p>
<h2>Co-Organizing WordCamp Miami</h2>
<p>David Bisset <a href=\"http://davidbisset.com/wordcamp-miami-2016-the-mega-review/\">shares his experience</a> co-organizing one of the largest WordCamps in the US. According to a recent tweet, the team is already making plans for WordCamp Miami, FL 2017.</p>
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">One of the reasons <a href=\"https://twitter.com/hashtag/wcmia?src=hash\">#wcmia</a> organization team is so great: post-conference planning meetups. 2017 planning has begun. <a href=\"https://t.co/NZF31TRNOj\">pic.twitter.com/NZF31TRNOj</a></p>
<p>&mdash; David Bisset (@dimensionmedia) <a href=\"https://twitter.com/dimensionmedia/status/708282526477979650\">March 11, 2016</a></p></blockquote>
<p></p>
<h2>Wapuu of the North!</h2>
<p>As a traditional part of this series, I end each issue by featuring a Wapuu design. For those who don&#8217;t know, Wapuu is the <a href=\"http://wapuu.jp/2015/12/12/wapuu-origins/\">unofficial mascot</a> of the WordPress project. St. Patrick&#8217;s day is right around the corner, so what better way to celebrate than with a Wapuu with Irish roots. Meet, The Wapuu of the North.</p>
<p>The Wapuu of the North was created by Peter of <a href=\"http://1440design.com/wordpress/branding-wordcamp-belfast/\" target=\"_blank\">1440 Design</a> for WordCamp Belfast, Ireland. This particular Wapuu has quite the head of hair!</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/belfast_wapuu.jpg\" rel=\"attachment wp-att-52005\"><img class=\"aligncenter size-full wp-image-52005\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/belfast_wapuu.jpg?resize=1000%2C1000\" alt=\"belfast_wapuu\" /></a></p>
<p>That&#8217;s it for issue four. If you recently discovered a cool resource or post related to WordPress, please share it with us in the comments.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 12 Mar 2016 01:24:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: OnePress: A Free Single-Page WordPress Theme Built with Bootstrap 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=51305\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/onepress-a-free-single-page-wordpress-theme-built-with-bootstrap-4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3001:\"<p>If you&#8217;re a fan of the scrolling single-page parallax style themes, <a href=\"https://wordpress.org/themes/onepress/\" target=\"_blank\">OnePress</a> is a new one on WordPress.org that may pique your interest. After less than a month in the official directory, it has already been installed on more than 3,000 websites. OnePress was developed by the folks at <a href=\"https://www.famethemes.com/themes/onepress/\" target=\"_blank\">FameThemes</a> using <a href=\"http://v4-alpha.getbootstrap.com/\" target=\"_blank\">Bootstrap version 4</a>. It is suitable for business, portfolio, and agency websites.</p>
<p>The theme features a full-screen background image with action buttons in the first major section. Scrolling further down reveals an about section, services, a video lightbox, an animated counter, team section, latest news, and contact form (powered by Contact Form 7).</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/onepress.png\" rel=\"attachment wp-att-52246\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/onepress.png?resize=1025%2C769\" alt=\"onepress\" class=\"aligncenter size-full wp-image-52246\" /></a></p>
<p>All of the sections can be easily configured in the customizer and each has design options such as overlay color and opacity, section titles and subtitles, number of columns, and more. You can elect to hide any of the sections that you don&#8217;t want to use.</p>
<p>Also, if you&#8217;re not a fan of the parallax animations, there are options to disable them per element or globally for all the animations in the theme. You can also disable the sticky header when scrolling.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/onepress-customizer.png\" rel=\"attachment wp-att-52356\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/onepress-customizer.png?resize=1025%2C374\" alt=\"onepress-customizer\" class=\"aligncenter size-full wp-image-52356\" /></a></p>
<p>OnePress includes controls in the customizer for setting social profiles in the footer. It also includes a setting for pasting in a MailChimp Action URL for a newsletter signup form.</p>
<p>Check out a <a href=\"http://www.famethemes.com/preview/?theme=OnePress\" target=\"_blank\">live demo</a> of OnePress and click the menu items or scroll to view all of the sections. You can also toggle through desktop, tablet, and mobile views. Its smooth responsiveness and mobile-friendly menu are powered by Bootstrap.</p>
<p>OnePress is an excellent example of how a single-page WordPress theme can be easily configurable via WordPress&#8217; native customizer. It is available for <a href=\"https://wordpress.org/themes/onepress/\" target=\"_blank\">download from WordPress.org</a> or via your admin theme browser. The OnePress homepage on FameThemes has thorough <a href=\"http://docs.famethemes.com/article/43-onepress-documentation\" target=\"_blank\">documentation</a> for setting up each of the sections.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Mar 2016 22:10:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: WordPress 4.5 Improves Comment Moderation Screens\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52295\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"http://wptavern.com/wordpress-4-5-improves-comment-moderation-screens\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6151:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/comments.png\" rel=\"attachment wp-att-28128\"><img class=\"aligncenter size-full wp-image-28128\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/comments.png?resize=984%2C455\" alt=\"comments\" /></a>Building on the momentum generated from the <a href=\"https://make.wordpress.org/core/2015/10/28/comment-object-and-query-features-in-4-4/\">WordPress 4.4 development cycle</a>, WordPress 4.5 includes a number of enhancements to comments. In a <a href=\"https://make.wordpress.org/core/2016/03/09/comment-changes-in-wordpress-4-5/\">post on the Make Core blog</a>, Rachel Baker explains the changes and what to expect.</p>
<p>&#8220;WordPress 4.5 includes several ancient bug fixes and a few enhancements in the Comments component. We have <a href=\"https://core.trac.wordpress.org/query?status=closed&component=Comments&milestone=4.5&group=resolution&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">closed 25 tickets</a>,&#8221; Baker said.</p>
<p>The biggest change users will notice are the design improvements to the comment moderation screen when clicking one of the available links in a comment moderation email. Instead of appearing as a large block of plain-text, comments are formatted as long as they contain the following HTML elements.</p>
<ul>
<li>A &#8211; Links</li>
<li>Abbr &#8211; Abbreviations</li>
<li>Acronym &#8211; Defines an acronym</li>
<li>B &#8211; Bold</li>
<li>Blockquote &#8211; Specifies a section that is quoted from another source</li>
<li>Cite &#8211; Defines the title of a work</li>
<li>Code &#8211; Defines a piece of computer code</li>
<li>Del &#8211; Defines text that has been deleted from a document</li>
<li>Em &#8211; Emphasizes text</li>
<li>I &#8211; Italicize</li>
<li>Q &#8211; Defines a short quotation</li>
<li>S &#8211; Specifies text that is no longer correct</li>
<li>Strike &#8211; Defines strikethrough text</li>
<li>Strong &#8211; Defines important text</li>
</ul>
<p>During testing, I noticed that in some cases, the text still appears in a large block as if the paragraph tag is ignored. I&#8217;ve already reported this issue to Baker who is looking into it. As you can see, the text that is bold, blockquoted, linked, and italicized, maintains its formatting on the moderation screen.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/CommentFormattingOnModerationScreen.png\" rel=\"attachment wp-att-52346\"><img class=\"size-full wp-image-52346\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/CommentFormattingOnModerationScreen.png?resize=1025%2C571\" alt=\"Formatted Text On The Comment Moderation Screen\" /></a>Formatted Text On The Comment Moderation Screen
<p>In addition to visual enhancements, an Edit Comment link was added to the bottom of the comment. In the future, it would be nice to edit a comment in place during the moderation flow, similar to how Quick Edit works, instead of navigating to a different screen. Other notable changes include:</p>
<ul>
<li>Updated message styles that match other screens.</li>
<li>The comment date is only wrapped in a link if the comment permalink exists.</li>
<li><code>#wpbody-content</code> is appended to comment moderation email links for accessibility.</li>
<li>The <code>rel=nofollow</code> attribute and value pair will no longer be added to relative or same domain links within <code>comment_content</code>.</li>
<li><code>WP_Comment_Query</code> now supports the <code>author_url</code> parameter.</li>
<li>The new <code>pre_wp_update_comment_count_now</code> filter allows you to bail out of updating the comment count for a given Post.</li>
</ul>
<h2>Maximum Comment Field Length</h2>
<p>Those who publish lengthy comments will be happy to know that in WordPress 4.5, &#8220;the comment fields will enforce the maximum length of each field’s respective database column with hardcoded attributes. The hardcoded limits can be adjusted to accommodate custom database schemas using the <code>comment_form_default_fields</code> filter,&#8221; Baker said. By default, the limits are as follows:</p>
<ul>
<li>Comment: 65525 characters</li>
<li>Name : 245 characters</li>
<li>Email: 100 characters</li>
<li>Url: 200 characters</li>
</ul>
<p>When comments are submitted in 4.5, they&#8217;ll be checked by the new <code>wp_get_comment_fields_max_lengths()</code> function and the <code>wp_get_comment_fields_max_lengths</code> filter. If a value is more than the limit, a <code>WP_Error</code> is displayed. If a user publishes a comment and sees an error page, they&#8217;ll be able to navigate back to their comment via a link rather than having to use their browser&#8217;s back button.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/CommentErrorNavigation.png\" rel=\"attachment wp-att-52347\"><img class=\"size-full wp-image-52347\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/CommentErrorNavigation.png?resize=724%2C354\" alt=\"Comment Error Page Navigation\" /></a>Comment Error Page Navigation
<p>It&#8217;s great that comments continue to receive attention, even if there&#8217;s a long way to go. Unfortunately, the ability to <a href=\"https://core.trac.wordpress.org/ticket/33717\">send a notification email when a comment is approved from moderation</a> was punted to a future release. I&#8217;m looking forward to reviewing plugins that allow users to easily configure the comment length limits as seen above. It would be nice to configure the limits so spammers see an error message because of their comment&#8217;s length rather than being placed into the moderation queue.</p>
<p>To see and test these improvements yourself, download and install <a href=\"https://wordpress.org/news/2016/03/wordpress-4-5-beta-3/\">WordPress beta 3</a> on a test site. If you think you’ve discovered a bug, please create a new post on the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta area</a> of the support forums. What do you think of these changes to comments in WordPress 4.5?</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Mar 2016 20:07:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"WPTavern: GitHub Now Supports Emoji Reactions for Pull Requests, Issues, and Comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52304\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"http://wptavern.com/github-now-supports-emoji-reactions-for-pull-requests-issues-and-comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3903:\"<p>Last month GitHub finally <a href=\"http://wptavern.com/github-responds-to-letter-from-open-source-project-maintainers\" target=\"_blank\">responded</a> to the <a href=\"http://wptavern.com/open-source-project-maintainers-confront-github-with-open-letter-on-issue-management\" target=\"_blank\">open letter on issue management</a> that has now been <a href=\"https://docs.google.com/spreadsheets/d/1oGsg02jS-PnlIMJ3OlWIOEmhtG-udTwuDz_vsQPBHKs/htmlview?usp=sharing&sle=true\" target=\"_blank\">signed</a> by nearly 2,000 open source project maintainers. GitHub officially apologized for the lack of communication and promised to add new features and iterate on the core experience.</p>
<p>Shortly after acknowledging the letter, GitHub <a href=\"http://wptavern.com/github-introduces-issue-and-pull-request-templates\" target=\"_blank\">introduced templates for issues and pull requests</a>, which allow project maintainers to guide contributors towards submitting more meaningful contributions.</p>
<p>One of the other major requests included in the open letter was a voting system to declutter +1&#8217;s from issues. While the +1&#8217;s constitute valuable feedback, maintainers need a better UI to help make these conversations easier to read.</p>
<p>GitHub has now answered this request by <a href=\"https://github.com/blog/2119-pull-request-and-issue-reactions\" target=\"_blank\">adding emoji reactions to pull requests, issues, and comments</a>. Emoji support is nothing new but organizing it into reactions helps keep comments more manageable:</p>
<blockquote><p>In many cases, especially on popular projects, the result is a long thread full of emoji and not much content, which makes it difficult to have a discussion. With reactions, you can now reduce the noise in these threads.</p></blockquote>
<p>Reactions are currently limited to six emoji that are commonly used in GitHub conversations:</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/github-reactions.gif\" rel=\"attachment wp-att-52312\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/github-reactions.gif?resize=917%2C359\" alt=\"github-reactions\" class=\"aligncenter size-full wp-image-52312\" /></a></p>
<p>Going forward, emoji reactions should make life easier for project maintainers, as they provide a quick way to assess consensus. If contributors embrace emoji reactions, the new feature can help maintainers gauge how widespread a bug is. They also serve to highlight the most helpful comments in a conversation.</p>
<p>Emoji reactions, which were also recently adopted by Slack and Facebook, are making their way into more applications as an alternative way of offering feedback. Path was one of the first social apps to offer reactions in 2012. Buzzfeed has taken the feature to a new level with the addition of gif reaction options at the end of articles:</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/buzzfeed-reactions.png\" rel=\"attachment wp-att-52327\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/buzzfeed-reactions.png?resize=1025%2C601\" alt=\"buzzfeed-reactions\" class=\"aligncenter size-full wp-image-52327\" /></a></p>
<p>A feature that was once limited to social networks is now changing communication in the workplace by facilitating conversations for large groups of people. While emoji reactions offer people more ways of expressing themselves, they can also serve as a metric, a gauge, and a voting system.</p>
<p>The new <a href=\"http://wptavern.com/new-feature-plugin-for-wordpress-adds-emoji-reactions-to-posts\" target=\"_blank\">Reactions feature plugin</a> for WordPress received no small amount of criticism when it was introduced earlier this week. Even if the plugin never reaches the proposal stage, the conversation about the value of emoji reactions in modern communication is worth having.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Mar 2016 16:10:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Matt: From Silence to Publishing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46343\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://ma.tt/2016/03/from-silence-to-publishing/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:722:\"<blockquote><p>My parents first noticed my stutter when I was three years old. For the longest time, I thought I would one day be rid of it. I went for speech therapy, I did fluency exercises, I prayed. But now, at age thirty, I’m fairly confident that it’s here to stay. [&#8230;]</p>
<p>Somehow, as I progressed through high school, the expectant pauses of those listening to me were more difficult to bear that the nicknames and name calling. Often, I would not speak up, even when I had something I wanted to say.</p>
<p>My default setting was silence.</p></blockquote>
<p><a href=\"http://heropress.com/essays/breaking-the-silence/\">Read the rest of Mahangu Weerasinghe&#8217;s story, Breaking the Silence</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 22:48:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"Post Status: Automattic has purchased a majority stake in Pressable\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=22262\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://poststatus.com/automattic-pressable/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5218:\"<p><a href=\"https://automattic.com\">Automattic</a> has purchased a majority stake in <a href=\"https://pressable.com/\">Pressable</a>, one of the earliest managed WordPress hosting companies, founded in 2010. They were first known as ZippyKid, and <a href=\"https://poststatus.com/zippykid-pressable/\">rebranded in 2013</a>.</p>
<p>Automattic was already a shareholder in Pressable, most recently as the primary investor of <a href=\"https://www.crunchbase.com/organization/pressable#/entity\">a $1.5 million round</a> in April of 2015.</p>
<p>Technically, Automattic purchased  common stock shares from Vid Luther, the CEO of Pressable. The monetary value of that common stock was, &#8220;enough to be debt free,&#8221; according to Vid. He owned about 37% of the company, or 4.5 million shares of 7 million shares of common stock (versus preferred shares). The company has also been in debt, reportedly close to $1 million worth.</p>
<p>Automattic is now the majority owner of Pressable, and since Vid sold his shares, this is effectively an acquisition, and Automattic will be able to set the direction of the company from now on. Chris Lauzon, a Happiness Engineer at Automattic, is the interim CEO. There are other smaller investors in Pressable whom maintain their shares in the company, and it&#8217;s unknown what those investors will do.</p>
<p>When I confirmed the exit with Vid, he said, &#8220;This is the best thing that I could have done for my family, or myself.&#8221; He was burning the candle at both ends, working twice as much as he wanted to be working, and wasn&#8217;t seeing the growth and success that he dreamed of for so many years. Pressable has always done okay in the managed WordPress market, but never outpaced quick-growth and heavily funded WP Engine, or the first entry to the market, Pagely. But Pressable has not been in a position of strength for a really long time.</p>
<p>Pagely, WP Engine, and Pressable were really the first three into the market of managed hosting &#8212; a market that now includes nearly every big name host. It&#8217;s fascinating to see the different directions they&#8217;ve gone since. WP Engine <a href=\"https://www.crunchbase.com/organization/wp-engine#/entity\">has raised</a> nearly $40 million over the years and gone for scale (Automattic also invested in their Series A), while Pagely has bootstrapped the whole way and really hit their stride in the last couple of years with a move to the higher end of the market. Dozens of managed hosting companies exist today.</p>
<p>The work these three companies put into the early managed market got the attention of the biggest players in the market, like GoDaddy and EIG (owner of BlueHost, HostGator, and many more). Pressable fought hard, and Vid&#8217;s exit from the company comes after a long road with many challenges.</p>
<p>Pressable has long been on Rackspace infrastructure, as Vid had relationships with them going back a long time; that infrastructure suffered <a href=\"http://wptavern.com/recent-pressable-outages-the-result-of-a-slow-loris-attack\">a few catastrophic outages</a> from attacks that cost Pressable quite a few customers in January 2015, stunting progress.</p>
<p>They nearly sold Pressable to WP Engine about two years ago, and decided against it at the 11th hour. The financing round last year was a period of rejuvenation for them, after a troubled period between the malicious attacks on their infrastructure and some internal issues, and the team was looking forward to new opportunities moving forward, including a potential focus on hosting catered for eCommerce with WordPress.</p>
<p>Speaking to an agency owner with clients at Pressable, they told me they believe they, &#8220;always struggled to find their voice and audience in a space that quickly filled up.&#8221; I agree with the observation.</p>
<p>Pressable&#8217;s revenues were under $2 million per year, and they have a team of about 10 people. Vid is no longer at the company; his last day was March 7th. It remains to be seen exactly what direction Automattic will take the company, though I presume it will continue business as usual for now, like they did <a href=\"https://poststatus.com/automattic-acquired-woocommerce-woothemes/\">after the WooThemes acquisition</a>. While Automattic now owns the company, Matt Mullenweg made it clear to me that it&#8217;s not in their long term interest to be significantly involved in the traditional hosting business.</p>
<p>Matt Mullenweg gave the following statement about the purchase:</p>
<blockquote><p>Automattic is happy to be an investor in a number of WordPress-related companies and web hosts, and will continue to invest in the future. With Pressable we&#8217;ve unfortunately been forced to take a more active role to protect Pressable&#8217;s customers, employees, and our investment. Chris Lauzon, a Happiness Engineer at Automattic, has been temporarily working with the Pressable team to get everything in order, especially on the support side. Automattic continues to enjoy working with and supporting many great WordPress hosts, and we expect that Pressable will be able to operate fully independently in the future.</p></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 21:59:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Do the Woo: A New Podcast for WooCommerce Store Owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52197\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wptavern.com/do-the-woo-a-new-podcast-for-woocommerce-store-owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3266:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/podcast.jpg\" rel=\"attachment wp-att-52297\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2016/03/podcast.jpg?resize=960%2C472\" alt=\"photo credit: Maciej Korsan\" class=\"size-full wp-image-52297\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/IQVHQYS3GL\">Maciej Korsan</a>
<p>Bob Dunn, a WordPress educator better known on the web as <a href=\"https://bobwp.com/\" target=\"_blank\">BobWP</a>, is <a href=\"http://dothewoopodcast.com/welcome-to-do-the-woo-the-podcast-for-woocommerce-shop-owners/\" target=\"_blank\">launching a podcast for WooCommerce store owners</a>. &#8220;Do the Woo&#8221; will air weekly on Wednesdays with tips and tricks to help store owners attract more customers. Dunn plans to host guests involved in WooCommerce development, as well as store owners who will be invited to share their challenges and successes.</p>
<p>After using WooCommerce for five years with client projects, as well as his own products, Dunn is prepared to share his store management experience with listeners. He&#8217;s used the plugin and many of its extensions for selling services, bookings, downloads, and currently for his membership site sales. He has also taught WooCommerce workshops and is preparing new courses for his students.</p>
<p>Store owners are the targeted audience for Dunn&#8217;s new podcast with a focus on the business aspects of store management.</p>
<p>&#8220;It will be a mix of topics, rather than a straight interviews format, which is what many of the other podcasts are,&#8221; Dunn said. &#8220;I’ll be sharing eCommerce news and tips from a WooCommerce perspective. I’ll Interview Woo experts, designers, developers and shop owners. I’ll also share ideas for using Woo in ways that the average user might not have considered. There will be some tech, but also marketing, sales and social, all around WC.&#8221;</p>
<p>Dunn is aiming to reach both tech savvy users and those who would rather focus solely on the business of running a store.</p>
<p>&#8220;Having built sites for shop owners and in my role as co-organizer for the Seattle WooCommerce meetup, I would have to say that it’s a mix of technical skill,&#8221; he said. &#8220;As with anything WordPress, it spans the spectrum. Some are very hands-on and comfortable with the technology, while others want to focus more on their products and sales and tend to avoid the tech end of things.&#8221;</p>
<p>With an estimated 30% of e-commerce sites running on WooCommerce, a podcast focused on navigating the WooCommerce ecosystem as a store owner has a good chance of finding a decent audience with the right content strategy.</p>
<p>&#8220;My goal is to help these shop owners by giving them marketing ideas and providing a forum for stories from some of their colleagues who have insights and experiences to share,&#8221; Dunn said.</p>
<p>Interested listeners can subscribe at <a href=\"http://dothewoopodcast.com/\" target=\"_blank\">DoTheWooPodcast.com</a> where the first official episode will be published next week. Dunn will also be running WooCommerce-related posts on <a href=\"http://BobWP.com\" target=\"_blank\">BobWP.com</a> every Wednesday.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 21:27:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: WPWeekly Episode 225 – Interview With Scott Kingsley Clark Lead Developer of Pods\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=52290&preview_id=52290\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"http://wptavern.com/wpweekly-episode-225-interview-with-scott-kingsley-clark-lead-developer-of-pods\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2883:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I interview <a href=\"https://scottkclark.com/\">Scott Kingsley Clark</a>, lead developer of the <a href=\"http://pods.io/\">Pods framework</a> plugin. Clark explains the financial and organizational structure of the <a href=\"https://pods.io/friends-of-pods/\">Friends of Pods program</a> and how it benefits the plugin&#8217;s development.</p>
<p>He also explains what the <a href=\"https://github.com/sc0ttkclark/wordpress-fields-api\">Fields API project</a> is and its significance to WordPress. To make a long story short, it&#8217;s on par with the REST API&#8217;s inclusion in core. Last but not least, in a first for WordPress Weekly, Clark sings a song while strumming his Baritone Ukulele.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/custom-content-type-manager-plugin-update-creates-a-security-nightmare\">Custom Content Type Manager Plugin Update Creates a Security Nightmare</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/video-conferencing-with-zoom-api/\">Video Conferencing with Zoom API,</a> by <a href=\"https://profiles.wordpress.org/j_3rk/\">Deepen Bajracharya</a> from Nepal, gives you the power to manage Zoom Meetings from your WordPress dashboard. You can manage meetings, users, and display meetings in posts or pages using shortcodes.</p>
<p><a href=\"https://wordpress.org/plugins/timeline-diagram/\">Time Line Diagram</a>, by <a href=\"https://profiles.wordpress.org/md-shiddikur-rahman/\">Shiddikur Rahman, </a>is a responsive WordPress Plugin that allows you to create a beautiful vertical storyline. You simply create posts, assign images, a date, and then Time Line Diagram will automatically populate the posts in chronological order, based on the year and date.</p>
<p><a href=\"https://wordpress.org/plugins/easier-excerpts/\">Easier Excerpts,</a> by <a href=\"https://profiles.wordpress.org/tommcfarlin/\">Tom McFarlin </a>and <a href=\"https://profiles.wordpress.org/ericdye/\">Eric Dye</a> from PressWare, automatically expands and contracts the post&#8217;s excerpt to eliminate unnecessary white space.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 16th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #225:</strong><br />
</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 20:37:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: Jetpack 3.9.3 Maintenance Release Adds Compatibility for WordPress 4.5 Custom Logos\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52250\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"http://wptavern.com/jetpack-3-9-3-maintenance-release-adds-compatibility-for-wordpress-4-5-custom-logos\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2731:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/jetpack-logo.gif\" rel=\"attachment wp-att-27470\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/07/jetpack-logo.gif?resize=700%2C276\" alt=\"jetpack-logo\" class=\"aligncenter size-full wp-image-27470\" /></a></p>
<p><a href=\"http://jetpack.com/2016/03/10/jetpack-3-9-3-maintenance-and-compatibility-release/\" target=\"_blank\">Jetpack 3.9.3 and 3.9.4</a> are now available. Although 3.9.3 is billed as a &#8220;maintenance and compatibility release,&#8221; there are a number of significant changes and improvements that make this an important release.</p>
<p>WordPress 4.5 will introduce native <a href=\"http://wptavern.com/wordpress-4-5-to-introduce-native-support-for-a-theme-logo\" target=\"_blank\">support for a theme logo</a>. This will render Jetpack&#8217;s site logo feature obsolete. The 3.9.3 release of the plugin adds compatibility with WordPress 4.5 by ensuring that sites use core&#8217;s implementation for custom logos instead.</p>
<p>According to Konstantin Obenland in a recent <a href=\"https://make.wordpress.org/core/2016/03/10/custom-logo/\" target=\"_blank\">post</a> on make/core, &#8220;Jetpack will do a migration behind the scenes to work with it out of the box.&#8221; He also said that WordPress core&#8217;s new custom logo feature will use <a href=\"http://wptavern.com/customizer-responsive-preview-and-selective-refresh-to-be-merged-into-wordpress-4-5\" target=\"_blank\">Selective Refresh</a>, which means that the preview will load instantly after the image has been uploaded.</p>
<p>Notable enhancements in this release include:</p>
<ul>
<li>When using Carousel and Photon together, Jetpack will now link to the Photon version of full-sized images</li>
<li>Performance improvements to Comments, Infinite Scroll, Markdown, Publicize, Sitemaps, and the Subscription widget</li>
<li>Infinite Scroll: Introduced a later filter for settings</li>
<li>New filters in the Top Posts Widget code</li>
<li>oEmbed for Houzz.com</li>
</ul>
<p>The release also fixes an annoying bug in the Comments module that would reload the page when clicking &#8216;Reply.&#8217;</p>
<p>Jetpack 3.9.4 was released right on the heels of 3.9.3 to fix an issue where some comments were being displayed incorrectly. The problem was significant enough to push out an additional release right away.</p>
<p>Updating to the latest version of Jetpack will help your site work seamlessly with WordPress 4.5 when it is released the week of April 12. Check out the full <a href=\"https://wordpress.org/plugins/jetpack/changelog/\" target=\"_blank\">changelog</a> for both releases to see all of the enhancements and bug fixes.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 18:29:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: WordCamp Europe 2016 Expands Attendee Capacity to 2200, Largest WordCamp to Date\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52248\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"http://wptavern.com/wordcamp-europe-2016-expands-attendee-capacity-to-2200-largest-wordcamp-to-date\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2919:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/MuseumsQuartier.jpg\" rel=\"attachment wp-att-52255\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/MuseumsQuartier.jpg?resize=800%2C448\" alt=\"photo credit: rank.at\" class=\"size-full wp-image-52255\" /></a>photo credit: <a href=\"https://www.rank.at/en/blog-article/old-meets-new-in-the-heart-of-vienna-the-museumsquartier-vienna.html\">rank.at</a>
<p><a href=\"https://2016.europe.wordcamp.org/\" target=\"_blank\">WordCamp Europe 2016</a> is now on track to be the largest WordPress conference to date. The event, which will be held in Vienna June 24-26, has expanded its capacity to 2200 attendees (including micro-sponsors.) 400 additional tickets will be made available this week.</p>
<p><a href=\"http://wptavern.com/wordcamp-europe-2016-sold-out-organizers-working-to-get-more-venue-space\" target=\"_blank\">The first 1700 seats sold out</a> six months in advance, causing organizers to scramble to expand the venue capacity to meet the overwhelming demand for more tickets. They were able to secure three additional halls in the Leopold Museum and the Baroque suites of the MuseumsQuartier, all located within a minute&#8217;s walking distance of each other.</p>
<p>“With the camp happening in the city center, we wanted to make it easy for people to visit all the exquisite museums and sights in the area,&#8221; lead organizer Petya Raykovska said. As a bonus, conference goers will receive free access to the Leopold&#8217;s museum&#8217;s permanent exhibitions as part of their tickets.</p>
<p>WordCamp Europe will also be hosting the largest WordPress contributor day on record. Organizers are planning for 500 attendees and are considering using one of Vienna&#8217;s universities as the venue.</p>
<p>&#8220;We would have liked it to be in Leopold’s but unfortunately securing stable wifi for so many people in a museum is above our budget, so we’re looking for a venue that already has the infrastructure,&#8221; Raykovska said.</p>
<p>Current attendees represent 68 different countries, and the organizing team now includes members from 10 countries spanning both Eastern and Western Europe. The team would like to host a WordPress community summit for Europe but have not received confirmation for this year.</p>
<p>The host city for WordCamp Europe 2017 will be selected by the end of March. This will expand the organizing team for the current event, as future hosts will come on board to learn the ropes.</p>
<p>The next batch of <a href=\"https://2016.europe.wordcamp.org/tickets/\" target=\"_blank\">tickets</a> for the event will go on sale Friday, March 11th at 10 AM CET. In the meantime, the 250 people who signed up for the <a href=\"http://eepurl.com/bNsAUr\" target=\"_blank\">waiting list</a> will receive an email to claim their tickets first via a special reservation link.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Mar 2016 10:35:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Write CSS in the Customizer with the Advanced CSS Editor Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52194\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wptavern.com/write-css-in-the-customizer-with-the-advanced-css-editor-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3247:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/paint-brush.jpg\" rel=\"attachment wp-att-52240\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/paint-brush.jpg?resize=1024%2C538\" alt=\"photo credit: cutting in - (license)\" class=\"size-full wp-image-52240\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/10687935@N04/6021868900\">cutting in</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc/2.0/\">(license)</a>
<p>Last year WordPress developer <a href=\"http://www.hardeepasrani.com/\" target=\"_blank\">Hardeep Asrani</a> and the folks at <a href=\"http://themeisle.com/\" target=\"_blank\">ThemeIsle</a> released <a href=\"http://wptavern.com/customize-your-login-page-using-the-wordpress-customizer\" target=\"_blank\">Custom Login Customizer</a>, a plugin that allows users to design their own login pages in the customizer. Since that time core developers have made more progress on the customizer roadmap, allowing for more varied uses outside of a theme-related context.</p>
<p>Last week the ThemeIsle team debuted <a href=\"https://wordpress.org/plugins/advanced-css-editor/\" target=\"_blank\">Advanced CSS Editor</a>, a new plugin in its arsenal that demonstrates another exciting use for the customizer. It makes use of <a href=\"http://wptavern.com/customizer-responsive-preview-and-selective-refresh-to-be-merged-into-wordpress-4-5\" target=\"_blank\">postMessage transport</a> to offer live previews of CSS changes while a user is writing them in the customizer. The plugin also allows users to write CSS for different device screen sizes, including desktop, tablet, and mobile phones. The demo below shows a screen capture of the plugin in action on my test site:</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/edit-css.gif\" rel=\"attachment wp-att-52205\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/edit-css.gif?resize=924%2C558\" alt=\"edit-css\" class=\"aligncenter size-full wp-image-52205\" /></a></p>
<p>Seeing CSS edits updating in real time, instead of switching back and forth between a file editor and the frontend, was a refreshing experience. Having the ability to quickly write and preview media queries is also a convenient feature.</p>
<p>Although many core contributors are not fond of having a file editor in WordPress, the feature has yet to be removed. Using the Advanced CSS Editor plugin makes you wonder what the core file editor might look like in the customizer, at least for CSS files.</p>
<p>In the past, the customizer&#8217;s paint brush admin icon seemed like an ambitious stretch for a feature that, up until recently, felt clunky and slow to render previews. But recent advancements like <a href=\"https://make.wordpress.org/core/2016/02/16/selective-refresh-in-the-customizer/\" target=\"_blank\">selective refresh</a> will help to make the customizer provide a true live preview experience.</p>
<p>The <a href=\"https://wordpress.org/plugins/advanced-css-editor/\" target=\"_blank\">Advanced CSS Editor</a> plugin is a good example of how fast previews can be in the customizer and how much of a better experience it offers over similar plugins that require multiple clicks to refresh.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Mar 2016 23:13:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: Jetpack Turns 5 and Celebrates With a New Domain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52190\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wptavern.com/jetpack-turns-5-and-celebrates-with-a-new-domain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9574:\"<p>On this day in 2011, <a href=\"https://wordpress.org/plugins/jetpack/\">Jetpack</a>, the project formerly known as &#8220;.org connect&#8221; inside Automattic, was released to the public. At the time, the team consisted of five people. Today, there are more than 50 people on various teams within the project, including, support, user experience, growth, and development. It&#8217;s also active on more than 1 million sites.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/Jetpack11Interface.png\" rel=\"attachment wp-att-52213\"><img class=\"size-full wp-image-52213\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/Jetpack11Interface.png?resize=989%2C855\" alt=\"Jetpack 1.1 User Interface\" /></a>Jetpack 1.1 User Interface
<p>To celebrate the occasion, <a href=\"https://profiles.wordpress.org/professor44/\">Jesse Friedman</a>, Experience Advocate at Automattic, <a href=\"http://jetpack.com/2016/03/09/5-years-in-jetpack-is-soaring-higher-than-ever/\">shares four unique stories</a> from people who rely on Jetpack for their sites. The stories include a food blogger who uses 20 different modules, a developer who manages a number of sites, a new user who discovers the benefits of <a href=\"http://jetpack.com/support/photon/\">Photon</a>, and a convert who prefers Jetpack over clunky alternatives.</p>
<p>Jetpack&#8217;s support team is also celebrating its fifth birthday. According to Carolyn Sonnek, Happiness Rocketeer for Jetpack, the support team responded to over 93,000 support messages between email and the forums last year.</p>
<p>In addition to Jetpack&#8217;s birthday, the site&#8217;s domain has moved from Jetpack.me to Jetpack.com. Automattic <a href=\"http://www.thedomains.com/2015/12/09/automattic-com-owner-of-wordpress-acquires-jetpack-com/\">purchased the domain</a> in December 2015, from Jetpack Design of Santa Monica, CA. According to domain appraisal service <a href=\"http://www.estibot.com\">Estibot.com</a>, its <a href=\"http://www.estibot.com/appraise.php?a=appraisal&k=f818b525ed659fb84fdca10f05e64f47&domain=jetpack.com\">estimated value</a> is $51K.</p>
<h2>Interview With Jesse Friedman</h2>
<p>Friedman describes his journey working on Jetpack and shares what he&#8217;s learned since joining the team.</p>
<p><strong>How long have you been on the Jetpack journey and what&#8217;s it been like?</strong></p>
<p>I started using Jetpack in the Spring of 2012. I was working as the Director of Web Development at a web development and marketing company. I needed several different tools to round out the WordPress environment I was building to house a 2,000 site multisite that was growing by 50 sites a month.</p>
<p>All of us on the team agreed that Jetpack solved a lot of different needs for us in one convenient plugin. As developers, we loved the out of the box features like Sharing, Publicize, and Monitor, and our clients loved Stats.</p>
<p>In 2014, I left that company and joined up with the BruteProtect team. We worked hard to build a great security plugin that has been implemented on millions of websites. Later in 2014, we were excited to receive the news that we were joining the Jetpack team to continue BruteProtect as a Jetpack feature. Released last year, Jetpack Protect guards our users from malicious and brute force login attempts. It was truly something special to go from being a big fan of Jetpack to being on the team at Automattic.</p>
<p><strong>What are some things you have learned through Jetpack development that have benefited you in other areas?</strong></p>
<p>In the last 18 months, I’ve been doing a lot of work around the experience users have with Jetpack. Everything from individual features, to the connection process, to our website and how we communicate with our users. I’ve learned a lot about Jetpack and our community. The main thing being that, while Jetpack provides a lot of value to professionals and veterans, it is just<span class=\"copyonly\"> as</span><i></i>, if not more important for new users.</p>
<p><strong>Do you think Jetpack is a key component to WordPress reaching 50% market share?</strong></p>
<p>The WordPress community as a whole is growing so quickly. Hosts provide really simple tools to build a WordPress website with a single click or even no clicks at all. That means that WordPress and Jetpack have to be just as intuitive and work to improve the new user experience.<i class=\"copy_only\"></i></p>
<p>This is especially important when we consider growing WordPress&#8217; market share. I think everyone who builds something for WordPress, or publishes on WordPress, or organizes WordPress community events, are critical to growing to 50% or beyond.</p>
<p>Any WordPress tool or plugin that can help a user build their website faster while providing maintenance tools like Manage or security tools like Protect is going to play an important role in the growth of market share.</p>
<p>Jetpack specifically, is in a unique position because we can leverage the<span class=\"Apple-converted-space\"> </span><a href=\"http://wordpress.com/\" target=\"_blank\" rel=\"noreferrer\">WordPress.com</a><span class=\"Apple-converted-space\"> </span>infrastructure and network to build extremely powerful tools (like a global CDN) in an otherwise simple interface. Not to mention Jetpack’s popularity, it’s one of the most popular plugins across all of WordPress. Which is reinforced for me as I spend more and more time with our users, who are quite happy.</p>
<h2>Paid Services in Jetpack Remain at a Minimum</h2>
<p>Jetpack has come a long way since its inception but it&#8217;s interesting to look back at 2011 and review what some in the WordPress media world had to say about it. Ryan Imel, of WPCandy.com, <a href=\"http://wpcandy.com/thinks/jetpack-means-more-than-features-for-dot-org-users/\">looked into new opportunities for Automattic</a> as Jetpack provided a direct line into millions of self hosted sites.</p>
<blockquote><p>Jetpack is now a direct line in to WordPress.org Dashboards for Automattic. When (not <em>if</em>) Automattic releases a new software as a service, a simple update to Jetpack will bring that news in front of a serious number of WordPress.org users. This is a big step for Automattic, since up to now their reach has been mostly within the walls of WordPress.com. Now Jetpack is not only available for anyone to use, but it will come preinstalled with one-click installs of WordPress with a number of hosting providers.</p></blockquote>
<p><a href=\"http://jetpack.com/2011/03/09/blast-off/\">Jetpack&#8217;s goal</a> was to provide many of the useful features on WordPress.com to self-hosted users and while it does that, the business portion of the plugin can&#8217;t be ignored. Automattic owned services VideoPress and VaultPress are presented to millions of users who may otherwise not have known about them.</p>
<p>Today, Jetpack contains only two modules that require a paid subscription, VideoPress and VaultPress. So while it would be easy to increase Jetpack&#8217;s revenue generating capabilities by cramming it with commercial services and paid add-ons, Automattic has not done so.</p>
<p>At the end of the post, Imel asks a question that couldn&#8217;t be answered at the time, &#8220;In a large sense, what does Jetpack mean to the world of WordPress?&#8221; Fast forward five years later, we know that it&#8217;s a key component that&#8217;s helping <a href=\"http://wptavern.com/how-important-is-jetpack-on-wordpress-road-to-50-market-share\">WordPress move towards 50% market share</a>.</p>
<h2>Jetpack Pride</h2>
<p>The five year mark is a great milestone for any plugin and a great time to reflect. In Jetpack&#8217;s five year existence, Matt Mullenweg, WordPress co-founder, says what he&#8217;s most proud of, &#8220;I’m most proud of the fact that people who start using WordPress and Jetpack at the same time are more likely to be using WordPress a month later. It brings us closer to WordPress’ over-arching goal of democratizing publishing, giving users the ability to have the best of both worlds: open source and cloud.&#8221; Mullenweg said.</p>
<h2>Share Your Jetpack Story</h2>
<p>The Jetpack team is looking for feedback on how it&#8217;s saved you time, help you build websites faster, helped optimize your sites, etc. You can share your story by publishing it in the comments of this post or by using the <a href=\"https://twitter.com/search?q=%23JetpackTurns5&src=typd\"><strong>#JetpackTurns5</strong></a> hashtag on Twitter. One of my favorite stories so far is from Cécile Rainon who discovered WordPress through Jetpack and now works for Automattic.</p>
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Discovered WordPress through this plugin and I\'m now a proud Automattician! <a href=\"https://t.co/r0yCKYzqmI\">https://t.co/r0yCKYzqmI</a> via <a href=\"https://twitter.com/jetpack\">@jetpack</a> <a href=\"https://twitter.com/hashtag/jetpackturns5?src=hash\">#jetpackturns5</a></p>
<p>&mdash; Cécile (@cecile_rainon) <a href=\"https://twitter.com/cecile_rainon/status/707594514433753088\">March 9, 2016</a></p></blockquote>
<p></p>
<p>We use a number of modules to provide basic functionality such as contact forms, custom CSS, Likes, Protect, and more. In fact, every module except for five are activated on the Tavern. Using one plugin that handles a lot of the functionality we use on a daily basis is easier to maintain than using a number of separate plugins.</p>
<p>Happy birthday, Jetpack and here&#8217;s to five more!</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Mar 2016 22:02:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Matt: Jetpack Turns 5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=46331\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"https://ma.tt/2016/03/jetpack-turns-5/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:761:\"<p>Today the <a href=\"http://jetpack.com/2016/03/09/5-years-in-jetpack-is-soaring-higher-than-ever/\">Jetpack plugin turns five years old</a>. Who woulda thunk it? It&#8217;s one of the most popular plugins in WP history, and sites that include it as part of their WordPress install are more likely to to have engaged and active users &#8212; we&#8217;ve even seen it reduce churn on major web hosts. While there&#8217;s been a lot that&#8217;s happened in the Jetpack plugin so far, what&#8217;s around the corner has me even more excited. <img src=\"https://s.w.org/images/core/emoji/72x72/1f600.png\" alt=\"😀\" class=\"wp-smiley\" /> <img src=\"https://s.w.org/images/core/emoji/72x72/1f680.png\" alt=\"🚀\" class=\"wp-smiley\" /> P.S. Check out that new domain.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Mar 2016 14:27:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: WordPress 4.5 Adds Inline Editing to the Links Modal\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52174\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"http://wptavern.com/wordpress-4-5-adds-inline-editing-to-the-links-modal\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1777:\"<p>Today Andrew Ozz, one of the maintainers on <a href=\"https://make.wordpress.org/core/components/\" target=\"_blank\">WordPress&#8217; core Editor component</a>, announced some <a href=\"https://make.wordpress.org/core/2016/03/08/link-modal-wplink-changes-in-wordpress-4-5/\" target=\"_blank\">major improvements coming to the links modal</a> in the 4.5 release. Currently, when adding a link to text in the visual editor, a modal launches where you can paste in the URL, add link text, and set the target to open in a new window. The modal also expands to let you search for and link to existing content.</p>
<p>The TinyMCE link modal in WordPress 4.5 will allow for inline editing. It can actually detect when a user is entering a URL or attempting to search for one. The search uses jQuery UI Autocomplete, making it fast and easy to search through existing content. The gears icon launches the full modal with advanced options to set the target and title attribute.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/links-modal.gif\" rel=\"attachment wp-att-52178\"><img class=\"aligncenter size-full wp-image-52178\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/links-modal.gif?resize=838%2C496\" alt=\"links-modal\" /></a></p>
<p>The links modal improvements are the result of WordPress core contributor Ella Iseulde Van Dorpe&#8217;s work on a <a href=\"https://core.trac.wordpress.org/ticket/33301\" target=\"_blank\">ticket</a> opened to make this UI similar to the way Google Docs handles links. The experience of linking in the visual editor is now tighter and much more elegant and intuitive. This is one of the many small, yet impactful ways that WordPress is improving with each incremental release.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Mar 2016 00:34:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: New Feature Plugin for WordPress Adds Emoji Reactions to Posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52097\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"http://wptavern.com/new-feature-plugin-for-wordpress-adds-emoji-reactions-to-posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5822:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/emoji.jpg\" rel=\"attachment wp-att-52168\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/emoji.jpg?resize=1024%2C576\" alt=\"photo credit: Emoji - (license)\" class=\"size-full wp-image-52168\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/59525227@N08/25617662995\">Emoji</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">(license)</a>
<p><a href=\"http://pento.net/\" target=\"_blank\">Gary Pendergast</a> is looking to bring WordPress users a new way of giving feedback on posts that goes beyond simple text-based comments. A core committer and emoji aficionado, Pendergast spearheaded the effort to add <a href=\"https://make.wordpress.org/core/tag/emoji/\" target=\"_blank\">emoji support</a> to WordPress and is now working on an <a href=\"https://make.wordpress.org/core/2016/03/07/reactions/\" target=\"_blank\">emoji reactions feature plugin</a>.</p>
<p>The plugin is being developed to offer reactions that are similar to those available in Slack and Facebook.</p>
<p>&#8220;It works much the same way as a Like button, but provides a wider range of reactions so readers can give more nuanced feedback without needing to go to the effort of leaving a comment,&#8221; Pendergast said. &#8220;This also allows readers to provide the same level of interaction in situations where a &#8216;Like&#8217; is an inappropriate message to send, as Eric Meyer describes in his post about <a href=\"http://meyerweb.com/eric/thoughts/2014/12/24/inadvertent-algorithmic-cruelty/\" target=\"_blank\">Inadvertent Algorithmic Cruelty</a>.&#8221;</p>
<p>The <a href=\"https://wordpress.org/plugins/react/\" target=\"_blank\">Reactions plugin</a> is available on WordPress.org as a proof-of-concept with basic features:</p>
<ul>
<li>Allows for reactions to posts</li>
<li>REST API endpoints for storing and retrieving reactions</li>
<li>An exceedingly ugly emoji selector</li>
</ul>
<p>The plugin is under active development but those who want to get involved testing it early can log bugs on the project&#8217;s <a href=\"https://github.com/pento/react/issues\" target=\"_blank\">GitHub issues queue</a>. Reactions requires the <a href=\"https://wordpress.org/plugins/rest-api/\" target=\"_blank\">WP REST API</a> plugin. Once both are installed, you&#8217;ll see an emoji reactions button beneath the post content.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/reactions.png\" rel=\"attachment wp-att-52147\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/reactions.png?resize=1025%2C642\" alt=\"reactions\" class=\"aligncenter size-full wp-image-52147\" /></a></p>
<p>Clicking on the button will expand a panel of emoji reactions. The emoji picker UI is very basic but Pendergast is still investigating different options for display.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/reactions-expanded.png\" rel=\"attachment wp-att-52161\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2016/03/reactions-expanded.png?resize=1025%2C639\" alt=\"reactions-expanded\" class=\"aligncenter size-full wp-image-52161\" /></a></p>
<p>The post on the make/core blog immediately drew heated criticism and opposition. One of the more restrained reactions from <a href=\"https://make.wordpress.org/core/2016/03/07/reactions/#comment-29449\" target=\"_blank\">@chatmandesign</a> praises the idea for personal blogs but discourages its development beyond a plugin:</p>
<blockquote><p>I have to agree with what rapidly seems to be becoming the general consensus: Great idea for a plugin – if I ever setup my own personal blog, I might even use it – but I can’t imagine why this would be considered for Core. I would end up having to disable it on nearly every website I build, which are primarily business websites where this sort of goofy element would simply be inappropriate.</p></blockquote>
<p>Others commented that while it may not be a good candidate for core, having a canonical plugin for handling emoji reactions could be beneficial for the community.</p>
<p>Pendergast responded to critics by reiterating the casual exploratory nature of the project.</p>
<p>&#8220;Right now, it isn’t being considered for Core – it’s being explored as a possible feature in the future,&#8221; he said. &#8220;The idea still has to prove itself in terms of usefulness, usability, and general appeal. In terms of how close this is to landing in Core, it’s about the same as a new ticket being opened on Trac.&#8221;</p>
<p>Thanks in large part to mobile devices, emoji are now inescapable staples of modern communication for digitally connected people. Even so, the question of bringing emoji reactions into WordPress core may prove to be a deeply polarizing issue.</p>
<p>In one camp you have emoji fanatics who would go so far as to create a 25,000+ character <a href=\"http://www.huffingtonpost.com/2015/04/16/alice-in-wonderland-emoji_n_7066576.html\" target=\"_blank\">emoji translation of Alice in Wonderland</a>. On the other side are equally impassioned emoji haters who think the characters are unimaginative and that using emoji <a href=\"http://www.theguardian.com/commentisfree/2014/jun/18/adults-emoji-grow-up-emoticons-teenagers\" target=\"_blank\">perpetuates &#8220;linguistic incompetence&#8221;</a>.</p>
<p>If the Reactions feature plugin makes it to the core proposal stage, the WordPress community will be in for some interesting debates. If you want to get in on the fun of emoji reactions and lend a hand to the project, you can join the #feature-reactions channel in Slack. Development of the plugin will continue on <a href=\"https://github.com/pento/react\" target=\"_blank\">GitHub</a> and will be periodically pushed to WordPress.org.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Mar 2016 21:56:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"WP Mobile Apps: WordPress for Android: Version 5.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://apps.wordpress.org/?p=3213\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://apps.wordpress.com/2016/03/08/wordpress-for-android-version-5-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2038:\"<p>Hi WordPress users! <a href=\"https://play.google.com/store/apps/details?id=org.wordpress.android\" target=\"_blank\">Version 5.1 of the WordPress for Android app</a> is now available in the Google Play Store.</p>
<p>This version is a maintenance release. We squashed bugs in the Me, Reader, Comments, and Site Settings screens. Orientation changes and the virtual keyboard now behave consistently.</p>
<p>We also improved accessibility and navigation for blind and low vision users with better labeling and by adopting <a href=\"http://www.androidcentral.com/what-google-talk-back\">TalkBack</a>. </p>
<p>We would like to hear from users with disabilities: drop us a comment or join the beta test! Our testers have access to beta versions with updates shipped directly through Google Play. The beta versions may have new features, new fixes &#8212; and possibly new bugs! Testers make it possible for us to improve the overall app experience, and offer us invaluable development feedback. Want to become a tester? Please request access through our <a href=\"https://plus.google.com/communities/108813167297661427043\">Google+ Community</a>.</p>
<h1>Thank you</h1>
<p>A big thank you to the contributors who worked on this release: <a href=\"https://github.com/daniloercoli\">@daniloercoli</a>, <a href=\"https://github.com/hypest\">@hypest</a>, <a href=\"https://github.com/kwonye\">@kwonye</a>, <a href=\"https://github.com/maxme\">@maxme</a>, <a href=\"https://github.com/mzorz\">@mzorz</a>, <a href=\"https://github.com/nbradbury\">@nbradbury</a>, <a href=\"https://github.com/oguzkocer\">@oguzkocer</a>, <a href=\"https://github.com/rishabh7m\">@rishabh7m</a> and <a href=\"https://github.com/tonyr59h\">@tonyr59h</a>.</p>
<p>Track development progress for the next version by visiting <a href=\"https://github.com/wordpress-mobile/WordPress-Android/milestones/5.2\">our 5.2 milestone on GitHub</a>.</p><img alt=\"\" border=\"0\" src=\"https://pixel.wp.com/b.gif?host=apps.wordpress.com&blog=108068616&post=3213&subd=apps&ref=&feed=1\" width=\"1\" height=\"1\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Mar 2016 15:59:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Maxime\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Automattic Releases WordPress Plugin for Facebook’s Instant Articles\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=52069\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/automattic-releases-wordpress-plugin-for-facebooks-instant-articles\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5930:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/facebook-instant-articles-wordpress.jpg\" rel=\"attachment wp-att-52114\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2016/03/facebook-instant-articles-wordpress.jpg?resize=1025%2C577\" alt=\"facebook-instant-articles-wordpress\" class=\"aligncenter size-full wp-image-52114\" /></a></p>
<p>Today the WordPress.com VIP team <a href=\"https://vip.wordpress.com/2016/03/07/new-wordpress-plugin-for-facebook-instant-articles/\" target=\"_blank\">released</a> a plugin for Facebook&#8217;s <a href=\"https://instantarticles.fb.com/\" target=\"_blank\">Instant Articles</a>, which will be <a href=\"http://media.fb.com/2016/02/17/opening-up-instant-articles/\" target=\"_blank\">open to any publisher</a> starting April 12, 2016. Automattic partnered with Facebook and VIP-Featured-Partner agency <a href=\"https://en.dekode.no/?noredirect=en_US\" target=\"_blank\">Dekode</a> to produce a plugin that outputs a compliant feed of posts wrapped in the required markup for Facebook.</p>
<p>Instant Articles for WordPress is now <a href=\"https://vip.wordpress.com/2016/03/07/new-wordpress-plugin-for-facebook-instant-articles/\" target=\"_blank\">available on GitHub</a> and is also coming soon to the WordPress plugin directory.</p>
<p>Publishers must go through a review process to ensure that their posts are properly formatted and compliant before being allowed to push content via Instant Articles. Once approved, articles will load nearly instantly on mobile devices. According to Facebook, the speed is as much as 10 times faster than the standard mobile web.</p>
<p>&#8220;We had heard from a lot of WordPress publishers that they were eager to try out the Instant Articles program — based on the speed and user experience optimized for Facebook&#8217;s audience,&#8221; VP of Platform Services at Automattic Paul Maiorana said. &#8220;It&#8217;s still quite early, but we wanted to move quickly to ensure that WordPress and WordPress.com VIP publishers can take advantage of Instant Articles as soon as it opens up to everyone. And we were excited to work with Facebook to help make that happen.&#8221;</p>
<p>Facebook is working to create the best news feed on the web. More content delivered instantly means more advertising revenue for the social network. Publishers that make their content available via Instant Articles also have the opportunity to earn advertising revenue. If publishers sell their own ads, they get to keep 100% of the revenue. If they opt to use the Facebook Audience Network, they keep 70%.</p>
<p>Automattic&#8217;s open source Instant Articles plugin does not have built-in options for serving ads. According to Maiorana, further customization will be left up to the publishers.</p>
<p>&#8220;The new plugin is meant to be a starting point for publishers, from which they can customize design, advertising options, and which articles they choose to syndicate,&#8221; Maiorana said.</p>
<p>Instant Articles is not yet available to WordPress.com users, but Maiorana said that it&#8217;s something they will explore in the future.</p>
<h3>Instant Articles Is Geared Towards News Publishers</h3>
<p>You may be wondering if your brand or business should use the new plugin and start pursuing the approval process with Facebook. The current implementation of Instant Articles is not for everyone. A Facebook spokesperson told <a href=\"https://contently.com/strategist/2016/02/17/facebook-will-likely-open-instant-articles-to-brands-publishers-grandma/#footnote-1\" target=\"_blank\">Contently</a>:</p>
<blockquote><p>In April, Instant Articles will be open to any publishers that wish to join, but it is primarily designed for news publishers. While other types of publishers will have the option to create Instant Articles, in many cases there are other formats on Facebook that will better serve their needs.</p></blockquote>
<p>Facebook&#8217;s algorithm is likely to prioritize Instant Articles, as faster-loading articles are shared more often.</p>
<p>However, publishing to Instant Articles requires no small amount of technical skill, especially if you&#8217;re not already on a platform like WordPress that offers support via a plugin. Even with the help of Automattic&#8217;s plugin you still need to make a number of customizations to add branding and advertising while the underlying APIs are still in flux.</p>
<p>Publishers will need to decide how much control of their content they are willing to give up to Facebook in exchange for articles that load instantly. Funneling readers to Instant Articles hosted on Facebook has the potential to undermine direct mobile traffic. Facebook is also <a href=\"http://money.cnn.com/2016/02/04/technology/online-censorship-facebook-twitter/\" target=\"_blank\">notorious for its censorship</a>. What will Automattic&#8217;s response be to its partner if Facebook decides to censor WordPress publishers on its network? Maiorana wouldn&#8217;t directly answer this question.</p>
<p>&#8220;Our goal at WordPress.com VIP is to help publishers have the tools and the freedom to make their own decisions — and to move quickly in experimenting across platforms,&#8221; Maiorana said. &#8220;This is another new way for them to do that.&#8221;</p>
<p>New mobile publishing channels like Instant Articles and <a href=\"http://wptavern.com/automattic-adds-amp-support-to-wordpress-com-releases-plugin-for-self-hosted-sites\" target=\"_blank\">Google&#8217;s AMP project</a> require developer resources for publishers to get on board. Both of these tech giants are clawing for content distribution. They each have their own unique requirements that publishers will have to meet to in order to have their content found and prioritized. Each publisher will have to decide whether the improved speed, exposure, and/or ad revenue will be enough to make these efforts worthwhile.</p>
<div id=\"epoch-width-sniffer\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Mar 2016 21:30:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 25 Mar 2016 08:16:53 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:14:\"content-length\";s:6:\"233805\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Fri, 25 Mar 2016 08:00:16 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";s:13:\"accept-ranges\";s:5:\"bytes\";}s:5:\"build\";s:14:\"20160324152444\";}","no");
INSERT INTO `wp_options` VALUES("568","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1458937014","no");
INSERT INTO `wp_options` VALUES("569","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1458893814","no");
INSERT INTO `wp_options` VALUES("570","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1458937015","no");
INSERT INTO `wp_options` VALUES("571","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Mar 2016 07:59:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WooCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29860@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"W3 Total Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/w3-total-cache/#post-12073\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2009 18:46:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"12073@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:132:\"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Frederick Townes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"18101@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Regenerate Thumbnails\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 23 Aug 2008 14:38:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"6743@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"Allows you to regenerate your thumbnails after changing the thumbnail sizes.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Alex Mills (Viper007Bond)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Yoast SEO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8321@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2082@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"23862@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"Increase your traffic, view your stats, speed up your site, and protect yourself from hackers with Jetpack.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Duplicate Post\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/duplicate-post/#post-2646\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2007 17:40:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2646@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Clone posts and pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Lopo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"15@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Google Analytics by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2316@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"1169@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 14 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WP-PageNavi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wp-pagenavi/#post-363\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 23:17:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"363@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Adds a more advanced paging navigation interface.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Lester Chan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29832@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"The Wordfence WordPress security plugin provides free enterprise-class WordPress security, protecting your website from hacks and malware.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Hello Dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/hello-dolly/#post-5790\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 May 2008 22:11:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"5790@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2141@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"753@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"The most downloaded plugin for WordPress (almost 30 million downloads). Use All in One SEO Pack to automatically optimize your site for Search Engines\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"132@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25254@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Really Simple CAPTCHA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/really-simple-captcha/#post-9542\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Mar 2009 02:17:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"9542@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2572@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Page Builder by SiteOrigin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/siteorigin-panels/#post-51888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Apr 2013 10:36:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"51888@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Disable Comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/plugins/disable-comments/#post-26907\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 May 2011 04:42:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26907@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:134:\"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Samir Shah\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WP Multibyte Patch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Jul 2011 12:22:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"28395@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Multibyte functionality enhancement for the WordPress Japanese package.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"plugin-master\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"31973@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"50539@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"iThemes Security (formerly Better WP Security)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/better-wp-security/#post-21738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Oct 2010 22:06:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"21738@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"iThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Clef Two-Factor Authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/wpclef/#post-47509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Dec 2012 01:25:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"47509@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"Modern two-factor that people love to use: strong authentication without passwords or tokens; single sign on/off; magical user experience.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Dave Ross\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"UpdraftPlus Backup and Restoration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/updraftplus/#post-38058\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 May 2012 15:14:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38058@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Anderson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Duplicator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/duplicator/#post-26607\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 May 2011 12:15:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26607@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"Duplicate, clone, backup, move and transfer an entire site from one location to another.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Cory Lamle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Meta Slider\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/ml-slider/#post-49521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Feb 2013 16:56:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"49521@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Matcha Labs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:46:\"https://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 25 Mar 2016 08:16:55 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Fri, 25 Mar 2016 08:34:36 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Fri, 25 Mar 2016 07:59:36 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20160324152444\";}","no");
INSERT INTO `wp_options` VALUES("572","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1458937015","no");
INSERT INTO `wp_options` VALUES("573","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1458893815","no");
INSERT INTO `wp_options` VALUES("574","_transient_timeout_plugin_slugs","1459007049","no");
INSERT INTO `wp_options` VALUES("575","_transient_plugin_slugs","a:8:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:31:\"goods_catalog/goods_catalog.php\";i:2;s:9:\"hello.php\";i:3;s:35:\"rus-to-lat-advanced/ru-translit.php\";i:4;s:37:\"tinymce-advanced/tinymce-advanced.php\";i:5;s:39:\"tinymce-templates/tinymce-templates.php\";i:6;s:23:\"wordfence/wordfence.php\";i:7;s:27:\"wp-super-cache/wp-cache.php\";}","no");
INSERT INTO `wp_options` VALUES("576","_transient_timeout_dash_f69de0bbfe7eaa113146875f40c02000","1458937015","no");
INSERT INTO `wp_options` VALUES("577","_transient_dash_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2016/03/wordpress-4-5-release-candidate/\'>WordPress 4.5 Release Candidate</a> <span class=\"rss-date\">24.03.2016</span><div class=\"rssSummary\">The release candidate for WordPress 4.5 is now available. We’ve made 49 changes since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.5 on Tuesday, April 12, but we need your help [&hellip;]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/versions-of-wp-cli-prior-to-0-23-0-are-incompatible-with-wordpress-4-5\'>WPTavern: Versions of WP-CLI Prior to 0.23.0 Are Incompatible with WordPress 4.5</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wpweekly-episode-227-the-heropress-story-with-topher-derosia\'>WPTavern: WPWeekly Episode 227 – The HeroPress Story with Topher DeRosia</a></li><li><a class=\'rsswidget\' href=\'https://apps.wordpress.com/2016/03/24/wordpress-for-ios-version-6-0/\'>WP Mobile Apps: WordPress for iOS: Version 6.0</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Популярный плагин:</span> <a href=\'https://wordpress.org/plugins/google-analytics-dashboard-for-wp/\' class=\'dashboard-news-plugin-link\'>Google Analytics Dashboard for WP</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=google-analytics-dashboard-for-wp&amp;_wpnonce=62edb8f79d&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Google Analytics Dashboard for WP\'>Установить</a>)</span></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("584","_site_transient_timeout_browser_67bffb4457c7c00ae77275828881cb94","1459501869","yes");
INSERT INTO `wp_options` VALUES("585","_site_transient_browser_67bffb4457c7c00ae77275828881cb94","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"49.0.2623.87\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("589","_site_transient_timeout_theme_roots","1458921840","yes");
INSERT INTO `wp_options` VALUES("590","_site_transient_theme_roots","a:4:{s:9:\"ast_theme\";s:7:\"/themes\";s:14:\"twentyfourteen\";s:7:\"/themes\";s:14:\"twentythirteen\";s:7:\"/themes\";s:12:\"twentytwelve\";s:7:\"/themes\";}","yes");
INSERT INTO `wp_options` VALUES("591","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1458920635;s:7:\"checked\";a:4:{s:9:\"ast_theme\";s:3:\"1.0\";s:14:\"twentyfourteen\";s:3:\"1.2\";s:14:\"twentythirteen\";s:3:\"1.3\";s:12:\"twentytwelve\";s:3:\"1.5\";}s:8:\"response\";a:3:{s:14:\"twentyfourteen\";a:4:{s:5:\"theme\";s:14:\"twentyfourteen\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentyfourteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentyfourteen.1.6.zip\";}s:14:\"twentythirteen\";a:4:{s:5:\"theme\";s:14:\"twentythirteen\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentythirteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentythirteen.1.7.zip\";}s:12:\"twentytwelve\";a:4:{s:5:\"theme\";s:12:\"twentytwelve\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwelve/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwelve.1.9.zip\";}}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("592","_site_transient_timeout_browser_5ae30cdd14332a186c84b08c03075a6c","1459524872","yes");
INSERT INTO `wp_options` VALUES("593","_site_transient_browser_5ae30cdd14332a186c84b08c03075a6c","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"49.0.2623.87\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("594","_site_transient_timeout_available_translations","1458930923","yes");
INSERT INTO `wp_options` VALUES("595","_site_transient_available_translations","a:77:{s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-07 13:09:53\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-12 10:15:45\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-07 20:53:51\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-11 22:42:10\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 08:50:29\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-08 13:17:04\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-04 09:40:25\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-24 08:27:23\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-16 15:34:57\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-26 16:01:40\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 22:48:20\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 14:19:21\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-29 10:47:54\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-26 16:11:56\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.4.2/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-01 18:27:32\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-07 04:39:48\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-15 11:52:35\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-14 21:14:29\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 13:34:17\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-06 23:10:59\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-25 13:07:29\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-24 15:17:36\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_PE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-13 12:28:49\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_ES.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"es\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-09 18:08:52\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_GT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-23 00:46:01\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_AR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:6:\"4.3-RC\";s:7:\"updated\";s:19:\"2015-08-04 06:10:33\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.3-RC/es_CO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-02 20:27:44\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_CL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-13 06:14:13\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_VE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-07 17:35:10\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/es_MX.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-18 06:44:22\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-03 10:31:09\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-31 19:24:20\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-23 06:49:15\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 13:47:35\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-08 17:19:17\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-09 02:16:19\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.3.3\";s:7:\"updated\";s:19:\"2015-09-24 15:25:30\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.3.3/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-13 16:48:03\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-16 18:59:27\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-24 14:53:42\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-04 08:39:26\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-03 14:37:42\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-04 07:13:54\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-21 16:17:50\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 00:20:24\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-13 13:43:58\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-25 13:08:14\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-09 08:53:31\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-24 00:12:01\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 20:07:24\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-28 05:41:39\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.10\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.10/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-07 10:01:09\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-20 13:35:50\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.4.2/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-23 18:59:13\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-14 12:19:44\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-08 16:21:37\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-24 15:31:29\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.10\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.10/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-03 17:32:29\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-24 16:16:27\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-24 11:09:36\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-03-21 18:23:26\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-26 11:29:13\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-11-26 00:00:18\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-23 10:30:30\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-09 09:09:51\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 23:28:56\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-08 03:22:55\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-11-27 15:51:36\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-17 23:12:27\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:6:\"4.1.10\";s:7:\"updated\";s:19:\"2015-03-26 16:45:38\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.10/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-01-03 22:04:41\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-09 01:01:25\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-12 22:55:08\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-11 18:51:41\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","yes");
INSERT INTO `wp_options` VALUES("596","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1458931140","yes");
INSERT INTO `wp_options` VALUES("597","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","a:100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"5762\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"3580\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"3548\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"3046\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"2757\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"2281\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"2190\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"2045\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"1999\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"1968\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"1959\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1915\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1828\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:4:\"1641\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:4:\"1539\";}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";s:4:\"1532\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:4:\"1509\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:4:\"1338\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:4:\"1281\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:4:\"1276\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:4:\"1178\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:4:\"1080\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:4:\"1055\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:3:\"996\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:3:\"950\";}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";s:3:\"922\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"907\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"892\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"889\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"878\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"878\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"822\";}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";s:3:\"784\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"778\";}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";s:3:\"759\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"743\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"737\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"736\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"735\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"732\";}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"Share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";s:3:\"727\";}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";s:3:\"726\";}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";s:3:\"687\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"681\";}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";s:3:\"671\";}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";s:3:\"671\";}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";s:3:\"670\";}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"CSS\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";s:3:\"661\";}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";s:3:\"648\";}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";s:3:\"630\";}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";s:3:\"629\";}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";s:3:\"626\";}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";s:3:\"609\";}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";s:3:\"602\";}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";s:3:\"591\";}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";s:3:\"585\";}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";s:3:\"585\";}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";s:3:\"585\";}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";s:3:\"584\";}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";s:3:\"570\";}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";s:3:\"562\";}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";s:3:\"558\";}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";s:3:\"548\";}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";s:3:\"540\";}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";s:3:\"537\";}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";s:3:\"526\";}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";s:3:\"517\";}s:7:\"picture\";a:3:{s:4:\"name\";s:7:\"picture\";s:4:\"slug\";s:7:\"picture\";s:5:\"count\";s:3:\"507\";}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";s:3:\"502\";}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";s:3:\"501\";}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";s:3:\"491\";}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";s:3:\"489\";}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";s:3:\"486\";}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";s:3:\"484\";}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";s:3:\"466\";}s:8:\"pictures\";a:3:{s:4:\"name\";s:8:\"pictures\";s:4:\"slug\";s:8:\"pictures\";s:5:\"count\";s:3:\"452\";}s:4:\"shop\";a:3:{s:4:\"name\";s:4:\"shop\";s:4:\"slug\";s:4:\"shop\";s:5:\"count\";s:3:\"438\";}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";s:3:\"436\";}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";s:3:\"436\";}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";s:3:\"435\";}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";s:3:\"434\";}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";s:3:\"428\";}s:5:\"flash\";a:3:{s:4:\"name\";s:5:\"flash\";s:4:\"slug\";s:5:\"flash\";s:5:\"count\";s:3:\"422\";}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";s:3:\"419\";}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";s:3:\"414\";}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"News\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";s:3:\"404\";}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";s:3:\"404\";}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";s:3:\"402\";}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";s:3:\"402\";}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";s:3:\"398\";}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";s:3:\"397\";}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";s:3:\"394\";}s:9:\"thumbnail\";a:3:{s:4:\"name\";s:9:\"thumbnail\";s:4:\"slug\";s:9:\"thumbnail\";s:5:\"count\";s:3:\"390\";}s:4:\"text\";a:3:{s:4:\"name\";s:4:\"text\";s:4:\"slug\";s:4:\"text\";s:5:\"count\";s:3:\"388\";}s:6:\"upload\";a:3:{s:4:\"name\";s:6:\"upload\";s:4:\"slug\";s:6:\"upload\";s:5:\"count\";s:3:\"386\";}s:7:\"sharing\";a:3:{s:4:\"name\";s:7:\"sharing\";s:4:\"slug\";s:7:\"sharing\";s:5:\"count\";s:3:\"384\";}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";s:3:\"384\";}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";s:3:\"384\";}s:9:\"automatic\";a:3:{s:4:\"name\";s:9:\"automatic\";s:4:\"slug\";s:9:\"automatic\";s:5:\"count\";s:3:\"381\";}s:6:\"paypal\";a:3:{s:4:\"name\";s:6:\"paypal\";s:4:\"slug\";s:6:\"paypal\";s:5:\"count\";s:3:\"381\";}}","yes");
INSERT INTO `wp_options` VALUES("602","wordfence_version","6.0.24","yes");
INSERT INTO `wp_options` VALUES("603","wordfenceActivated","0","yes");
INSERT INTO `wp_options` VALUES("604","wf_plugin_act_error","","yes");
INSERT INTO `wp_options` VALUES("606","ossdl_off_cdn_url","http://asteh.su","yes");
INSERT INTO `wp_options` VALUES("607","ossdl_off_include_dirs","wp-content,wp-includes","yes");
INSERT INTO `wp_options` VALUES("608","ossdl_off_exclude",".php","yes");
INSERT INTO `wp_options` VALUES("609","ossdl_cname","","yes");
INSERT INTO `wp_options` VALUES("611","wpsupercache_start","1458920534","yes");
INSERT INTO `wp_options` VALUES("612","wpsupercache_count","0","yes");
INSERT INTO `wp_options` VALUES("613","wpsupercache_gc_time","1458920542","yes");
INSERT INTO `wp_options` VALUES("615","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1458920640;s:7:\"checked\";a:8:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.0.6\";s:31:\"goods_catalog/goods_catalog.php\";s:3:\"1.0\";s:9:\"hello.php\";s:3:\"1.6\";s:35:\"rus-to-lat-advanced/ru-translit.php\";s:3:\"1.1\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:5:\"4.2.8\";s:39:\"tinymce-templates/tinymce-templates.php\";s:5:\"4.4.3\";s:23:\"wordfence/wordfence.php\";s:6:\"6.0.24\";s:27:\"wp-super-cache/wp-cache.php\";s:5:\"1.4.8\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"41309\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.0.6\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";}s:9:\"hello.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"3564\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";}s:35:\"rus-to-lat-advanced/ru-translit.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"39288\";s:4:\"slug\";s:19:\"rus-to-lat-advanced\";s:6:\"plugin\";s:35:\"rus-to-lat-advanced/ru-translit.php\";s:11:\"new_version\";s:3:\"1.1\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/rus-to-lat-advanced/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/rus-to-lat-advanced.zip\";}s:37:\"tinymce-advanced/tinymce-advanced.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:3:\"731\";s:4:\"slug\";s:16:\"tinymce-advanced\";s:6:\"plugin\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:11:\"new_version\";s:5:\"4.2.8\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/tinymce-advanced/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/tinymce-advanced.4.2.8.zip\";}s:39:\"tinymce-templates/tinymce-templates.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"17614\";s:4:\"slug\";s:17:\"tinymce-templates\";s:6:\"plugin\";s:39:\"tinymce-templates/tinymce-templates.php\";s:11:\"new_version\";s:5:\"4.4.3\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/tinymce-templates/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/tinymce-templates.4.4.3.zip\";}s:23:\"wordfence/wordfence.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"25305\";s:4:\"slug\";s:9:\"wordfence\";s:6:\"plugin\";s:23:\"wordfence/wordfence.php\";s:11:\"new_version\";s:6:\"6.0.24\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/wordfence/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/wordfence.6.0.24.zip\";}s:27:\"wp-super-cache/wp-cache.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:4:\"1221\";s:4:\"slug\";s:14:\"wp-super-cache\";s:6:\"plugin\";s:27:\"wp-super-cache/wp-cache.php\";s:11:\"new_version\";s:5:\"1.4.8\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-super-cache/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wp-super-cache.1.4.8.zip\";s:14:\"upgrade_notice\";s:38:\"Removed malware URL in a code comment.\";}}}","yes");
INSERT INTO `wp_options` VALUES("616","aiowpsec_db_version","1.8","yes");
INSERT INTO `wp_options` VALUES("617","aio_wp_security_configs","a:74:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:13:\"7282588@bk.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:32:\"aiowps_unlock_request_secret_key\";s:20:\"pzrjma73hq30ht7jw8ea\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"nqbv2691xppde7mr8klg\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:13:\"7282588@bk.ru\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:13:\"7282588@bk.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("618","_transient_timeout_users_online","1458922449","no");
INSERT INTO `wp_options` VALUES("619","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1458935049;s:10:\"ip_address\";s:15:\"188.163.102.139\";}}","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","index.php");
INSERT INTO `wp_postmeta` VALUES("2","2","_edit_lock","1458685912:1");
INSERT INTO `wp_postmeta` VALUES("3","2","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("11","11","_wp_attached_file","2016/03/readme.txt");
INSERT INTO `wp_postmeta` VALUES("22","18","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("23","18","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("24","18","_menu_item_object_id","18");
INSERT INTO `wp_postmeta` VALUES("25","18","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("26","18","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("27","18","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("28","18","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("29","18","_menu_item_url","/");
INSERT INTO `wp_postmeta` VALUES("40","21","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("41","21","_edit_lock","1458686575:1");
INSERT INTO `wp_postmeta` VALUES("42","21","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("43","23","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("44","23","_edit_lock","1458685998:1");
INSERT INTO `wp_postmeta` VALUES("45","23","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("46","25","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("47","25","_edit_lock","1458727964:1");
INSERT INTO `wp_postmeta` VALUES("48","25","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("49","27","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("50","27","_edit_lock","1458728233:1");
INSERT INTO `wp_postmeta` VALUES("51","27","_wp_page_template","page-kontakty.php");
INSERT INTO `wp_postmeta` VALUES("52","29","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("53","29","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("54","29","_menu_item_object_id","27");
INSERT INTO `wp_postmeta` VALUES("55","29","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("56","29","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("57","29","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("58","29","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("59","29","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("61","30","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("62","30","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("63","30","_menu_item_object_id","25");
INSERT INTO `wp_postmeta` VALUES("64","30","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("65","30","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("66","30","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("67","30","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("68","30","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("70","31","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("71","31","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("72","31","_menu_item_object_id","23");
INSERT INTO `wp_postmeta` VALUES("73","31","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("74","31","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("75","31","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("76","31","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("77","31","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("79","32","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("80","32","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("81","32","_menu_item_object_id","21");
INSERT INTO `wp_postmeta` VALUES("82","32","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("83","32","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("84","32","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("85","32","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("86","32","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("88","18","_wp_old_slug","%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f");
INSERT INTO `wp_postmeta` VALUES("89","33","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("90","33","_edit_lock","1458893781:1");
INSERT INTO `wp_postmeta` VALUES("91","33","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("92","36","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("93","36","_edit_lock","1458893796:1");
INSERT INTO `wp_postmeta` VALUES("94","36","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("105","51","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("106","51","_edit_lock","1458490166:1");
INSERT INTO `wp_postmeta` VALUES("111","73","_wp_attached_file","2016/03/1.jpg");
INSERT INTO `wp_postmeta` VALUES("112","73","_wp_attachment_metadata","a:5:{s:5:\"width\";i:260;s:6:\"height\";i:260;s:4:\"file\";s:13:\"2016/03/1.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("113","74","_wp_attached_file","2016/03/2.jpg");
INSERT INTO `wp_postmeta` VALUES("114","74","_wp_attachment_metadata","a:5:{s:5:\"width\";i:260;s:6:\"height\";i:260;s:4:\"file\";s:13:\"2016/03/2.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("115","2","title","Главная");
INSERT INTO `wp_postmeta` VALUES("116","27","title","Контакты");
INSERT INTO `wp_postmeta` VALUES("117","23","title","Доставка");
INSERT INTO `wp_postmeta` VALUES("118","25","title","О нас");
INSERT INTO `wp_postmeta` VALUES("119","21","title","Условия аренды");
INSERT INTO `wp_postmeta` VALUES("120","76","_wp_attached_file","2016/03/2.gif");
INSERT INTO `wp_postmeta` VALUES("121","76","_wp_attachment_metadata","a:5:{s:5:\"width\";i:143;s:6:\"height\";i:93;s:4:\"file\";s:13:\"2016/03/2.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("122","77","_wp_attached_file","2016/03/1.gif");
INSERT INTO `wp_postmeta` VALUES("123","77","_wp_attachment_metadata","a:5:{s:5:\"width\";i:114;s:6:\"height\";i:90;s:4:\"file\";s:13:\"2016/03/1.gif\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("124","79","_wp_attached_file","2016/03/Foto-1.jpg");
INSERT INTO `wp_postmeta` VALUES("125","79","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1083;s:6:\"height\";i:897;s:4:\"file\";s:18:\"2016/03/Foto-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Foto-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Foto-1-300x248.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:248;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"Foto-1-768x636.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:636;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"Foto-1-1024x848.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:848;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("126","80","_wp_attached_file","2016/03/Foto-2.jpeg");
INSERT INTO `wp_postmeta` VALUES("127","80","_wp_attachment_metadata","a:5:{s:5:\"width\";i:824;s:6:\"height\";i:670;s:4:\"file\";s:19:\"2016/03/Foto-2.jpeg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-2-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-2-300x244.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:244;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Foto-2-768x624.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:624;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("128","81","_wp_attached_file","2016/03/Foto-3.jpg");
INSERT INTO `wp_postmeta` VALUES("129","81","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:18:\"2016/03/Foto-3.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Foto-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Foto-3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"Foto-3-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("130","82","_wp_attached_file","2016/03/Foto-4.jpg");
INSERT INTO `wp_postmeta` VALUES("131","82","_wp_attachment_metadata","a:5:{s:5:\"width\";i:699;s:6:\"height\";i:675;s:4:\"file\";s:18:\"2016/03/Foto-4.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Foto-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Foto-4-300x290.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:290;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("132","83","_wp_attached_file","2016/03/Foto-5.jpg");
INSERT INTO `wp_postmeta` VALUES("133","83","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2016/03/Foto-5.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Foto-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Foto-5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("134","84","_wp_attached_file","2016/03/Foto-678910.jpg");
INSERT INTO `wp_postmeta` VALUES("135","84","_wp_attachment_metadata","a:5:{s:5:\"width\";i:472;s:6:\"height\";i:444;s:4:\"file\";s:23:\"2016/03/Foto-678910.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"Foto-678910-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Foto-678910-300x282.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:282;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("136","85","_wp_attached_file","2016/03/Foto-11.jpg");
INSERT INTO `wp_postmeta` VALUES("137","85","_wp_attachment_metadata","a:5:{s:5:\"width\";i:699;s:6:\"height\";i:775;s:4:\"file\";s:19:\"2016/03/Foto-11.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-11-271x300.jpg\";s:5:\"width\";i:271;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("138","86","_wp_attached_file","2016/03/Foto-12.jpg");
INSERT INTO `wp_postmeta` VALUES("139","86","_wp_attachment_metadata","a:5:{s:5:\"width\";i:449;s:6:\"height\";i:442;s:4:\"file\";s:19:\"2016/03/Foto-12.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-12-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-12-300x295.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:295;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("140","87","_wp_attached_file","2016/03/Foto-13.jpg");
INSERT INTO `wp_postmeta` VALUES("141","87","_wp_attachment_metadata","a:5:{s:5:\"width\";i:591;s:6:\"height\";i:591;s:4:\"file\";s:19:\"2016/03/Foto-13.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-13-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-13-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("142","88","_wp_attached_file","2016/03/Foto-14.jpg");
INSERT INTO `wp_postmeta` VALUES("143","88","_wp_attachment_metadata","a:5:{s:5:\"width\";i:519;s:6:\"height\";i:572;s:4:\"file\";s:19:\"2016/03/Foto-14.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-14-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-14-272x300.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("144","89","_wp_attached_file","2016/03/Foto-15.jpg");
INSERT INTO `wp_postmeta` VALUES("145","89","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2016/03/Foto-15.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-15-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-15-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Foto-15-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("146","90","_wp_attached_file","2016/03/Foto-16.jpg");
INSERT INTO `wp_postmeta` VALUES("147","90","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:495;s:4:\"file\";s:19:\"2016/03/Foto-16.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-16-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-16-300x297.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:297;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("148","91","_wp_attached_file","2016/03/Foto-17.jpg");
INSERT INTO `wp_postmeta` VALUES("149","91","_wp_attachment_metadata","a:5:{s:5:\"width\";i:901;s:6:\"height\";i:705;s:4:\"file\";s:19:\"2016/03/Foto-17.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-17-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-17-300x235.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:235;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Foto-17-768x601.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:601;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("150","92","_wp_attached_file","2016/03/Foto-18.jpg");
INSERT INTO `wp_postmeta` VALUES("151","92","_wp_attachment_metadata","a:5:{s:5:\"width\";i:700;s:6:\"height\";i:700;s:4:\"file\";s:19:\"2016/03/Foto-18.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-18-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-18-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("152","93","_wp_attached_file","2016/03/Foto-19.jpg");
INSERT INTO `wp_postmeta` VALUES("153","93","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:19:\"2016/03/Foto-19.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-19-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-19-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("154","94","_wp_attached_file","2016/03/Foto-2022242628303234.jpg");
INSERT INTO `wp_postmeta` VALUES("155","94","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:33:\"2016/03/Foto-2022242628303234.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Foto-2022242628303234-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Foto-2022242628303234-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"Foto-2022242628303234-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"Foto-2022242628303234-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("156","95","_wp_attached_file","2016/03/Foto-21.jpg");
INSERT INTO `wp_postmeta` VALUES("157","95","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:19:\"2016/03/Foto-21.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-21-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-21-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("158","96","_wp_attached_file","2016/03/Foto-23.jpg");
INSERT INTO `wp_postmeta` VALUES("159","96","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1600;s:4:\"file\";s:19:\"2016/03/Foto-23.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Foto-23-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Foto-23-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Foto-23-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Foto-23-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("160","97","_wp_attached_file","2016/03/Foto-2527293133.jpg");
INSERT INTO `wp_postmeta` VALUES("161","97","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:27:\"2016/03/Foto-2527293133.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Foto-2527293133-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Foto-2527293133-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"Foto-2527293133-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("162","98","_wp_attached_file","2016/03/Otboynyy-molotok-Hitachi-H65SB2.pdf");
INSERT INTO `wp_postmeta` VALUES("163","99","_wp_attached_file","2016/03/Perforator-Makita-HR-5001-C.doc");
INSERT INTO `wp_postmeta` VALUES("164","100","_wp_attached_file","2016/03/Perforator-Makita-HR-5001-C.pdf");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2016-03-11 14:15:47","2016-03-11 14:15:47","Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!","Привет, мир!","","publish","open","open","","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80","","","2016-03-11 14:15:47","2016-03-11 14:15:47","","0","http://ast/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2016-03-11 14:15:47","2016-03-11 14:15:47","Мы предоставляем нашим заказчикам услуги по прокату строительной техники и инструмента в Москве и Московской области. Наша организация имеет собственную базу качественной техники и инструмента лидирующих производителей: Makita, Hitachi и т. д.

Оказывая услуги по прокату ремонтного инструмента, мы стараемся соответствовать всем требованиям клиентов. Наша компания старается предложить своим клиентам услуги аренды наиболее востребованных моделей строительного инструмента в соответствии с самыми высокими стандартами качества на рынке аренды техники и инструмента.","КАК АРЕНДОВАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ?","","publish","open","open","","sample-page","","","2016-03-23 02:33:45","2016-03-22 22:33:45","","0","http://ast/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2016-03-11 21:03:50","2016-03-11 17:03:50","[wordpress_file_upload]Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:

<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>

...или так:

<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>

Перейдите <a href=\"http://ast/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!","Пример страницы","","inherit","open","open","","2-revision-v1","","","2016-03-11 21:03:50","2016-03-11 17:03:50","","2","http://ast/?p=4","0","revision","","0");
INSERT INTO `wp_posts` VALUES("6","1","2016-03-15 17:09:39","2016-03-15 13:09:39","Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:
<blockquote>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>
...или так:
<blockquote>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>
Перейдите <a href=\"http://ast/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!","Пример страницы","","inherit","open","open","","2-revision-v1","","","2016-03-15 17:09:39","2016-03-15 13:09:39","","2","http://ast/?p=6","0","revision","","0");
INSERT INTO `wp_posts` VALUES("11","1","2016-03-17 00:25:21","2016-03-16 20:25:21","","readme","","inherit","open","open","","readme","","","2016-03-17 00:25:21","2016-03-16 20:25:21","","0","http://ast/wp-content/uploads/2016/03/readme.txt","0","attachment","text/plain","0");
INSERT INTO `wp_posts` VALUES("17","1","2016-03-19 23:25:04","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2016-03-19 23:25:04","0000-00-00 00:00:00","","0","http://ast/?p=17","0","post","","0");
INSERT INTO `wp_posts` VALUES("18","1","2016-03-19 23:27:36","2016-03-19 19:27:36","","Главная","","publish","open","closed","","glavnaya","","","2016-03-21 22:02:02","2016-03-21 18:02:02","","0","http://ast/?p=18","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("20","1","2016-03-19 23:29:06","2016-03-19 19:29:06","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также 
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","КАК ВЫБРАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ? ","","inherit","open","open","","2-revision-v1","","","2016-03-19 23:29:06","2016-03-19 19:29:06","","2","http://ast/?p=20","0","revision","","0");
INSERT INTO `wp_posts` VALUES("21","1","2016-03-19 23:29:56","2016-03-19 19:29:56","<h2>Условия аренды</h2>
Выставленный на нашем сайте инструмент и оборудование возможно взять в аренду и вернуть ежедневно с 9:00 до 19:00. Наша компания работает без праздников и выходных. Адрес пункта аренды инструмента: г. Москва, ул. Мартеновская, д. 38, корп. 2.
<h3>Самовывоз</h3>
<ol>
	<li>Вы звоните нам по телефону и уточняете наличие нужного Вам инструмента.</li>
	<li>Вы приезжаете к нам в пункт проката, имея при себе паспорт, залоговую стоимость инструмента и оплату за весь срок проката.</li>
	<li>Вы выбираете интересующий Вас инструмент.</li>
	<li>При Вашем присутствии наш сотрудник демонстрирует исправность и рабочее состояние инструмента.</li>
	<li>Вы читаете и подписываете договор проката инструмента, вносите залоговую сумму и оплату за весь срок проката.</li>
	<li>Вы пользуетесь инструментом.</li>
	<li>Вы возвращаете чистый и исправный инструмент обратно к нам в пункт проката, подписываете акт возврата инструмента, забираете залог полностью или частично (при пользовании оборудованием дольше обозначенного в договоре проката срока).</li>
	<li>При возврате грязного инструмента накладывается штраф 500 рублей.</li>
	<li>При возврате неисправного инструмента по вине <strong>Арендатора с Арендатора</strong> удерживается сумма необходимая для ремонта инструмента.</li>
	<li>При потере инструмента <strong>Арендатор</strong> оплачивает его полную стоимость.</li>
</ol>
<h4>Плавила оформления и получения оборудования</h4>
<del>Физ. лица:</del>
<ol>
	<li>Для аренды инструмента при залоге, указанном на сайте в карточке товара, <strong>Арендатор</strong> должен быть прописан в Москве или Московской области и предъявить паспорт гражданина РФ с отметкой о прописке в Москве или МО.</li>
	<li>В любом другом случае <strong>Арендатор</strong> предъявляет документ, удостоверяющий его личность и вносит в качестве залога полную стоимость инструмента (размер полной стоимости инструмента можно уточнить у нашего сотрудника).</li>
</ol>
<del>Юр. лица:</del>
<ol>
	<li>Для аренды оборудования при залоге, указанном на сайте в карточке товара, необходимо предоставить полные данные о фирме.</li>
	<li>Необходимо предоставить паспортные данные физического лица, прописанного в Москве или Московской области, которое будет представлять юр. лицо при заключении договора аренды.</li>
	<li>После поступления на р/с <strong>Арендодателя</strong> сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
	<li>Для аренды оборудования при залоге, равном полной стоимости инструмента, необходимо предоставить реквизиты фирмы.</li>
	<li>После поступления на р/с Арендодателя сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
</ol>
<del>Определение стоимости проката:</del>
<ol>
	<li>Стоимость проката определяется исходя из цен, указанных на сайте в карточке товара и срока использования инструмента.</li>
	<li><strong>Арендатор</strong> оплачивает полную сумму аренды за весь период.</li>
	<li>При залоге, равном полной стоимости инструмента, оплачивается только залог.</li>
	<li>Стоимость аренды вычитается из залога при возврате оборудования.</li>
</ol>
<del>Определение периода проката:</del>
<ol>
	<li>Начинается прокат инструмента с даты и времени, указанных в акте передачи оборудования.</li>
	<li>Заканчивается прокат инструмента на дату и время, указанные в акте возврата оборудования.</li>
	<li>Минимальный период проката - сутки (24 часа).</li>
</ol>
<del>Информация предоставляемая <strong>Арендатором:</strong></del>
<ol>
	<li>Место эксплуатации инструмента.</li>
	<li>Телефон заказчика, телефон ответственного на объекте.</li>
	<li><strong>Арендатор</strong> обязан уведомить в течении суток о любых изменениях предоставленных данных (телефоны, адреса, реквизиты).</li>
</ol>
<h5>Получение инструмента в аренду</h5>
<ol>
	<li>При получении инструмента в прокат <strong>Арендатору</strong> демонстрируется его исправность и пригодность к работе.</li>
	<li>При поломке инструмента <strong>Арендатор</strong> должен сообщить об этом Арендодателю и вернуть инструмент в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 за свой счет. В течении 10 рабочих дней <strong>Арендодатель</strong> осуществляет проверку инструмента для определения причины поломки (естественный износ или вина <strong>Арендатора</strong>). На протяжении проверки залог <strong>Арендатору</strong> не возвращается. По результатам проверки, <strong>Арендодатель </strong>сообщает <strong>Арендатору</strong> причину неисправности и возвращает залог целиком или использует его частично или полностью для починки инструмента.</li>
	<li>Прокат инструмента заканчивается при поступлении оборудования в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 или передаче его экспедитору. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Сообщения по телефону или с помощью других видов связи не останавливают аренду. Арендная плата начисляется до фактического возврата инструмента.</li>
	<li>Если инструмент сломался, <strong>Арендодатель</strong> не несет ответственность за упущенную выгоду <strong>Арендатором</strong>.</li>
	<li>Инструмент должен быть возвращен в чистом виде. В противном случае взимается штраф в размере 500 р.</li>
	<li><strong>Арендатору</strong> может быть отказано в сдаче оборудования в прокат без указания причин. Кроме того возможны внесения изменений в стоимость аренды или залога исходя из индивидуальной ситуации.</li>
</ol>","условия аренды","","publish","open","open","","usloviya-arendy","","","2016-03-23 02:36:48","2016-03-22 22:36:48","","0","http://ast/?page_id=21","0","page","","0");
INSERT INTO `wp_posts` VALUES("22","1","2016-03-19 23:29:56","2016-03-19 19:29:56","условия аренды","условия аренды","","inherit","open","open","","21-revision-v1","","","2016-03-19 23:29:56","2016-03-19 19:29:56","","21","http://ast/?p=22","0","revision","","0");
INSERT INTO `wp_posts` VALUES("23","1","2016-03-19 23:34:21","2016-03-19 19:34:21","<h2>Доставка строительного инструмента по Москве и Московской области:</h2>
<ul>
	<li>Для удобства наших клиентов мы можем осуществить доставку инструмента непосредственно к заказчику.</li>
	<li>Стоимость доставки внутри МКАД составляет от 500 до 1000 р. в зависимости от удаленности объекта от пункта проката (ул. Мартеновская, д. 38, корп. 2).</li>
	<li>Доставка за МКАД - 20 р./км.</li>
	<li>Стоимость вывоза равна стоимости доставки.</li>
	<li>Документы по прокату будут у водителя с собой.</li>
	<li>Погрузка и разгрузка инструмента осуществляется силами <strong>Арендатора</strong>.</li>
	<li>Простой по вине <strong>Арендатора</strong> оплачивается <strong>Арендатором</strong> из расчета 300 р/час за каждый час простоя.</li>
</ul>","доставка","","publish","open","open","","dostavka","","","2016-03-23 02:35:34","2016-03-22 22:35:34","","0","http://ast/?page_id=23","0","page","","0");
INSERT INTO `wp_posts` VALUES("24","1","2016-03-19 23:34:21","2016-03-19 19:34:21","доставка","доставка","","inherit","open","open","","23-revision-v1","","","2016-03-19 23:34:21","2016-03-19 19:34:21","","23","http://ast/?p=24","0","revision","","0");
INSERT INTO `wp_posts` VALUES("25","1","2016-03-19 23:35:03","2016-03-19 19:35:03","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>Наша компания всегда рада Вашему визиту!</b></i>

&nbsp;
<h3><strong>ИП Полтавец Николай Петрович</strong></h3>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
</tbody>
</table>
</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","publish","open","open","","o-nas","","","2016-03-23 14:15:03","2016-03-23 10:15:03","","0","http://ast/?page_id=25","0","page","","0");
INSERT INTO `wp_posts` VALUES("26","1","2016-03-19 23:35:03","2016-03-19 19:35:03","о нас","о нас","","inherit","open","open","","25-revision-v1","","","2016-03-19 23:35:03","2016-03-19 19:35:03","","25","http://ast/?p=26","0","revision","","0");
INSERT INTO `wp_posts` VALUES("27","1","2016-03-19 23:38:00","2016-03-19 19:38:00","контакты","контакты","","publish","open","open","","kontakty","","","2016-03-23 13:22:30","2016-03-23 09:22:30","","0","http://ast/?page_id=27","0","page","","0");
INSERT INTO `wp_posts` VALUES("28","1","2016-03-19 23:38:00","2016-03-19 19:38:00","контакты","контакты","","inherit","open","open","","27-revision-v1","","","2016-03-19 23:38:00","2016-03-19 19:38:00","","27","http://ast/27-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("29","1","2016-03-19 23:39:48","2016-03-19 19:39:48"," ","","","publish","open","closed","","29","","","2016-03-21 22:02:03","2016-03-21 18:02:03","","0","http://ast/?p=29","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("30","1","2016-03-19 23:39:47","2016-03-19 19:39:47"," ","","","publish","open","closed","","30","","","2016-03-21 22:02:03","2016-03-21 18:02:03","","0","http://ast/?p=30","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("31","1","2016-03-19 23:39:46","2016-03-19 19:39:46"," ","","","publish","open","closed","","31","","","2016-03-21 22:02:03","2016-03-21 18:02:03","","0","http://ast/?p=31","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("32","1","2016-03-19 23:39:45","2016-03-19 19:39:45"," ","","","publish","open","closed","","32","","","2016-03-21 22:02:03","2016-03-21 18:02:03","","0","http://ast/?p=32","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("33","1","2016-03-20 00:32:46","2016-03-19 20:32:46","Мы предоставляем нашим заказчикам услуги по прокату строительной техники и инструмента в Москве и Московской области. Наша организация имеет собственную базу качественной техники и инструмента лидирующих производителей: Makita, Hitachi и т. д.","Категории","","publish","open","open","","categories","","","2016-03-21 19:12:05","2016-03-21 15:12:05","","0","http://ast/?page_id=33","0","page","","0");
INSERT INTO `wp_posts` VALUES("34","1","2016-03-20 00:32:46","2016-03-19 20:32:46","","Категории","","inherit","open","open","","33-revision-v1","","","2016-03-20 00:32:46","2016-03-19 20:32:46","","33","http://ast/33-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("35","1","2016-03-20 01:58:20","2016-03-19 21:58:20","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также 
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","Категории","","inherit","open","open","","33-revision-v1","","","2016-03-20 01:58:20","2016-03-19 21:58:20","","33","http://ast/33-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("36","1","2016-03-20 02:00:36","2016-03-19 22:00:36","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также 
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","Продукт","","publish","open","open","","product","","","2016-03-20 02:02:10","2016-03-19 22:02:10","","0","http://ast/?page_id=36","0","page","","0");
INSERT INTO `wp_posts` VALUES("37","1","2016-03-20 02:00:36","2016-03-19 22:00:36","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также 
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","Сео текст","","inherit","open","open","","36-revision-v1","","","2016-03-20 02:00:36","2016-03-19 22:00:36","","36","http://ast/36-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("38","1","2016-03-20 02:01:59","2016-03-19 22:01:59","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также 
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","Продукты","","inherit","open","open","","36-revision-v1","","","2016-03-20 02:01:59","2016-03-19 22:01:59","","36","http://ast/36-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("39","1","2016-03-20 02:02:10","2016-03-19 22:02:10","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также 
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","Продукт","","inherit","open","open","","36-revision-v1","","","2016-03-20 02:02:10","2016-03-19 22:02:10","","36","http://ast/36-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("40","1","2016-03-21 20:22:28","2016-03-21 16:22:28","<h2>условия аренды</h2>
Выставленный на нашем сайте инструмент и оборудование возможно взять в аренду и вернуть ежедневно с 9:00 до 19:00. Наша компания работает без праздников и выходных. Адрес пункта аренды инструмента: г. Москва, ул. Мартеновская, д. 38, корп. 2.
<h3>Самовывоз</h3>
<ol>
	<li>Вы звоните нам по телефону и уточняете наличие нужного Вам инструмента.</li>
	<li>Вы приезжаете к нам в пункт проката, имея при себе паспорт, залоговую стоимость инструмента и оплату за весь срок проката.</li>
	<li>Вы выбираете интересующий Вас инструмент.</li>
	<li>При Вашем присутствии наш сотрудник демонстрирует исправность и рабочее состояние инструмента.</li>
	<li>Вы читаете и подписываете договор проката инструмента, вносите залоговую сумму и оплату за весь срок проката.</li>
	<li>Вы пользуетесь инструментом.</li>
	<li>Вы возвращаете чистый и исправный инструмент обратно к нам в пункт проката, подписываете акт возврата инструмента, забираете залог полностью или частично (при пользовании оборудованием дольше обозначенного в договоре проката срока).</li>
	<li>При возврате грязного инструмента накладывается штраф 500 рублей.</li>
	<li>При возврате неисправного инструмента по вине <strong>Арендатора с Арендатора</strong> удерживается сумма необходимая для ремонта инструмента.</li>
	<li>При потере инструмента <strong>Арендатор</strong> оплачивает его полную стоимость.</li>
</ol>
<h4>Плавила оформления и получения оборудования</h4>
<del>Физ. лица:</del>
<ol>
	<li>Для аренды инструмента при залоге, указанном на сайте в карточке товара, <strong>Арендатор</strong> должен быть прописан в Москве или Московской области и предъявить паспорт гражданина РФ с отметкой о прописке в Москве или МО.</li>
	<li>В любом другом случае <strong>Арендатор</strong> предъявляет документ, удостоверяющий его личность и вносит в качестве залога полную стоимость инструмента (размер полной стоимости инструмента можно уточнить у нашего сотрудника).</li>
</ol>
<del>Юр. лица:</del>
<ol>
	<li>Для аренды оборудования при залоге, указанном на сайте в карточке товара, необходимо предоставить полные данные о фирме.</li>
	<li>Необходимо предоставить паспортные данные физического лица, прописанного в Москве или Московской области, которое будет представлять юр. лицо при заключении договора аренды.</li>
	<li>После поступления на р/с <strong>Арендодателя</strong> сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
	<li>Для аренды оборудования при залоге, равном полной стоимости инструмента, необходимо предоставить реквизиты фирмы.</li>
	<li>После поступления на р/с Арендодателя сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
</ol>
<del>Определение стоимости проката:</del>
<ol>
	<li>Стоимость проката определяется исходя из цен, указанных на сайте в карточке товара и срока использования инструмента.</li>
	<li><strong>Арендатор</strong> оплачивает полную сумму аренды за весь период.</li>
	<li>При залоге, равном полной стоимости инструмента, оплачивается только залог.</li>
	<li>Стоимость аренды вычитается из залога при возврате оборудования.</li>
</ol>
<del>Определение периода проката:</del>
<ol>
	<li>Начинается прокат инструмента с даты и времени, указанных в акте передачи оборудования.</li>
	<li>Заканчивается прокат инструмента на дату и время, указанные в акте возврата оборудования.</li>
	<li>Минимальный период проката - сутки (24 часа).</li>
</ol>
<del>Информация предоставляемая <strong>Арендатором:</strong></del>
<ol>
	<li>Место эксплуатации инструмента.</li>
	<li>Телефон заказчика, телефон ответственного на объекте.</li>
	<li><strong>Арендатор</strong> обязан уведомить в течении суток о любых изменениях предоставленных данных (телефоны, адреса, реквизиты).</li>
</ol>
<h5>Получение инструмента в аренду</h5>
<ol>
	<li>При получении инструмента в прокат <strong>Арендатору</strong> демонстрируется его исправность и пригодность к работе.</li>
	<li>При поломке инструмента Арендатор должен сообщить об этом Арендодателю и вернуть инструмент в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 за свой счет. В течении 10 рабочих дней Арендодатель осуществляет проверку инструмента для определения причины поломки (естественный износ или вина Арендатора). На протяжении проверки залог Арендатору не возвращается. По результатам проверки, Арендодатель сообщает Арендатору причину неисправности и возвращает залог целиком или использует его частично или полностью для починки инструмента.</li>
	<li>Прокат инструмента заканчивается при поступлении оборудования в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 или передаче его экспедитору. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Аренда оборудования прекращается ТОЛЬКО при поступлении оборудования на склад по адресу г. Москва, ул. Гоголя, д.7. или передаче его экспедитору транспортной компании с которой сотрудничает СТРОЙАРЕНДА. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Сообщения по телефону или с помощью других видов связи не останавливают аренду. Арендная плата начисляется до фактического возврата оборудования.</li>
	<li>Если оборудование сломалось, АРЕНДОДАТЕЛЬ не несет ответственность за упущенную выгоду АРЕНДАТОРОМ.</li>
	<li>Оборудование должно быть возвращено в чистом виде. В противном случае накладывается штраф в размере 500 р.</li>
	<li>АРЕНДАТОРУ может выть отказано в сдаче оборудования в аренду без указания причин. Также могут быть внесены изменения в стоимость аренды либо залога исходя из конкретного случая.</li>
</ol>","условия аренды","","inherit","open","open","","21-autosave-v1","","","2016-03-21 20:22:28","2016-03-21 16:22:28","","21","http://ast/21-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("41","1","2016-03-20 18:27:16","2016-03-20 14:27:16","<h2>условия аренды</h2>
Все представленное на сайте оборудование можно получить напрокат и вернуть ежедневно с 7:00 до 23:00. Для Вашего удобства мы
работаем в выходные и праздничные дни. Место выдачи оборудования: г. Москва, ул. Гоголя, д.7.
Погрузочные и разгрузочные работы строительных лесов, опалубки перекрытия проводятся с 9:00 до 21:00. В другое время в рамках работы
проката (с 7:00 до 23:00) заказчик может произвести погрузочно-разгрузочные работы собственными силами.
<h3>Самовывоз</h3>
<ol>
	<li>Вам необходимо выяснить по телефону наличие необходимого инструмента (оборудования) в пункте проката (бронирование возможно на время не более 3 часов с момента заказа).</li>
	<li>Взять с собой залоговую сумму (см. таблицу интересующего раздела), паспорт (см. залог)</li>
	<li>По прибытию на КПП по адресу: г. Москва, ул. Гоголя, д.7 выяснить местонахождение пункта проката (см. карту на сайте).</li>
	<li>Заехать или зайти на территорию склада пункта проката.</li>
	<li>Выбрать интересующее Вас оборудование или инструмент.</li>
	<li>Проверить исправность и работоспособность оборудования (во избежании претензий).</li>
	<li>Подписать договор аренды, внести залоговую сумму и оплатить весь срок аренды.</li>
	<li>После возврата чистого и исправного оборудования Вы можете получить остаток залога.</li>
	<li>В случае возврата грязного оборудования взимается штраф 500 рублей.</li>
	<li>В случае возврата неисправного оборудования по вине Арендатора с Арендатора удерживается сумма необходимая для восстановления работоспособности оборудования или инструмента.</li>
	<li>В случае утраты оборудования Арендатор оплачивает полную стоимость оборудования или инструмента.</li>
</ol>
<h4>Плавила оформления и получения оборудования</h4>
Физическими лицами:
<ol>
	<li>Аренда оборудования при частичном залоге.
<ol>
	<li>В случае, если Арендатор прописан в г. Москве или Московской области, оборудование ему может быть выдано при частичном залоге. Размер залога указан в таблице стоимости аренды оборудования в колонке Залоговая сумма.</li>
	<li>Аренда при частичном залоге возможна ТОЛЬКО при предъявлении лично АРЕНДАТОРОМ паспорта гражданина РФ с отметкой о прописке в Москве или МО.</li>
</ol>
</li>
	<li>Аренда оборудования при полном залоге.
<ol>
	<li>Аренда оборудования при полном залоге возможна при предъявлении паспорта, либо (по согласованию) другого документа, удостоверяющего личность. Размер полного залога указан в таблице стоимости аренды оборудования в колонке Полная стоимость.</li>
</ol>
</li>
</ol>
Юридическими лицами:
<ol>
	<li>Аренда оборудования при частичном залоге.
<ol>
	<li>Для аренды оборудования при частичном залоге необходимо предоставить для проверки полные данные о своей компании.</li>
	<li> Если проверка прошла положительно необходимо предоставить паспортные данные физического лица, прописанного в Москве или Московской области для составления договора поручительства.</li>
	<li> После поступления на р/с АРЕНДОДАТЕЛЯ сумм, указанных в договоре и счете, АРЕНДАТОР может получить оборудование на складе АРЕНДОДАТЕЛЯ.</li>
	<li>Выдача оборудования производится ТОЛЬКО при наличии доверенности.</li>
</ol>
</li>
	<li>Аренда оборудования при полном залоге. 2.1. Для аренды оборудования при полном залоге необходимо предоставить реквизиты своей компании.
<ol>
	<li>После поступления на р/с АРЕНДОДАТЕЛЯ сумм, указанных в договоре и счете, АРЕНДАТОР может получить оборудование на складе АРЕНДОДАТЕЛЯ.</li>
	<li> Выдача оборудования производится ТОЛЬКО при наличии доверенности.</li>
</ol>
</li>
</ol>
Расчет стоимости аренды:
<ol>
	<li>Стоимость аренды рассчитываются исходя из цен, указанных на сайте</li>
	<li>АРЕНДАТОР оплачивает полную сумму аренды за весь период. При полном залоге оплачивается только полная стоимость оборудования, стоимость аренды вычитается из залога при возврате оборудования.</li>
</ol>
Период аренды:
<ol>
	<li>Отсчет аренды начинается с даты и времени, указанных в акте передачи оборудования.</li>
	<li>Окончанием аренды считается дата и время, указанные в акте возврата оборудования.</li>
	<li>Минимальный период аренды – одни сутки (24 часа).</li>
	<li>Если возврат оборудования произошел с задержкой больше чем на 2 часа, оплата происходит за следующие сутки.</li>
</ol>
Контактная информация сообщаемая АРЕНДАТОРОМ:
<ol>
	<li>Место эксплуатации оборудования.</li>
	<li>Телефон заказчика, телефон ответственного на объекте.</li>
	<li>АРЕНДАТОР обязан уведомить в течении суток о любых изменениях контактов, адреса эксплуатации или реквизитов.</li>
</ol>
<h5>Передача оборудования напрокат</h5>
<ol>
	<li>При передаче оборудования в аренду проверяется его работоспособность и демонстрируется АРЕНДАТОРУ. АРЕНДАТОР подписывается в акте передачи о том, что оборудование ему было передано в исправном состоянии и работоспособность продемонстрирована. В случае наличия дефектов, об этом делается отметка в акте передачи.</li>
	<li>Заправка оборудования происходит за счет АРЕНДАТОРА.</li>
	<li>В случае поломки оборудования АРЕНДАТОР обязан известить об этом АРЕНДОДАТЕЛЯ и вернуть оборудование на склад по адресу г. Москва, ул. Гоголя, д.7. за свой счет. В течении 10 рабочих дней АРЕНДОДАТЕЛЬ проводит экспертизу оборудования для определения причины поломки (естественный износ или вина АРЕНДАТОРА). В течении этого периода залог АРЕНДАТОРУ не возвращается. По результатам экспертизы, АРЕНДОДАТЕЛЬ сообщает АРЕНДАТОРУ причину поломки и возвращает залог целиком или использует его частично или полностью для ремонта оборудования. По согласованию с АРЕНДОДАТЕЛЕМ АРЕНДАТОР может произвести ремонт своими силами.</li>
	<li>Аренда оборудования прекращается ТОЛЬКО при поступлении оборудования на склад по адресу г. Москва, ул. Гоголя, д.7. или передаче его экспедитору транспортной компании с которой сотрудничает СТРОЙАРЕНДА. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Сообщения по телефону или с помощью других видов связи не останавливают аренду. Арендная плата начисляется до фактического возврата оборудования.</li>
	<li>Если оборудование сломалось, АРЕНДОДАТЕЛЬ не несет ответственность за упущенную выгоду АРЕНДАТОРОМ.</li>
	<li>Оборудование должно быть возвращено в чистом виде. В противном случае накладывается штраф в размере 500 р.</li>
	<li>АРЕНДАТОРУ может выть отказано в сдаче оборудования в аренду без указания причин. Также могут быть внесены изменения в стоимость аренды либо залога исходя из конкретного случая.</li>
</ol>","условия аренды","","inherit","open","open","","21-revision-v1","","","2016-03-20 18:27:16","2016-03-20 14:27:16","","21","http://ast/21-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("47","1","2016-03-20 18:43:38","2016-03-20 14:43:38","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.

&nbsp;

<strong>[cn-social-icon]</strong>","КАК ВЫБРАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ? ","","inherit","open","open","","2-revision-v1","","","2016-03-20 18:43:38","2016-03-20 14:43:38","","2","http://ast/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("48","1","2016-03-20 18:44:21","2016-03-20 14:44:21","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.

[cn-social-icon]","КАК ВЫБРАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ? ","","inherit","open","open","","2-revision-v1","","","2016-03-20 18:44:21","2016-03-20 14:44:21","","2","http://ast/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("49","1","2016-03-20 19:43:56","2016-03-20 15:43:56","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.
<div class=\"head_point\">вапвапвапвапвапвап</div>","КАК ВЫБРАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ?","","inherit","open","open","","2-autosave-v1","","","2016-03-20 19:43:56","2016-03-20 15:43:56","","2","http://ast/2-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("50","1","2016-03-20 18:58:33","2016-03-20 14:58:33","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и
Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB,
Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая
важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания
состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также
нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом,
наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в
каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.","КАК ВЫБРАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ? ","","inherit","open","open","","2-revision-v1","","","2016-03-20 18:58:33","2016-03-20 14:58:33","","2","http://ast/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("51","1","2016-03-20 19:39:45","2016-03-20 15:39:45","<div class=\"head_point\">Ваш заголовок</div>","Оглавление с точкой","","publish","closed","closed","","oglavlenie-s-tochkoy","","","2016-03-20 19:39:45","2016-03-20 15:39:45","","0","http://ast/?post_type=tinymcetemplates&#038;p=51","0","tinymcetemplates","","0");
INSERT INTO `wp_posts` VALUES("52","1","2016-03-20 19:39:45","2016-03-20 15:39:45","<div class=\"head_point\">Ваш заголовок</div>","Оглавление с точкой","","inherit","closed","closed","","51-revision-v1","","","2016-03-20 19:39:45","2016-03-20 15:39:45","","51","http://ast/51-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("54","1","2016-03-20 22:07:40","2016-03-20 18:07:40","<h2>Информация о нашей компании:</h2>
Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB, Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом, наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.

<strong>Наша компания всегда рада Вашему визиту!</strong>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-20 22:07:40","2016-03-20 18:07:40","","25","http://ast/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("55","1","2016-03-20 22:08:42","2016-03-20 18:08:42","<h2>условия аренды</h2>
Все представленное на сайте оборудование можно получить напрокат и вернуть ежедневно с 7:00 до 23:00. Для Вашего удобства мы
работаем в выходные и праздничные дни. Место выдачи оборудования: г. Москва, ул. Гоголя, д.7.
Погрузочные и разгрузочные работы строительных лесов, опалубки перекрытия проводятся с 9:00 до 21:00. В другое время в рамках работы
проката (с 7:00 до 23:00) заказчик может произвести погрузочно-разгрузочные работы собственными силами.
<h3>Самовывоз</h3>
<ol>
	<li>Вам необходимо выяснить по телефону наличие необходимого инструмента (оборудования) в пункте проката (бронирование возможно на время не более 3 часов с момента заказа).</li>
	<li>Взять с собой залоговую сумму (см. таблицу интересующего раздела), паспорт (см. залог)</li>
	<li>По прибытию на КПП по адресу: г. Москва, ул. Гоголя, д.7 выяснить местонахождение пункта проката (см. карту на сайте).</li>
	<li>Заехать или зайти на территорию склада пункта проката.</li>
	<li>Выбрать интересующее Вас оборудование или инструмент.</li>
	<li>Проверить исправность и работоспособность оборудования (во избежании претензий).</li>
	<li>Подписать договор аренды, внести залоговую сумму и оплатить весь срок аренды.</li>
	<li>После возврата чистого и исправного оборудования Вы можете получить остаток залога.</li>
	<li>В случае возврата грязного оборудования взимается штраф 500 рублей.</li>
	<li>В случае возврата неисправного оборудования по вине Арендатора с Арендатора удерживается сумма необходимая для восстановления работоспособности оборудования или инструмента.</li>
	<li>В случае утраты оборудования Арендатор оплачивает полную стоимость оборудования или инструмента.</li>
</ol>
<h4>Плавила оформления и получения оборудования</h4>
<del>Физическими лицами:</del>
<ol>
	<li>Аренда оборудования при частичном залоге.
<ol>
	<li>В случае, если Арендатор прописан в г. Москве или Московской области, оборудование ему может быть выдано при частичном залоге. Размер залога указан в таблице стоимости аренды оборудования в колонке Залоговая сумма.</li>
	<li>Аренда при частичном залоге возможна ТОЛЬКО при предъявлении лично АРЕНДАТОРОМ паспорта гражданина РФ с отметкой о прописке в Москве или МО.</li>
</ol>
</li>
	<li>Аренда оборудования при полном залоге.
<ol>
	<li>Аренда оборудования при полном залоге возможна при предъявлении паспорта, либо (по согласованию) другого документа, удостоверяющего личность. Размер полного залога указан в таблице стоимости аренды оборудования в колонке Полная стоимость.</li>
</ol>
</li>
</ol>
<del>Юридическими лицами:</del>
<ol>
	<li>Аренда оборудования при частичном залоге.
<ol>
	<li>Для аренды оборудования при частичном залоге необходимо предоставить для проверки полные данные о своей компании.</li>
	<li> Если проверка прошла положительно необходимо предоставить паспортные данные физического лица, прописанного в Москве или Московской области для составления договора поручительства.</li>
	<li> После поступления на р/с АРЕНДОДАТЕЛЯ сумм, указанных в договоре и счете, АРЕНДАТОР может получить оборудование на складе АРЕНДОДАТЕЛЯ.</li>
	<li>Выдача оборудования производится ТОЛЬКО при наличии доверенности.</li>
</ol>
</li>
	<li>Аренда оборудования при полном залоге. 2.1. Для аренды оборудования при полном залоге необходимо предоставить реквизиты своей компании.
<ol>
	<li>После поступления на р/с АРЕНДОДАТЕЛЯ сумм, указанных в договоре и счете, АРЕНДАТОР может получить оборудование на складе АРЕНДОДАТЕЛЯ.</li>
	<li> Выдача оборудования производится ТОЛЬКО при наличии доверенности.</li>
</ol>
</li>
</ol>
<del>Расчет стоимости аренды:</del>
<ol>
	<li>Стоимость аренды рассчитываются исходя из цен, указанных на сайте</li>
	<li>АРЕНДАТОР оплачивает полную сумму аренды за весь период. При полном залоге оплачивается только полная стоимость оборудования, стоимость аренды вычитается из залога при возврате оборудования.</li>
</ol>
<del>Период аренды:</del>
<ol>
	<li>Отсчет аренды начинается с даты и времени, указанных в акте передачи оборудования.</li>
	<li>Окончанием аренды считается дата и время, указанные в акте возврата оборудования.</li>
	<li>Минимальный период аренды – одни сутки (24 часа).</li>
	<li>Если возврат оборудования произошел с задержкой больше чем на 2 часа, оплата происходит за следующие сутки.</li>
</ol>
<del>Контактная информация сообщаемая АРЕНДАТОРОМ:</del>
<ol>
	<li>Место эксплуатации оборудования.</li>
	<li>Телефон заказчика, телефон ответственного на объекте.</li>
	<li>АРЕНДАТОР обязан уведомить в течении суток о любых изменениях контактов, адреса эксплуатации или реквизитов.</li>
</ol>
<h5>Передача оборудования напрокат</h5>
<ol>
	<li>При передаче оборудования в аренду проверяется его работоспособность и демонстрируется АРЕНДАТОРУ. АРЕНДАТОР подписывается в акте передачи о том, что оборудование ему было передано в исправном состоянии и работоспособность продемонстрирована. В случае наличия дефектов, об этом делается отметка в акте передачи.</li>
	<li>Заправка оборудования происходит за счет АРЕНДАТОРА.</li>
	<li>В случае поломки оборудования АРЕНДАТОР обязан известить об этом АРЕНДОДАТЕЛЯ и вернуть оборудование на склад по адресу г. Москва, ул. Гоголя, д.7. за свой счет. В течении 10 рабочих дней АРЕНДОДАТЕЛЬ проводит экспертизу оборудования для определения причины поломки (естественный износ или вина АРЕНДАТОРА). В течении этого периода залог АРЕНДАТОРУ не возвращается. По результатам экспертизы, АРЕНДОДАТЕЛЬ сообщает АРЕНДАТОРУ причину поломки и возвращает залог целиком или использует его частично или полностью для ремонта оборудования. По согласованию с АРЕНДОДАТЕЛЕМ АРЕНДАТОР может произвести ремонт своими силами.</li>
	<li>Аренда оборудования прекращается ТОЛЬКО при поступлении оборудования на склад по адресу г. Москва, ул. Гоголя, д.7. или передаче его экспедитору транспортной компании с которой сотрудничает СТРОЙАРЕНДА. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Сообщения по телефону или с помощью других видов связи не останавливают аренду. Арендная плата начисляется до фактического возврата оборудования.</li>
	<li>Если оборудование сломалось, АРЕНДОДАТЕЛЬ не несет ответственность за упущенную выгоду АРЕНДАТОРОМ.</li>
	<li>Оборудование должно быть возвращено в чистом виде. В противном случае накладывается штраф в размере 500 р.</li>
	<li>АРЕНДАТОРУ может выть отказано в сдаче оборудования в аренду без указания причин. Также могут быть внесены изменения в стоимость аренды либо залога исходя из конкретного случая.</li>
</ol>","условия аренды","","inherit","closed","closed","","21-revision-v1","","","2016-03-20 22:08:42","2016-03-20 18:08:42","","21","http://ast/21-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("56","1","2016-03-20 22:37:55","2016-03-20 18:37:55","<h2>Информация о нашей компании:</h2>
Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB, Hitachi, Kubota, Hyundai.

Предоставляя услуги по аренде строительной техники, наша организация стремится отвечать любым запросам наших заказчиков, понимая важность и своевременность подачи техники требуемой модели на конкретный объект. Помимо собственных ресурсов, наша компания состоит в партнерских отношениях с компаниями, имеющими мощные базы спецтехники различных моделей и модификаций, а также нушительный выбор дополнительного оборудования, расположенными в различных районах нашего регионального покрытия. Таким образом, наша компания имеет возможность предложить своим клиентам услуги аренды любой модели строительной техники, представленной в каталоге, в соответствии с самыми высокими стандартами качества на рынке аренды специальной техники.

<strong>Наша компания всегда рада Вашему визиту!</strong>

<div class=\"col-sm-12\">
    <div class=\"col-sm-6\">
        <table class=\"table tableAbout\">
            <tr>
                <td><p><del>Полное наименование</del></p></td>
                <td></td>
            </tr>
            <tr>
                <td>ИНН / КПП</td>
                <td>5643916621 / 477301001</td>
            </tr>
            <tr>
                <td>ОГРН</td>
                <td>6797746147865</td>
            </tr>
            <tr>
                <td>ОКПО</td>
                <td>45013123</td>
            </tr>
            <tr>
                <td>Свидетельство</td>
                <td>45№563468215 0т 16.12.2013</td>
            </tr>
        </table>
        
        
        <table class=\"table tableAbout\">
            <tr>
                <td><p><del>Контактные данные</del></p></td>
                <td></td>
            </tr>
            <tr>
                <td>Юридический адрес</td>
                <td>Адресс: г. Москва, ул.Гоголя, д.7</td>
            </tr>
            <tr>
                <td>Фактический адрес</td>
                <td>Адресс: г. Москва, ул.Гоголя, д.7</td>
            </tr>
            <tr>
                <td>Телефон</td>
                <td>+7 (888) 123-45-67</td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td>mali1357@yandex.ru</td>
            </tr>
        </table>
    </div>
    <div class=\"col-sm-6\">
        <table class=\"table tableAbout\">
            <tr>
                <td><p><del>Расчетный счет</del></p></td>
                <td></td>
            </tr>
            <tr>
                <td>БИК</td>
                <td>468525578</td>
            </tr>
            <tr>
                <td>Расчетный счет</td>
                <td>78702810245435619409</td>
            </tr>
            <tr>
                <td>Корр. счет</td>
                <td>24101810404678500467</td>
            </tr>
            <tr>
                <td>Банк</td>
                <td>АО «Азия-Инвест Банк»</td>
            </tr>
        </table>
    </div>
</div>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-20 22:37:55","2016-03-20 18:37:55","","25","http://ast/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("57","1","2016-03-20 22:41:33","2016-03-20 18:41:33","<h2>Доставка строительного оборудования по Москве и Московской области:</h2>
При необходимости Вы можете воспользоваться услугой доставки оборудования.

Это поможет Вам сэкономить Ваше время и нервы.

Стоимость доставки 1500 рублей по Москве.

Доставка за МКАД 30 рублей за километр.

Стоимость вывоза равна стоимости доставки.

При этом Вам нет необходимости ехать на склад.

Доставка оплачивается в одну сторону.

Стоимость вывоза равна стоимости доставки.

Все документы по аренде будут доставлены водителем транспортной компании на Ваш объект. От Вас необходимо согласовать время, место и стоимость доставки. Погрузка и разгрузка оборудования на объекте осуществляется силами Арендатора. Простой по вине Арендатора оплачивается Арендатором из расчета 500 руб.за каждый час простоя автомобиля. Вопросы времени доставки согласовываются с водителем транспортной компании.","доставка","","inherit","closed","closed","","23-autosave-v1","","","2016-03-20 22:41:33","2016-03-20 18:41:33","","23","http://ast/23-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("58","1","2016-03-20 22:42:22","2016-03-20 18:42:22","<h2>Доставка строительного оборудования по Москве и Московской области:</h2>
При необходимости Вы можете воспользоваться услугой доставки оборудования.

Это поможет Вам сэкономить Ваше время и нервы.

Стоимость доставки 1500 рублей по Москве.

Доставка за МКАД 30 рублей за километр.

Стоимость вывоза равна стоимости доставки.

При этом Вам нет необходимости ехать на склад.

Доставка оплачивается в одну сторону.

Стоимость вывоза равна стоимости доставки.

Все документы по аренде будут доставлены водителем транспортной компании на Ваш объект.

От Вас необходимо согласовать время, место и стоимость доставки.

Погрузка и разгрузка оборудования на объекте осуществляется силами Арендатора.

Простой по вине Арендатора оплачивается Арендатором из расчета 500 руб.за каждый час простоя автомобиля.

Вопросы времени доставки согласовываются с водителем транспортной компании.
<h3>Доставка строительного оборудования в регионы России:</h3>
Доставка товара в регионы РФ осуществляется любой удобной для Вас транспортной компанией. До транспортной компании товар доставляется согласно выше указанным тарифам, далее согласно тарифов Транспортной компании.","доставка","","inherit","closed","closed","","23-revision-v1","","","2016-03-20 22:42:22","2016-03-20 18:42:22","","23","http://ast/23-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("59","1","2016-03-21 18:15:21","2016-03-21 14:15:21","Мы предоставляем нашим заказчикам услуги по прокату строительной техники и инструмента в Москве и Московской области. Наша организация имеет собственную базу качественной техники и инструмента лидирующих производителей: Makita, Hitachi и т. д.

Оказывая услуги по прокату ремонтного инструмента, мы стараемся соответствовать всем требованиям клиентов. Наша компания старается предложить своим клиентам услуги аренды наиболее востребованных моделей строительного инструмента в соответствии с самыми высокими стандартами качества на рынке аренды техники и инструмента.","КАК АРЕНДОВАТЬ КАЧЕСТВЕННЫЙ ЭЛЕКТРОИНСТРУМЕНТ?","","inherit","closed","closed","","2-revision-v1","","","2016-03-21 18:15:21","2016-03-21 14:15:21","","2","http://ast/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("60","1","2016-03-21 19:11:50","2016-03-21 15:11:50","Наша компания предлагает своим клиентам услуги по аренде строительной техники в Москве, Московской области, Санкт-Петербурге и Ленинградской области. Компания располагает собственной базой надежной спецтехники ведущих мировых производителей: Caterpillar, JCB, Hitachi, Kubota, Hyundai.","Категории","","inherit","closed","closed","","33-revision-v1","","","2016-03-21 19:11:50","2016-03-21 15:11:50","","33","http://ast/33-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("61","1","2016-03-21 19:12:05","2016-03-21 15:12:05","Мы предоставляем нашим заказчикам услуги по прокату строительной техники и инструмента в Москве и Московской области. Наша организация имеет собственную базу качественной техники и инструмента лидирующих производителей: Makita, Hitachi и т. д.","Категории","","inherit","closed","closed","","33-revision-v1","","","2016-03-21 19:12:05","2016-03-21 15:12:05","","33","http://ast/33-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("62","1","2016-03-21 20:26:08","2016-03-21 16:26:08","<h2>условия аренды</h2>
Выставленный на нашем сайте инструмент и оборудование возможно взять в аренду и вернуть ежедневно с 9:00 до 19:00. Наша компания работает без праздников и выходных. Адрес пункта аренды инструмента: г. Москва, ул. Мартеновская, д. 38, корп. 2.
<h3>Самовывоз</h3>
<ol>
	<li>Вы звоните нам по телефону и уточняете наличие нужного Вам инструмента.</li>
	<li>Вы приезжаете к нам в пункт проката, имея при себе паспорт, залоговую стоимость инструмента и оплату за весь срок проката.</li>
	<li>Вы выбираете интересующий Вас инструмент.</li>
	<li>При Вашем присутствии наш сотрудник демонстрирует исправность и рабочее состояние инструмента.</li>
	<li>Вы читаете и подписываете договор проката инструмента, вносите залоговую сумму и оплату за весь срок проката.</li>
	<li>Вы пользуетесь инструментом.</li>
	<li>Вы возвращаете чистый и исправный инструмент обратно к нам в пункт проката, подписываете акт возврата инструмента, забираете залог полностью или частично (при пользовании оборудованием дольше обозначенного в договоре проката срока).</li>
	<li>При возврате грязного инструмента накладывается штраф 500 рублей.</li>
	<li>При возврате неисправного инструмента по вине <strong>Арендатора с Арендатора</strong> удерживается сумма необходимая для ремонта инструмента.</li>
	<li>При потере инструмента <strong>Арендатор</strong> оплачивает его полную стоимость.</li>
</ol>
<h4>Плавила оформления и получения оборудования</h4>
<del>Физ. лица:</del>
<ol>
	<li>Для аренды инструмента при залоге, указанном на сайте в карточке товара, <strong>Арендатор</strong> должен быть прописан в Москве или Московской области и предъявить паспорт гражданина РФ с отметкой о прописке в Москве или МО.</li>
	<li>В любом другом случае <strong>Арендатор</strong> предъявляет документ, удостоверяющий его личность и вносит в качестве залога полную стоимость инструмента (размер полной стоимости инструмента можно уточнить у нашего сотрудника).</li>
</ol>
<del>Юр. лица:</del>
<ol>
	<li>Для аренды оборудования при залоге, указанном на сайте в карточке товара, необходимо предоставить полные данные о фирме.</li>
	<li>Необходимо предоставить паспортные данные физического лица, прописанного в Москве или Московской области, которое будет представлять юр. лицо при заключении договора аренды.</li>
	<li>После поступления на р/с <strong>Арендодателя</strong> сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
	<li>Для аренды оборудования при залоге, равном полной стоимости инструмента, необходимо предоставить реквизиты фирмы.</li>
	<li>После поступления на р/с Арендодателя сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
</ol>
<del>Определение стоимости проката:</del>
<ol>
	<li>Стоимость проката определяется исходя из цен, указанных на сайте в карточке товара и срока использования инструмента.</li>
	<li><strong>Арендатор</strong> оплачивает полную сумму аренды за весь период.</li>
	<li>При залоге, равном полной стоимости инструмента, оплачивается только залог.</li>
	<li>Стоимость аренды вычитается из залога при возврате оборудования.</li>
</ol>
<del>Определение периода проката:</del>
<ol>
	<li>Начинается прокат инструмента с даты и времени, указанных в акте передачи оборудования.</li>
	<li>Заканчивается прокат инструмента на дату и время, указанные в акте возврата оборудования.</li>
	<li>Минимальный период проката - сутки (24 часа).</li>
</ol>
<del>Информация предоставляемая <strong>Арендатором:</strong></del>
<ol>
	<li>Место эксплуатации инструмента.</li>
	<li>Телефон заказчика, телефон ответственного на объекте.</li>
	<li><strong>Арендатор</strong> обязан уведомить в течении суток о любых изменениях предоставленных данных (телефоны, адреса, реквизиты).</li>
</ol>
<h5>Получение инструмента в аренду</h5>
<ol>
	<li>При получении инструмента в прокат <strong>Арендатору</strong> демонстрируется его исправность и пригодность к работе.</li>
	<li>При поломке инструмента <strong>Арендатор</strong> должен сообщить об этом Арендодателю и вернуть инструмент в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 за свой счет. В течении 10 рабочих дней <strong>Арендодатель</strong> осуществляет проверку инструмента для определения причины поломки (естественный износ или вина <strong>Арендатора</strong>). На протяжении проверки залог <strong>Арендатору</strong> не возвращается. По результатам проверки, <strong>Арендодатель </strong>сообщает <strong>Арендатору</strong> причину неисправности и возвращает залог целиком или использует его частично или полностью для починки инструмента.</li>
	<li>Прокат инструмента заканчивается при поступлении оборудования в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 или передаче его экспедитору. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Сообщения по телефону или с помощью других видов связи не останавливают аренду. Арендная плата начисляется до фактического возврата инструмента.</li>
	<li>Если инструмент сломался, <strong>Арендодатель</strong> не несет ответственность за упущенную выгоду <strong>Арендатором</strong>.</li>
	<li>Инструмент должен быть возвращен в чистом виде. В противном случае взимается штраф в размере 500 р.</li>
	<li><strong>Арендатору</strong> может быть отказано в сдаче оборудования в прокат без указания причин. Кроме того возможны внесения изменений в стоимость аренды или залога исходя из индивидуальной ситуации.</li>
</ol>","условия аренды","","inherit","closed","closed","","21-revision-v1","","","2016-03-21 20:26:08","2016-03-21 16:26:08","","21","http://ast/21-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("63","1","2016-03-21 20:26:59","2016-03-21 16:26:59","<h2>Условия аренды</h2>
Выставленный на нашем сайте инструмент и оборудование возможно взять в аренду и вернуть ежедневно с 9:00 до 19:00. Наша компания работает без праздников и выходных. Адрес пункта аренды инструмента: г. Москва, ул. Мартеновская, д. 38, корп. 2.
<h3>Самовывоз</h3>
<ol>
	<li>Вы звоните нам по телефону и уточняете наличие нужного Вам инструмента.</li>
	<li>Вы приезжаете к нам в пункт проката, имея при себе паспорт, залоговую стоимость инструмента и оплату за весь срок проката.</li>
	<li>Вы выбираете интересующий Вас инструмент.</li>
	<li>При Вашем присутствии наш сотрудник демонстрирует исправность и рабочее состояние инструмента.</li>
	<li>Вы читаете и подписываете договор проката инструмента, вносите залоговую сумму и оплату за весь срок проката.</li>
	<li>Вы пользуетесь инструментом.</li>
	<li>Вы возвращаете чистый и исправный инструмент обратно к нам в пункт проката, подписываете акт возврата инструмента, забираете залог полностью или частично (при пользовании оборудованием дольше обозначенного в договоре проката срока).</li>
	<li>При возврате грязного инструмента накладывается штраф 500 рублей.</li>
	<li>При возврате неисправного инструмента по вине <strong>Арендатора с Арендатора</strong> удерживается сумма необходимая для ремонта инструмента.</li>
	<li>При потере инструмента <strong>Арендатор</strong> оплачивает его полную стоимость.</li>
</ol>
<h4>Плавила оформления и получения оборудования</h4>
<del>Физ. лица:</del>
<ol>
	<li>Для аренды инструмента при залоге, указанном на сайте в карточке товара, <strong>Арендатор</strong> должен быть прописан в Москве или Московской области и предъявить паспорт гражданина РФ с отметкой о прописке в Москве или МО.</li>
	<li>В любом другом случае <strong>Арендатор</strong> предъявляет документ, удостоверяющий его личность и вносит в качестве залога полную стоимость инструмента (размер полной стоимости инструмента можно уточнить у нашего сотрудника).</li>
</ol>
<del>Юр. лица:</del>
<ol>
	<li>Для аренды оборудования при залоге, указанном на сайте в карточке товара, необходимо предоставить полные данные о фирме.</li>
	<li>Необходимо предоставить паспортные данные физического лица, прописанного в Москве или Московской области, которое будет представлять юр. лицо при заключении договора аренды.</li>
	<li>После поступления на р/с <strong>Арендодателя</strong> сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
	<li>Для аренды оборудования при залоге, равном полной стоимости инструмента, необходимо предоставить реквизиты фирмы.</li>
	<li>После поступления на р/с Арендодателя сумм, указанных в договоре и счете, представитель Арендатора может получить инструмент на складе Арендодателя, при наличии доверенности.</li>
</ol>
<del>Определение стоимости проката:</del>
<ol>
	<li>Стоимость проката определяется исходя из цен, указанных на сайте в карточке товара и срока использования инструмента.</li>
	<li><strong>Арендатор</strong> оплачивает полную сумму аренды за весь период.</li>
	<li>При залоге, равном полной стоимости инструмента, оплачивается только залог.</li>
	<li>Стоимость аренды вычитается из залога при возврате оборудования.</li>
</ol>
<del>Определение периода проката:</del>
<ol>
	<li>Начинается прокат инструмента с даты и времени, указанных в акте передачи оборудования.</li>
	<li>Заканчивается прокат инструмента на дату и время, указанные в акте возврата оборудования.</li>
	<li>Минимальный период проката - сутки (24 часа).</li>
</ol>
<del>Информация предоставляемая <strong>Арендатором:</strong></del>
<ol>
	<li>Место эксплуатации инструмента.</li>
	<li>Телефон заказчика, телефон ответственного на объекте.</li>
	<li><strong>Арендатор</strong> обязан уведомить в течении суток о любых изменениях предоставленных данных (телефоны, адреса, реквизиты).</li>
</ol>
<h5>Получение инструмента в аренду</h5>
<ol>
	<li>При получении инструмента в прокат <strong>Арендатору</strong> демонстрируется его исправность и пригодность к работе.</li>
	<li>При поломке инструмента <strong>Арендатор</strong> должен сообщить об этом Арендодателю и вернуть инструмент в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 за свой счет. В течении 10 рабочих дней <strong>Арендодатель</strong> осуществляет проверку инструмента для определения причины поломки (естественный износ или вина <strong>Арендатора</strong>). На протяжении проверки залог <strong>Арендатору</strong> не возвращается. По результатам проверки, <strong>Арендодатель </strong>сообщает <strong>Арендатору</strong> причину неисправности и возвращает залог целиком или использует его частично или полностью для починки инструмента.</li>
	<li>Прокат инструмента заканчивается при поступлении оборудования в пункт проката по адресу: г. Москва, ул. Мартеновская, д. 38, корп. 2 или передаче его экспедитору. Для этого подписывается акт возврата оборудования с указанием даты и времени передачи.</li>
	<li>Сообщения по телефону или с помощью других видов связи не останавливают аренду. Арендная плата начисляется до фактического возврата инструмента.</li>
	<li>Если инструмент сломался, <strong>Арендодатель</strong> не несет ответственность за упущенную выгоду <strong>Арендатором</strong>.</li>
	<li>Инструмент должен быть возвращен в чистом виде. В противном случае взимается штраф в размере 500 р.</li>
	<li><strong>Арендатору</strong> может быть отказано в сдаче оборудования в прокат без указания причин. Кроме того возможны внесения изменений в стоимость аренды или залога исходя из индивидуальной ситуации.</li>
</ol>","условия аренды","","inherit","closed","closed","","21-revision-v1","","","2016-03-21 20:26:59","2016-03-21 16:26:59","","21","http://ast/21-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("64","1","2016-03-21 20:28:34","2016-03-21 16:28:34","<h2>Доставка строительного инструмента по Москве и Московской области::</h2>
Для удобства наших клиентов мы можем осуществить доставку инструмента непосредственно к заказчику.
Стоимость доставки внутри МКАД составляет от 500 до 1000 р. в зависимости от удаленности объекта от пункта проката (ул. Мартеновская, д. 38, корп. 2).
Доставка за МКАД - 20 р./км.
Стоимость вывоза равна стоимости доставки.
Документы по прокату будут у водителя с собой.
Погрузка и разгрузка инструмента осуществляется силами Арендатора.
Простой по вине Арендатора оплачивается Арендатором из расчета 300 р/час за каждый час простоя.","доставка","","inherit","closed","closed","","23-revision-v1","","","2016-03-21 20:28:34","2016-03-21 16:28:34","","23","http://ast/23-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("65","1","2016-03-21 20:29:13","2016-03-21 16:29:13","<h2>Доставка строительного инструмента по Москве и Московской области:</h2>
<ul>
	<li>Для удобства наших клиентов мы можем осуществить доставку инструмента непосредственно к заказчику.</li>
	<li>Стоимость доставки внутри МКАД составляет от 500 до 1000 р. в зависимости от удаленности объекта от пункта проката (ул. Мартеновская, д. 38, корп. 2).</li>
	<li>Доставка за МКАД - 20 р./км.</li>
	<li>Стоимость вывоза равна стоимости доставки.</li>
	<li>Документы по прокату будут у водителя с собой.</li>
	<li>Погрузка и разгрузка инструмента осуществляется силами Арендатора.</li>
	<li>Простой по вине Арендатора оплачивается Арендатором из расчета 300 р/час за каждый час простоя.</li>
</ul>","доставка","","inherit","closed","closed","","23-revision-v1","","","2016-03-21 20:29:13","2016-03-21 16:29:13","","23","http://ast/23-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("66","1","2016-03-21 20:29:33","2016-03-21 16:29:33","<h2>Доставка строительного инструмента по Москве и Московской области:</h2>
<ul>
	<li>Для удобства наших клиентов мы можем осуществить доставку инструмента непосредственно к заказчику.</li>
	<li>Стоимость доставки внутри МКАД составляет от 500 до 1000 р. в зависимости от удаленности объекта от пункта проката (ул. Мартеновская, д. 38, корп. 2).</li>
	<li>Доставка за МКАД - 20 р./км.</li>
	<li>Стоимость вывоза равна стоимости доставки.</li>
	<li>Документы по прокату будут у водителя с собой.</li>
	<li>Погрузка и разгрузка инструмента осуществляется силами <strong>Арендатора</strong>.</li>
	<li>Простой по вине <strong>Арендатора</strong> оплачивается <strong>Арендатором</strong> из расчета 300 р/час за каждый час простоя.</li>
</ul>","доставка","","inherit","closed","closed","","23-revision-v1","","","2016-03-21 20:29:33","2016-03-21 16:29:33","","23","http://ast/23-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("67","1","2016-03-21 20:37:39","2016-03-21 16:37:39","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>Наша компания всегда рада Вашему визиту!</b></i>

&nbsp;

<strong>Наша компания всегда рада Вашему визиту!</strong>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
<tr>
<td>Банк</td>
<td>АО «Азия-Инвест Банк»</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","inherit","closed","closed","","25-autosave-v1","","","2016-03-21 20:37:39","2016-03-21 16:37:39","","25","http://ast/25-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("68","1","2016-03-21 20:37:49","2016-03-21 16:37:49","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>Наша компания всегда рада Вашему визиту!</b></i>

&nbsp;

<strong>Наша компания всегда рада Вашему визиту!</strong>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-21 20:37:49","2016-03-21 16:37:49","","25","http://ast/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("69","1","2016-03-21 20:38:34","2016-03-21 16:38:34","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>Наша компания всегда рада Вашему визиту!</b></i>

&nbsp;
<h3><strong>Наша компания всегда рада Вашему визиту!</strong></h3>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-21 20:38:34","2016-03-21 16:38:34","","25","http://ast/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("70","1","2016-03-21 20:50:23","2016-03-21 16:50:23","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>Наша компания всегда рада Вашему визиту!</b></i>

&nbsp;
<h3><strong>Наша компания всегда рада Вашему визиту!</strong></h3>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>

<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
</tbody>
</table>

</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-21 20:50:23","2016-03-21 16:50:23","","25","http://ast/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("73","1","2016-03-22 22:51:22","2016-03-22 18:51:22","","1","","inherit","open","closed","","1","","","2016-03-22 22:51:22","2016-03-22 18:51:22","","0","http://ast/wp-content/uploads/2016/03/1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("74","1","2016-03-22 22:51:47","2016-03-22 18:51:47","","2","","inherit","open","closed","","2","","","2016-03-22 22:51:47","2016-03-22 18:51:47","","0","http://ast/wp-content/uploads/2016/03/2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("75","1","2016-03-22 22:57:45","2016-03-22 18:57:45","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>ИП Полтавец Николай Петрович</b></i>

&nbsp;
<h3><strong>Наша компания всегда рада Вашему визиту!</strong></h3>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>

<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
</tbody>
</table>

</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-22 22:57:45","2016-03-22 18:57:45","","25","http://ast/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("76","1","2016-03-23 02:53:32","2016-03-22 22:53:32","","2","","inherit","open","closed","","2-2","","","2016-03-23 02:53:32","2016-03-22 22:53:32","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/2.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("77","1","2016-03-23 02:53:44","2016-03-22 22:53:44","","1","","inherit","open","closed","","1-2","","","2016-03-23 02:53:44","2016-03-22 22:53:44","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/1.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("78","1","2016-03-23 14:15:03","2016-03-23 10:15:03","<h2>Информация о нашей компании:</h2>
Наша компания предоставляет на рынке Москвы и МО качественные и недорогие услуги по прокату строительного инструмента. При выполнении своих обязательств для наших заказчиков мы зарекомендовали себя надежным партнером, делающим все соответственно с договоренностями<wbr />, а главное – вовремя и качественно. Задача компании – добросовестная и своевременная помощь нашим клиентам в осуществлении строительно-ремо<wbr />нтной деятельности. Мы работаем качественно, оперативно и на совесть!

&nbsp;

<i><b>Наша компания всегда рада Вашему визиту!</b></i>

&nbsp;
<h3><strong>ИП Полтавец Николай Петрович</strong></h3>
<div class=\"col-sm-12\">
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Реквизиты</del></td>
<td></td>
</tr>
<tr>
<td>ИНН</td>
<td>770470033960</td>
</tr>
<tr>
<td>ОГРНИП</td>
<td>314500133600078</td>
</tr>
<tr>
<td>Свидетельство</td>
<td>50 013925280</td>
</tr>
</tbody>
</table>
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Контактные данные</del></td>
<td></td>
</tr>
<tr>
<td>АДРЕС</td>
<td>г. Москва, ул. Мартеновская, д. 38, корп. 2</td>
</tr>
<tr>
<td>ТЕЛЕФОН</td>
<td>+7 (495) 728-25-88</td>
</tr>
<tr>
<td><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">E</span></span><span style=\"font-size: small;\">-</span><span style=\"font-size: small;\"><span lang=\"en-US\" xml:lang=\"en-US\">MAIL</span></span></td>
<td>7282588@bk.ru</td>
</tr>
</tbody>
</table>
</div>
<div class=\"col-sm-6\">
<table class=\"table tableAbout\">
<tbody>
<tr>
<td><del>Расчетный счет</del></td>
<td></td>
</tr>
<tr>
<td>Р/СЧ</td>
<td>4080281033800001<wbr />5253</td>
</tr>
<tr>
<td>БАНК</td>
<td>ПАО \"Сбербанк России\"</td>
</tr>
<tr>
<td>БИК</td>
<td>044525225</td>
</tr>
<tr>
<td>К/СЧ</td>
<td>3010181040000000<wbr />0225</td>
</tr>
</tbody>
</table>
</div>
</div>","о нас","","inherit","closed","closed","","25-revision-v1","","","2016-03-23 14:15:03","2016-03-23 10:15:03","","25","http://ast.team-kaktus.tk/25-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("79","1","2016-03-23 23:34:46","2016-03-23 19:34:46","","Фото 1","","inherit","open","closed","","foto-1","","","2016-03-23 23:34:46","2016-03-23 19:34:46","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("80","1","2016-03-23 23:34:50","2016-03-23 19:34:50","","Фото 2","","inherit","open","closed","","foto-2","","","2016-03-23 23:34:50","2016-03-23 19:34:50","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-2.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("81","1","2016-03-23 23:34:53","2016-03-23 19:34:53","","Фото 3","","inherit","open","closed","","foto-3","","","2016-03-23 23:34:53","2016-03-23 19:34:53","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("82","1","2016-03-23 23:34:56","2016-03-23 19:34:56","","Фото 4","","inherit","open","closed","","foto-4","","","2016-03-23 23:34:56","2016-03-23 19:34:56","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("83","1","2016-03-23 23:34:58","2016-03-23 19:34:58","","Фото 5","","inherit","open","closed","","foto-5","","","2016-03-23 23:34:58","2016-03-23 19:34:58","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("84","1","2016-03-23 23:35:00","2016-03-23 19:35:00","","Фото 6,7,8,9,10","","inherit","open","closed","","foto-678910","","","2016-03-23 23:35:00","2016-03-23 19:35:00","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-678910.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("85","1","2016-03-23 23:35:03","2016-03-23 19:35:03","","Фото 11","","inherit","open","closed","","foto-11","","","2016-03-23 23:35:03","2016-03-23 19:35:03","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-11.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("86","1","2016-03-23 23:35:05","2016-03-23 19:35:05","","Фото 12","","inherit","open","closed","","foto-12","","","2016-03-23 23:35:05","2016-03-23 19:35:05","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-12.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("87","1","2016-03-23 23:35:08","2016-03-23 19:35:08","","Фото 13","","inherit","open","closed","","foto-13","","","2016-03-23 23:35:08","2016-03-23 19:35:08","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-13.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("88","1","2016-03-23 23:35:11","2016-03-23 19:35:11","","Фото 14","","inherit","open","closed","","foto-14","","","2016-03-23 23:35:11","2016-03-23 19:35:11","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-14.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("89","1","2016-03-23 23:35:14","2016-03-23 19:35:14","","Фото 15","","inherit","open","closed","","foto-15","","","2016-03-23 23:35:14","2016-03-23 19:35:14","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-15.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("90","1","2016-03-23 23:35:17","2016-03-23 19:35:17","","Фото 16","","inherit","open","closed","","foto-16","","","2016-03-23 23:35:17","2016-03-23 19:35:17","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-16.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("91","1","2016-03-23 23:35:22","2016-03-23 19:35:22","","Фото 17","","inherit","open","closed","","foto-17","","","2016-03-23 23:35:22","2016-03-23 19:35:22","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-17.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("92","1","2016-03-23 23:35:24","2016-03-23 19:35:24","","Фото 18","","inherit","open","closed","","foto-18","","","2016-03-23 23:35:24","2016-03-23 19:35:24","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-18.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("93","1","2016-03-23 23:35:26","2016-03-23 19:35:26","","Фото 19","","inherit","open","closed","","foto-19","","","2016-03-23 23:35:26","2016-03-23 19:35:26","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-19.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("94","1","2016-03-23 23:35:28","2016-03-23 19:35:28","","Фото 20,22,24,26,28,30,32,34","","inherit","open","closed","","foto-2022242628303234","","","2016-03-23 23:35:28","2016-03-23 19:35:28","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-2022242628303234.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("95","1","2016-03-23 23:35:31","2016-03-23 19:35:31","","Фото 21","","inherit","open","closed","","foto-21","","","2016-03-23 23:35:31","2016-03-23 19:35:31","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-21.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("96","1","2016-03-23 23:35:34","2016-03-23 19:35:34","","Фото 23","","inherit","open","closed","","foto-23","","","2016-03-23 23:35:34","2016-03-23 19:35:34","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-23.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("97","1","2016-03-23 23:35:38","2016-03-23 19:35:38","","Фото 25,27,29,31,33","","inherit","open","closed","","foto-2527293133","","","2016-03-23 23:35:38","2016-03-23 19:35:38","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Foto-2527293133.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("98","1","2016-03-23 23:37:09","2016-03-23 19:37:09","","Отбойный молоток Hitachi H65SB2","","inherit","open","closed","","otboynyy-molotok-hitachi-h65sb2","","","2016-03-23 23:37:09","2016-03-23 19:37:09","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Otboynyy-molotok-Hitachi-H65SB2.pdf","0","attachment","application/pdf","0");
INSERT INTO `wp_posts` VALUES("99","1","2016-03-23 23:37:12","2016-03-23 19:37:12","","Перфоратор Makita HR 5001 C","","inherit","open","closed","","perforator-makita-hr-5001-c","","","2016-03-23 23:37:12","2016-03-23 19:37:12","","0","http://ast.team-kaktus.tk/wp-content/uploads/2016/03/Perforator-Makita-HR-5001-C.doc","0","attachment","application/msword","0");
INSERT INTO `wp_posts` VALUES("100","1","2016-03-25 12:31:51","2016-03-25 08:31:51","","Перфоратор Makita HR 5001 C","","inherit","open","closed","","perforator-makita-hr-5001-c-2","","","2016-03-25 12:31:51","2016-03-25 08:31:51","","0","http://asteh.su/wp-content/uploads/2016/03/Perforator-Makita-HR-5001-C.pdf","0","attachment","application/pdf","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("18","2","0");
INSERT INTO `wp_term_relationships` VALUES("29","2","0");
INSERT INTO `wp_term_relationships` VALUES("30","2","0");
INSERT INTO `wp_term_relationships` VALUES("31","2","0");
INSERT INTO `wp_term_relationships` VALUES("32","2","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","nav_menu","","0","5");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8","0");
INSERT INTO `wp_terms` VALUES("2","Меню 1","menyu-1","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("7","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("8","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("9","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("10","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("11","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("12","1","dismissed_wp_pointers","wp350_media,wp360_revisions,wp360_locks,wp390_widgets");
INSERT INTO `wp_usermeta` VALUES("13","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("14","1","session_tokens","a:6:{s:64:\"ac503dc5b3e93e3a06a16e27795d94014c229842ad10524dcc8238c94a7b6615\";a:1:{s:10:\"expiration\";i:1459625100;}s:64:\"42921d3138dc96fe55acf34109df83953ff71526104b9747ee6db4f7ee8b3d5a\";a:4:{s:10:\"expiration\";i:1458932531;s:2:\"ip\";s:12:\"46.63.169.37\";s:2:\"ua\";s:110:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36\";s:5:\"login\";i:1458759731;}s:64:\"7a885c5f6d835d09a654191e5345c17ef861a96f7a1d286e30e9b08c43cf0a71\";a:4:{s:10:\"expiration\";i:1459069869;s:2:\"ip\";s:13:\"188.163.77.47\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36\";s:5:\"login\";i:1458897069;}s:64:\"c36a2f5a0b004379baec212ab994620e7dec60f6e253228b8146a7a4650540ee\";a:4:{s:10:\"expiration\";i:1459070167;s:2:\"ip\";s:13:\"212.96.109.41\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36\";s:5:\"login\";i:1458897367;}s:64:\"759184cb885a2337869240dd830ef9b1d74d3fdd6cac0d5052eb2b8f51696d34\";a:4:{s:10:\"expiration\";i:1459092872;s:2:\"ip\";s:15:\"188.163.102.139\";s:2:\"ua\";s:108:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36\";s:5:\"login\";i:1458920072;}s:64:\"f244a5dae428628201ad0027d02aa82ccb7950f72c19d5406daed7606f2398d6\";a:4:{s:10:\"expiration\";i:1459092978;s:2:\"ip\";s:15:\"188.163.102.139\";s:2:\"ua\";s:108:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36\";s:5:\"login\";i:1458920178;}}");
INSERT INTO `wp_usermeta` VALUES("15","1","wp_user-settings","libraryContent=browse&hidetb=1&editor=tinymce");
INSERT INTO `wp_usermeta` VALUES("16","1","wp_user-settings-time","1458728100");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","17");
INSERT INTO `wp_usermeta` VALUES("18","1","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","metaboxhidden_nav-menus","a:2:{i:0;s:8:\"add-post\";i:1;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES("20","1","nav_menu_recently_edited","2");
INSERT INTO `wp_usermeta` VALUES("21","1","closedpostboxes_page","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("22","1","metaboxhidden_page","a:5:{i:0;s:12:\"revisionsdiv\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$BO0pM/vOPtqgc4JOJrOTsyqx.mj8dt1","admin","leviafun777@gmail.com","","2016-03-11 14:15:43","","0","admin");


DROP TABLE IF EXISTS `wp_wfBadLeechers`;

CREATE TABLE `wp_wfBadLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_wfBlockedIPLog`;

CREATE TABLE `wp_wfBlockedIPLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`,`unixday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfBlocks`;

CREATE TABLE `wp_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfBlocksAdv`;

CREATE TABLE `wp_wfBlocksAdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockType` char(2) NOT NULL,
  `blockString` varchar(255) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `totalBlocked` int(10) unsigned DEFAULT '0',
  `lastBlocked` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfConfig`;

CREATE TABLE `wp_wfConfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_wfConfig` VALUES("actUpdateInterval","");
INSERT INTO `wp_wfConfig` VALUES("addCacheComment","0");
INSERT INTO `wp_wfConfig` VALUES("advancedCommentScanning","0");
INSERT INTO `wp_wfConfig` VALUES("alertEmails","");
INSERT INTO `wp_wfConfig` VALUES("alertOn_adminLogin","1");
INSERT INTO `wp_wfConfig` VALUES("alertOn_block","1");
INSERT INTO `wp_wfConfig` VALUES("alertOn_critical","1");
INSERT INTO `wp_wfConfig` VALUES("alertOn_loginLockout","1");
INSERT INTO `wp_wfConfig` VALUES("alertOn_lostPasswdForm","1");
INSERT INTO `wp_wfConfig` VALUES("alertOn_nonAdminLogin","0");
INSERT INTO `wp_wfConfig` VALUES("alertOn_throttle","0");
INSERT INTO `wp_wfConfig` VALUES("alertOn_update","0");
INSERT INTO `wp_wfConfig` VALUES("alertOn_warnings","1");
INSERT INTO `wp_wfConfig` VALUES("alert_maxHourly","0");
INSERT INTO `wp_wfConfig` VALUES("allowed404s","/favicon.ico
/apple-touch-icon*.png
/*@2x.png");
INSERT INTO `wp_wfConfig` VALUES("allowHTTPSCaching","0");
INSERT INTO `wp_wfConfig` VALUES("apiKey","fc3c679046eb08e92e9efc6ba80dd23a8447e2398e356f97651fc883e85c644b93aa4d59aa88a6e02a298fe79de9aece9a8ff427e68a630e6d32015449e1ecd5");
INSERT INTO `wp_wfConfig` VALUES("autoBlockScanners","1");
INSERT INTO `wp_wfConfig` VALUES("autoUpdate","0");
INSERT INTO `wp_wfConfig` VALUES("autoUpdateChoice","1");
INSERT INTO `wp_wfConfig` VALUES("bannedURLs","");
INSERT INTO `wp_wfConfig` VALUES("blockedTime","300");
INSERT INTO `wp_wfConfig` VALUES("blockFakeBots","0");
INSERT INTO `wp_wfConfig` VALUES("cbl_restOfSiteBlocked","1");
INSERT INTO `wp_wfConfig` VALUES("checkSpamIP","0");
INSERT INTO `wp_wfConfig` VALUES("debugOn","0");
INSERT INTO `wp_wfConfig` VALUES("deleteTablesOnDeact","0");
INSERT INTO `wp_wfConfig` VALUES("disableCodeExecutionUploads","0");
INSERT INTO `wp_wfConfig` VALUES("disableCookies","0");
INSERT INTO `wp_wfConfig` VALUES("email_summary_dashboard_widget_enabled","1");
INSERT INTO `wp_wfConfig` VALUES("email_summary_enabled","1");
INSERT INTO `wp_wfConfig` VALUES("email_summary_excluded_directories","wp-content/cache,wp-content/wfcache,wp-content/plugins/wordfence/tmp");
INSERT INTO `wp_wfConfig` VALUES("email_summary_interval","biweekly");
INSERT INTO `wp_wfConfig` VALUES("encKey","548ce1a74f77dd0b");
INSERT INTO `wp_wfConfig` VALUES("firewallEnabled","1");
INSERT INTO `wp_wfConfig` VALUES("howGetIPs","");
INSERT INTO `wp_wfConfig` VALUES("liveTrafficEnabled","1");
INSERT INTO `wp_wfConfig` VALUES("liveTraf_ignoreIPs","");
INSERT INTO `wp_wfConfig` VALUES("liveTraf_ignorePublishers","1");
INSERT INTO `wp_wfConfig` VALUES("liveTraf_ignoreUA","");
INSERT INTO `wp_wfConfig` VALUES("liveTraf_ignoreUsers","");
INSERT INTO `wp_wfConfig` VALUES("loginSecurityEnabled","1");
INSERT INTO `wp_wfConfig` VALUES("loginSec_blockAdminReg","1");
INSERT INTO `wp_wfConfig` VALUES("loginSec_countFailMins","240");
INSERT INTO `wp_wfConfig` VALUES("loginSec_disableAuthorScan","1");
INSERT INTO `wp_wfConfig` VALUES("loginSec_lockInvalidUsers","0");
INSERT INTO `wp_wfConfig` VALUES("loginSec_lockoutMins","240");
INSERT INTO `wp_wfConfig` VALUES("loginSec_maskLoginErrors","1");
INSERT INTO `wp_wfConfig` VALUES("loginSec_maxFailures","20");
INSERT INTO `wp_wfConfig` VALUES("loginSec_maxForgotPasswd","20");
INSERT INTO `wp_wfConfig` VALUES("loginSec_strongPasswds","pubs");
INSERT INTO `wp_wfConfig` VALUES("loginSec_userBlacklist","");
INSERT INTO `wp_wfConfig` VALUES("max404Crawlers","DISABLED");
INSERT INTO `wp_wfConfig` VALUES("max404Crawlers_action","throttle");
INSERT INTO `wp_wfConfig` VALUES("max404Humans","DISABLED");
INSERT INTO `wp_wfConfig` VALUES("max404Humans_action","throttle");
INSERT INTO `wp_wfConfig` VALUES("maxExecutionTime","");
INSERT INTO `wp_wfConfig` VALUES("maxGlobalRequests","DISABLED");
INSERT INTO `wp_wfConfig` VALUES("maxGlobalRequests_action","throttle");
INSERT INTO `wp_wfConfig` VALUES("maxMem","256");
INSERT INTO `wp_wfConfig` VALUES("maxRequestsCrawlers","DISABLED");
INSERT INTO `wp_wfConfig` VALUES("maxRequestsCrawlers_action","throttle");
INSERT INTO `wp_wfConfig` VALUES("maxRequestsHumans","DISABLED");
INSERT INTO `wp_wfConfig` VALUES("maxRequestsHumans_action","throttle");
INSERT INTO `wp_wfConfig` VALUES("maxScanHits","DISABLED");
INSERT INTO `wp_wfConfig` VALUES("maxScanHits_action","throttle");
INSERT INTO `wp_wfConfig` VALUES("neverBlockBG","neverBlockVerified");
INSERT INTO `wp_wfConfig` VALUES("other_blockBadPOST","0");
INSERT INTO `wp_wfConfig` VALUES("other_hideWPVersion","1");
INSERT INTO `wp_wfConfig` VALUES("other_noAnonMemberComments","1");
INSERT INTO `wp_wfConfig` VALUES("other_pwStrengthOnUpdate","1");
INSERT INTO `wp_wfConfig` VALUES("other_scanComments","1");
INSERT INTO `wp_wfConfig` VALUES("other_scanOutside","0");
INSERT INTO `wp_wfConfig` VALUES("other_WFNet","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_comments","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_core","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_database","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_diskSpace","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_dns","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_fileContents","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_heartbleed","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_highSense","0");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_malware","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_oldVersions","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_options","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_passwds","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_plugins","0");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_posts","1");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_public","0");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_scanImages","0");
INSERT INTO `wp_wfConfig` VALUES("scansEnabled_themes","0");
INSERT INTO `wp_wfConfig` VALUES("scan_exclude","");
INSERT INTO `wp_wfConfig` VALUES("scheduledScansEnabled","1");
INSERT INTO `wp_wfConfig` VALUES("securityLevel","2");
INSERT INTO `wp_wfConfig` VALUES("spamvertizeCheck","0");
INSERT INTO `wp_wfConfig` VALUES("ssl_verify","1");
INSERT INTO `wp_wfConfig` VALUES("startScansRemotely","0");
INSERT INTO `wp_wfConfig` VALUES("tourClosed","1");
INSERT INTO `wp_wfConfig` VALUES("vulnRegex","/(?:wordfence_test_vuln_match|\\/timthumb\\.php|\\/thumb\\.php|\\/thumbs\\.php|\\/thumbnail\\.php|\\/thumbnails\\.php|\\/thumnails\\.php|\\/cropper\\.php|\\/picsize\\.php|\\/resizer\\.php|connectors\\/uploadtest\\.html|connectors\\/test\\.html|mingleforumaction|uploadify\\.php|allwebmenus-wordpress-menu-plugin|wp-cycle-playlist|count-per-day|wp-autoyoutube|pay-with-tweet|comment-rating\\/ck-processkarma\\.php)/i");
INSERT INTO `wp_wfConfig` VALUES("welcomeClosed","1");
INSERT INTO `wp_wfConfig` VALUES("wf_summaryItems","a:7:{s:10:\"totalUsers\";i:1;s:10:\"totalPages\";s:1:\"7\";s:10:\"totalPosts\";s:1:\"1\";s:13:\"totalComments\";s:1:\"1\";s:15:\"totalCategories\";s:1:\"1\";s:11:\"totalTables\";i:45;s:9:\"totalRows\";i:703;}");
INSERT INTO `wp_wfConfig` VALUES("whitelisted","");


DROP TABLE IF EXISTS `wp_wfCrawlers`;

CREATE TABLE `wp_wfCrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_wfFileMods`;

CREATE TABLE `wp_wfFileMods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  PRIMARY KEY (`filenameMD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfHits`;

CREATE TABLE `wp_wfHits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `is404` tinyint(4) NOT NULL,
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `wp_wfHits` VALUES("1","1458920528.814742","\0\0\0\0\0\0\0\0\0\0���B","1","0","0","0","1","http://asteh.su/","","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 YaBrowser/16.3.0.7146 Yowser/2.5 Safari/537.36");
INSERT INTO `wp_wfHits` VALUES("2","1458920548.090385","\0\0\0\0\0\0\0\0\0\0���B","1","0","0","0","0","http://asteh.su/categories/?id=5","http://asteh.su/","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 YaBrowser/16.3.0.7146 Yowser/2.5 Safari/537.36");
INSERT INTO `wp_wfHits` VALUES("3","1458920570.913065","\0\0\0\0\0\0\0\0\0\0���B","1","0","0","0","0","http://asteh.su/categories/?id=4","http://asteh.su/categories/?id=5","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 YaBrowser/16.3.0.7146 Yowser/2.5 Safari/537.36");
INSERT INTO `wp_wfHits` VALUES("4","1458920575.153868","\0\0\0\0\0\0\0\0\0\0���B","1","0","0","0","0","http://asteh.su/categories/?id=6","http://asteh.su/categories/?id=4","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 YaBrowser/16.3.0.7146 Yowser/2.5 Safari/537.36");
INSERT INTO `wp_wfHits` VALUES("5","1458920598.691224","\0\0\0\0\0\0\0\0\0\0���B","1","0","0","0","0","http://asteh.su/product/?id=51","http://asteh.su/categories/?id=5","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 YaBrowser/16.3.0.7146 Yowser/2.5 Safari/537.36");


DROP TABLE IF EXISTS `wp_wfHoover`;

CREATE TABLE `wp_wfHoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` binary(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfIssues`;

CREATE TABLE `wp_wfIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfLeechers`;

CREATE TABLE `wp_wfLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `wp_wfLeechers` VALUES("24315342","\0\0\0\0\0\0\0\0\0\0���B","4");
INSERT INTO `wp_wfLeechers` VALUES("24315343","\0\0\0\0\0\0\0\0\0\0���B","1");


DROP TABLE IF EXISTS `wp_wfLockedOut`;

CREATE TABLE `wp_wfLockedOut` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfLocs`;

CREATE TABLE `wp_wfLocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfLogins`;

CREATE TABLE `wp_wfLogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfNet404s`;

CREATE TABLE `wp_wfNet404s` (
  `sig` binary(16) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `URI` varchar(1000) NOT NULL,
  PRIMARY KEY (`sig`),
  KEY `k1` (`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfReverseCache`;

CREATE TABLE `wp_wfReverseCache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_wfScanners`;

CREATE TABLE `wp_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `wp_wfStatus`;

CREATE TABLE `wp_wfStatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfThrottleLog`;

CREATE TABLE `wp_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfVulnScanners`;

CREATE TABLE `wp_wfVulnScanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfu_dbxqueue`;

CREATE TABLE `wp_wfu_dbxqueue` (
  `iddbxqueue` mediumint(9) NOT NULL AUTO_INCREMENT,
  `fileid` mediumint(9) NOT NULL,
  `priority` mediumint(9) NOT NULL,
  `status` mediumint(9) NOT NULL,
  `jobid` varchar(10) NOT NULL,
  `start_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`iddbxqueue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfu_log`;

CREATE TABLE `wp_wfu_log` (
  `idlog` mediumint(9) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(9) NOT NULL,
  `uploaduserid` mediumint(9) NOT NULL,
  `uploadtime` bigint(20) DEFAULT NULL,
  `sessionid` varchar(40) DEFAULT NULL,
  `filepath` text NOT NULL,
  `filehash` varchar(100) NOT NULL,
  `filesize` bigint(20) NOT NULL,
  `uploadid` varchar(20) NOT NULL,
  `pageid` mediumint(9) DEFAULT NULL,
  `blogid` mediumint(9) DEFAULT NULL,
  `sid` varchar(10) DEFAULT NULL,
  `date_from` datetime DEFAULT NULL,
  `date_to` datetime DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `linkedto` mediumint(9) DEFAULT NULL,
  `filedata` text,
  PRIMARY KEY (`idlog`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `wp_wfu_userdata`;

CREATE TABLE `wp_wfu_userdata` (
  `iduserdata` mediumint(9) NOT NULL AUTO_INCREMENT,
  `uploadid` varchar(20) NOT NULL,
  `property` varchar(100) NOT NULL,
  `propkey` mediumint(9) NOT NULL,
  `propvalue` text,
  `date_from` datetime DEFAULT NULL,
  `date_to` datetime DEFAULT NULL,
  PRIMARY KEY (`iduserdata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;





