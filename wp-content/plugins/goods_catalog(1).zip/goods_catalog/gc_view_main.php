<?php


?>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6 text-center">
        <h3>Вас приветсвует плагин обработки товарного каталога</h3>
        <p>
            Данный плагин выделяется своей гибкостью и даёт Вам возможность создавать любые наборы товаров с любым
            набором атрибутов
        </p>
        <p>Что и как создаватать выбираете ВЫ!</p>
        <p>
            Приятной работы ;)
        </p>
    </div>
    <div class="col-md-3"></div>
</div>